"""Same-field four-square comparison at target 1 and uniformizer depth 5."""
from collections import Counter
from fractions import Fraction
from itertools import product
import json


def four_square_contact():
    # pi^5 = 4*pi, so the two coefficient moduli are 8 and 4.
    addresses = list(product(range(8), range(4)))
    square = {(a, b): ((a*a + 2*b*b) % 8, (2*a*b) % 4) for a, b in addresses}
    pairs = Counter(((u[0] + v[0]) % 8, (u[1] + v[1]) % 4)
                    for u in square.values() for v in square.values())
    count = sum(n * pairs[((1-a) % 8, -b % 4)] for (a, b), n in pairs.items())
    direct = sum((sum(x[0] for x in xs) % 8, sum(x[1] for x in xs) % 4) == (1, 0)
                 for xs in product(square.values(), repeat=4))
    assert count == direct == 65536
    return dict(source='https://arxiv.org/pdf/1610.06935v2',
                section='3.1, proof of dyadic density theorem, target 1',
                depth=5, coefficient_moduli=[8, 4], variables=4,
                vectors=len(addresses)**4, solutions=count, normalized=str(Fraction(count, 2**15)))


if __name__ == '__main__':
    print(json.dumps(four_square_contact(), indent=2))
