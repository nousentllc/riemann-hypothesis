"""Check the written primitive-count derivation in all cells through depth five."""
from collections import Counter
from fractions import Fraction
from itertools import product
from math import comb
import json

def convolution(first, second, moduli):
    ma, mb = moduli
    result = Counter()
    for (a, b), na in first.items():
        for (c, d), nb in second.items():
            result[(a+c) % ma, (b+d) % mb] += na * nb
    return result

def check_depth(depth):
    ma, mb = 2**((depth+1)//2), 2**(depth//2)
    units, nonunits = Counter(), Counter()
    for a, b in product(range(ma), range(mb)):
        destination = units if a % 2 else nonunits
        destination[(a*a+2*b*b) % ma, (2*a*b) % mb] += 1
    whole = Counter({(0, 0): 1})
    imprimitive = whole.copy()
    for _ in range(6):
        whole = convolution(whole, units + nonunits, (ma, mb))
        imprimitive = convolution(imprimitive, nonunits, (ma, mb))
    rows = []
    for a, b in product(range(ma), range(mb)):
        primitive = whole[a, b] - imprimitive[a, b]
        if depth >= 4:
            exponent = 16 if depth == 4 else 21
            mixed = (sum(comb(6, m) for m in range(1, 6) if m%2 == a%2)
                     * 2**exponent if b % 2 == 0 else 0)
            weight = 4 if depth == 4 else 8
            all_units = weight**6 * sum(
                comb(6, m) for m in range(7)
                if (6+2*m) % ma == a and (2*m) % mb == b)
            assert primitive == mixed + all_units, (depth, a, b)
        if depth in (2, 3) and a % 2:
            assert Fraction(whole[a, b], 2**(5*depth)) == (2 if b == 0 else 0)
        rows.append([a, b, primitive, whole[a, b]])
    return dict(depth=depth, moduli=[ma, mb], histogram_units=sorted(units.items()),
                histogram_nonunits=sorted(nonunits.items()), counts=rows)

def main():
    print(json.dumps([check_depth(d) for d in range(2, 6)], indent=2))

if __name__ == '__main__':
    main()
