# Exact dyadic densities for a ramified Gram fiber · v1.1

The original rank-one Gram-fiber mass on the rank-three Gaussian lattice takes exactly two values at every valuation `4k` with `k ≥ 1`. The classifier is the coefficient of `π` in the residual unit, reduced modulo two. Here `π² = 2`, the field is the dyadic completion of `ℚ(√2)`, and scalar Haar measure gives the valuation ring mass one.

| Scalar `s = 4^k(a+bπ)`, with `a` odd | Original lattice mass |
| --- | --- |
| `b ≡ 0 (mod 2)` | `2 + 2/256^k` |
| `b ≡ 1 (mod 2)` | `2 − 2/256^k` |

Both values occur for each admissible disintegration. The first permanent tube-ratio cutoff is `4k+2` for every unit. One digit earlier every target on the shell occupies the same ball, with ratio two. The positive class contains the nonsquare unit `1+2π`. At `k=1` it gives `257/128`, the value of the square target.

## Read and verify

Version 1.1 adds a conventional bibliography and expands the original-source attribution and AI disclosure. [Component licenses](LICENSE.md) · [Original Lean source notice](pinned/NOTICE.md)

The 17 original proof source files appear only by path and Git blob ID. Offline verification validates the manifest and the local package receipts. To compare those 17 files with a separately obtained original tree, run the verifier with --upstream-src pointing to its src directory. The Lean replay still uses the original sources and compiled dependencies from the pinned environment.

The release incorporates the short coefficient proof from ChatGPT’s editorial rewrite, checked by an independent integer convolution at all 60 addresses through depth five (starting at depth two). [Editorial arithmetic check](dilates/editorial_anchors.py)

The paper brings the arithmetic count, the original named-place measure, and the target-four geometry into one exposition. The new literature comparison checks Thompson's four-square count over the same ramified field. [Independent contact check](literature/thompson_contact.json)

The geometry section uses two earlier formal studies and independent controls. [Target Haar and all 18 valuation strata](geometry/target-four-haar/README.md) · [Two pivots and the double branch](geometry/target-four-chart-overlap/README.md)

- [Single LuaLaTeX source](Ramified_Gram_Fiber_Densities.tex) · [PDF](Ramified_Gram_Fiber_Densities.pdf) · [ZIP](Nous_Ramified_Gram_Fiber_Densities.zip)
- [Replay receipt](verification/receipt.json) · [Publication recheck and cache scope](verification/publication-replay.json) · [Paper verification](verification/paper.json) · [Study protocol](PROTOCOL.md)
- [Independent all-address experiment](dilates/unit_experiment.py) · [Exact results](dilates/unit_results.json)

| Proof obligation | Lean declaration |
| --- | --- |
| Every integral unit reduces to one of the two displayed representatives | [`RamDilate.UnitClass.decomposition`](dilates/UnitResidue.lean) |
| Twenty-four coarse positive target counts | [`low2_one`, `low3_one`, `low3_two`](dilates/UnitLow.lean) |
| Every perturbed positive count equals the square count | [`RamDilate.UnitClass.same_as_square`](dilates/UnitCounts.lean) |
| Both masses at all later even and odd depths | [`RamDilate.UnitClass.all_late`](dilates/UnitCells.lean) |
| Sharp cutoff for each unit | [`RamDilate.UnitClass.sharp_stabilization`](dilates/UnitDepth.lean) |
| Exactly the two masses on the original valuation shell | [`UnitTransport.exact_range_at_exponent`](dilates/UnitEndpoint.lean) |
| Both distinct masses across all scales in one family | [`UnitTransport.values_distinct`, `UnitTransport.realized`](dilates/UnitEndpoint.lean) |

The primitive count is constant under shifts by multiples of eight. Descending in the all-divisible subtype preserves the target class and contracts density by (1/16). The positive-class counts at residual exponents zero and one supply the new anchors. Once the proof reaches exponent two, two targets in the same positive class differ by a multiple of eight. The inherited companion-cylinder proof supplies the other sign. At the first scale, half of the gap between the two masses comes from losing the all-two-divisible stratum. The other half comes from the smaller primitive count after exactly one common division by the uniformizer.

Run `python3 verify.py` to regenerate the finite controls and validate the study and paper receipts. The shell proof inventory contains 120 Lean study modules and 1,038 pinned original dependencies. The separate target-four geometry receipts identify their own replay scopes. The publication manuscript revises the exposition and retains the formal statements and proof sources. The publication recheck rebuilt ten modules including the final endpoint, revalidated 110 cached proof records, and reproduced the archived receipt byte for byte, including the four intentional negative controls. The replay command verifies the complete study manifest and hashes for 1,038 pinned original source files and their respective original compiled objects.

```sh
python3 verification/replay.py \
  --sdk /path/to/lean-4.33.1 \
  --mathlib /path/to/pinned/mathlib \
  --objects /path/to/pinned/original/olean-tree \
  --original /path/to/pinned/original/repository/src \
  --work /path/to/empty/replay-directory \
  --receipt /path/to/replay-receipt.json --jobs 3
```

Use the [cache-restoration instructions in the square-dilate edition](https://github.com/nousentllc/riemann-hypothesis/tree/17263859a4d27c62cfc67571737355f61a080806/research/uriel/experiments/ramified-square-dilates) to obtain the matching original objects and Mathlib. The [third edition](https://github.com/nousentllc/riemann-hypothesis/tree/1747b933087347e26863fbcb3dbb82debd0441e0/research/uriel/experiments/ramified-companion-lean) preserves the clean companion replay. The scope of the study is the stated local Gram datum and shell family.
