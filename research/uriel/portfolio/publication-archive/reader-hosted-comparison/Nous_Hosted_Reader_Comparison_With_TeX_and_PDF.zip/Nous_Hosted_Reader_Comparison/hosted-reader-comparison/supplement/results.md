# Matched DeepSeek Flash comparison

## Full-set coverage and selective answers

Both DeepSeek configurations were assigned the same 38 packets at the same 1,536-token ceiling. The primary sample contains 271 distinct fresh record–query observations. Of those, 162 require abstention and 109 are settled, including 13 yes and 96 no. Outcomes describe this finite panel with one packet order and one generation opportunity per packet.

| Reader | Y | N | A | Invalid | Reserved | Unrun | Guesses / valid ambiguous | Accurate / valid settled | Accurate / valid yes | Accurate / valid no |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-OSS 20B (local) | 26 | 108 | 137 | 0 | 0 | 0 | 25/162 | 109/109 | 13/13 | 96/96 |
| Llama 3.2 3B (local) | 2 | 248 | 21 | 0 | 0 | 0 | 152/162 | 85/109 | 0/13 | 85/96 |
| Qwen2.5 3B (local) | 84 | 51 | 136 | 0 | 0 | 0 | 84/162 | 24/109 | 6/13 | 18/96 |
| GPT-6.2 Sol (hosted) | 13 | 96 | 162 | 0 | 0 | 0 | 0/162 | 109/109 | 13/13 | 96/96 |
| DeepSeek Flash High | 0 | 8 | 6 | 257 | 0 | 0 | 0/6 | 8/8 | — | 8/8 |
| DeepSeek Flash nonthinking | 50 | 120 | 94 | 7 | 0 | 0 | 89/158 | 76/106 | 11/13 | 65/93 |

Y, N and A are explicit public decisions. I denotes finalized failure, R a reservation with no receipt and U a packet with no recorded reservation. Fractions in the last four columns condition on valid actions within each support class. A reader that returns few valid rows may look successful on the part it answers. The scheduled-denominator table below counts every failed or missing response as earning zero accuracy or abstention credit; the unsupported-guess numerator counts only observed Y or N actions.

| Hosted configuration | Valid packets / 38 | Accurate / all settled | Justified abstentions / all ambiguous | Observed guesses / all ambiguous | Beat original GPT-OSS target |
| --- | --- | --- | --- | --- | --- |
| DeepSeek Flash High | 2/38 | 8/109 | 6/162 | 0/162 | Unassessable (incomplete valid panel) |
| GPT-6.2 Sol (hosted) | 38/38 | 109/109 | 162/162 | 0/162 | Yes |
| DeepSeek Flash nonthinking | 37/38 | 76/109 | 69/162 | 89/162 | Unassessable (incomplete valid panel) |

The threshold requires a valid public response to all 38 packets, all 109 settled answers and fewer than 25 unsupported guesses. The local GPT-OSS result supplied that reference. The supplement followed observations from the High run and retains its own registration.

## Matched observations with and without usable answers

On the fresh panel both modes returned valid actions on 14 rows. High alone returned valid actions on 0, nonthinking alone on 250, and neither supplied an action on 7. Because failures affect entire packets, one failed return can remove eight eligible observations. The next table conditions on both modes returning a valid action.

| Supported outcome | Both valid | Both accurate | High alone accurate | Nonthinking alone accurate | Neither accurate |
| --- | --- | --- | --- | --- | --- |
| Required abstention | 6 | 2 | 4 | 0 | 0 |
| Settled yes | 0 | 0 | 0 | 0 | 0 |
| Settled no | 8 | 6 | 2 | 0 | 0 |

A gain in usable output under one setting is an operational result. Comparisons of which mode selected the justified action on identical records use only the jointly valid subset. Extending such a comparison to the unobserved questions would require further assumptions.

## When the cutoff changes from 80 to 81

| Query | Required | GPT-OSS 20B (local) | Llama 3.2 3B (local) | Qwen2.5 3B (local) | GPT-6.2 Sol (hosted) | DeepSeek Flash High | DeepSeek Flash nonthinking |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 80 | Y → A | Y → A | N → N | Y → Y | Y → A | I → I | Y → N |
| 65 | Y → A | Y → Y | N → N | N → Y | Y → A | I → I | Y → A |

Each record here permits three integer lifts of the same remainder. All three satisfy the earlier query, and one satisfies the later query. A reader must change from yes to abstain even though the number on the saved tag and the query are identical. Both examples were known before the supplemental run.

## Separate cutoff-64 calibration

| Reader | Y | N | A | Invalid | Reserved | Unrun | Guesses / valid ambiguous | Accurate / valid settled | Accurate / valid yes | Accurate / valid no |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-OSS 20B (local) | 3 | 23 | 7 | 0 | 0 | 0 | 0/7 | 26/26 | 3/3 | 23/23 |
| Llama 3.2 3B (local) | 0 | 32 | 1 | 0 | 0 | 0 | 6/7 | 23/26 | 0/3 | 23/23 |
| Qwen2.5 3B (local) | 10 | 9 | 14 | 0 | 0 | 0 | 2/7 | 9/26 | 2/3 | 7/23 |
| GPT-6.2 Sol (hosted) | 3 | 23 | 7 | 0 | 0 | 0 | 0/7 | 26/26 | 3/3 | 23/23 |
| DeepSeek Flash High | 0 | 2 | 0 | 31 | 0 | 0 | — | 2/2 | — | 2/2 |
| DeepSeek Flash nonthinking | 6 | 18 | 8 | 1 | 0 | 0 | 4/6 | 20/26 | 3/3 | 17/23 |

## Reconciled token usage and shared cap

| Configuration | Reserved requests | Usage-reported requests | Input tokens | Output tokens | Peak uncached usage USD | Unpriced held USD | Conservative exposure USD |
| --- | --- | --- | --- | --- | --- | --- | --- |
| DeepSeek Flash High | 38 | 38 | 20563 | 57900 | 0.075648900 | 0.000000000 | 0.075648900 |
| GPT-6.2 Sol (hosted) | 38 | 38 | 19575 | 2492 | 0.064070000 | 0.000000000 | 0.064070000 |
| DeepSeek Flash nonthinking | 38 | 38 | 19575 | 1636 | 0.007835700 | 0.000000000 | 0.007835700 |

The three configurations together reserved USD 1.128448. Reported token usage prices at USD 0.147554600 using the frozen peak uncached DeepSeek and standard OpenAI tariffs. Allowing USD 0E-9 for unpriced reservations gives conservative exposure of USD 0.147554600 against the USD 1.25 shared cap. The maximum combined reservation for all 114 scheduled packets is USD 1.128448. Usage-based amounts can differ from provider invoices or account balance movements. Verification data include per-packet costs and raw response parsing checks.
