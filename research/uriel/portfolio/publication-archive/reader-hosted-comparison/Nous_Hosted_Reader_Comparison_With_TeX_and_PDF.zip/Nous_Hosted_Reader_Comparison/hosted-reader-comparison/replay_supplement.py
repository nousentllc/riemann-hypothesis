"""Replay both the frozen supplemental report and its two registered parent dependencies.

The preregistered report rejected every path outside the supplement directory.
Its manifest lists the parent audit and the original study manifest. This replay
changes only path validation, authenticating the seven exact entries against
the committed tree. Scoring, accounting, timing checks and output schemas use
the frozen report implementation. The embedded Git objects support ZIP replay
without a checkout or external timestamp service.
"""
import argparse
from base64 import b64decode
from datetime import datetime, timezone
from hashlib import sha1, sha256
import importlib.util
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
COMMIT = "2dd5d495b9ecb30fffcbdea2eacd1b743b166c4a"
PARENT = "d4c23336766d39762931d106fe57d2b398069629"
MANIFEST = "12c14c1bcc8d94d8bc444c2d5b7a32a5f97939bb987cf74fa2cd503a6e0caf09"
LOCAL = {"PROTOCOL.md", "reader.mjs", "reader.sh", "report.py", "run.py"}
SHARED = {"../audit_hosted.py": "audit_hosted.py", "../FROZEN.json": "FROZEN.json"}


# Exact Git object bytes from the supplemental registration.
REGISTERED_COMMIT = (
    "dHJlZSAwYzYxOTY1ZDhhNzQ5YzU0ZDMzNzk3Y2ZhZTJjZDI0NGE1MzU0MWI0CnBhcmVudCBkNGMyMzMzNjc2NmQz"
    "OTc2MjkzMWQxMDZmZTU3ZDJiMzk4MDY5NjI5CmF1dGhvciBOb3VzIFJlc2VhcmNoIDxub3VzLXJlc2VhcmNoQGxv"
    "Y2FsaG9zdD4gMTc5NTQ3MjQyNSAtMDUwMApjb21taXR0ZXIgTm91cyBSZXNlYXJjaCA8bm91cy1yZXNlYXJjaEBs"
    "b2NhbGhvc3Q+IDE3OTU0NzI0MjUgLTA1MDAKClJlZ2lzdGVyIHNlcGFyYXRlbHkgYXV0aG9yaXplZCBuby10aGlu"
    "a2luZyBjb21wYXJpc29uIGJlZm9yZSBpbmZlcmVuY2UK"
)
REGISTERED_ROOT = (
    "MTAwNjQ0IC5naXRpZ25vcmUAWiepgbUc8Fx5Zd7xR8vnafGmGqUxMDA2NDQgRlJPWkVOLmpzb24A1UNoMg6sfrD4"
    "+LvOilq16SKopxMxMDA2NDQgUFJPVE9DT0wubWQAOPZF7Gt/HRghMJLGpDGVU9WGM2QxMDA2NDQgYXVkaXRfaG9z"
    "dGVkLnB5AOBqXZ+nfMg4R5kh2h9Whaj8rGPsNDAwMDAgaGFybmVzcwBsBboj6/QreooRAhVR/gKhj8oi5DEwMDY0"
    "NCBwdWJsaWNfcGFja2V0cy5qc29ubAC4hSWBXWGyXt8PkK/G/zFjz2T0AzEwMDY0NCBydW5faG9zdGVkLnB5AJuz"
    "Kn12uR2BA2kX3KgWlkqwyOz3MTAwNjQ0IHNjb3JlX2hvc3RlZC5weQCL0kLKLfw13p24c+oiD8SLQbMTnDQwMDAw"
    "IHN1cHBsZW1lbnQAUbxEg0vKe7z1s6Fm0VIP4frIsMc="
)
REGISTERED_SUPPLEMENT = (
    "MTAwNjQ0IEZST1pFTi5qc29uAAqUZtg2Vbrvk0lRt6jAGNZYbSRsMTAwNjQ0IFBST1RPQ09MLm1kAMXKHXLmtcM1"
    "tzyaXwDhSdx4JfeyMTAwNjQ0IHJlYWRlci5tanMA8Z3JH2fZB3GclLkYrmgNs/EGt3kxMDA3NTUgcmVhZGVyLnNo"
    "ADQc1giy8QseiQxv+Ks0GnwqWHQyMTAwNjQ0IHJlcG9ydC5weQBLdVX7dHqbVipBP2Y/JA2oEZvBBjEwMDY0NCBy"
    "dW4ucHkA57YOvulHE9CVhnJb9+OSbp1a4gA="
)


def need(condition, detail):
    if not condition:
        raise ValueError(detail)


def git_oid(kind, body):
    return sha1(kind.encode() + b" " + str(len(body)).encode() + b"\x00" + body).hexdigest()


def decode_tree(encoded, expected_oid):
    raw = b64decode(encoded, validate=True)
    need(git_oid("tree",raw)==expected_oid, "Commit tree witness failed")
    entries = {}
    at = 0
    while at < len(raw):
        nul = raw.index(b"\x00",at)
        mode, name = raw[at:nul].decode().split(" ",1)
        entries[name] = (mode,raw[nul+1:nul+21].hex())
        at = nul+21
    return entries


def commit_evidence():
    body = b64decode(REGISTERED_COMMIT,validate=True)
    need(git_oid("commit",body)==COMMIT,"Registration commit witness failed")
    lines = body.decode().split("\n\n",1)[0].splitlines()
    need("parent "+PARENT in lines,"Unexpected base experiment commit")
    root_oid = next(line.split(" ",1)[1] for line in lines if line.startswith("tree "))
    root = decode_tree(REGISTERED_ROOT,root_oid)
    mode, sub_oid = root["supplement"]
    need(mode=="40000","Supplement is not a committed directory")
    sub = decode_tree(REGISTERED_SUPPLEMENT,sub_oid)
    timestamp = int(next(line for line in lines if line.startswith("committer ")).rsplit(" ",2)[1])
    return root,sub,datetime.fromtimestamp(timestamp,timezone.utc)


def registered_inputs(folder):
    folder=folder.absolute()
    study=folder.parent
    need(folder.name=="supplement" and folder==folder.resolve(), "Supplement directory cannot be aliased")
    root,sub,stamp=commit_evidence()

    def exact(base,name,tree):
        path=base/name
        need(not path.is_symlink() and path.is_file() and path.resolve()==path, "Unsafe or missing input: "+name)
        data=path.read_bytes()
        mode,oid=tree[name]
        need(mode in ("100644","100755") and git_oid("blob",data)==oid, "Bytes differ from registered Git blob: "+name)
        return data

    raw=exact(folder,"FROZEN.json",sub)
    need(sha256(raw).hexdigest()==MANIFEST, "Supplement manifest digest mismatch")
    pins=json.loads(raw)
    need(set(pins)==LOCAL | set(SHARED), "Unexpected supplemental dependency names")
    for name,expected in pins.items():
        data=exact(study,SHARED[name],root) if name in SHARED else exact(folder,name,sub)
        need(sha256(data).hexdigest()==expected, "Supplement input digest mismatch: "+name)
    # The scoring module is imported by report.py. Verify that shared input before loading Python code.
    scorer=exact(study,"score_hosted.py",root)
    expected=json.loads(exact(study,"FROZEN.json",root))["score_hosted.py"]
    need(sha256(scorer).hexdigest()==expected, "Primary scorer digest mismatch")
    if (study/".git").exists():
        subprocess.run(["git","-C",str(study),"merge-base","--is-ancestor",COMMIT,"HEAD"],check=True)
    return MANIFEST,COMMIT,stamp


def replay(study, reference):
    sup=study.resolve()/"supplement"
    registration=registered_inputs(sup)
    spec=importlib.util.spec_from_file_location("registered_supplement_report",sup/"report.py")
    frozen=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(frozen)
    def matched(folder):
        need(folder.absolute()==sup,"Unexpected supplemental study")
        return registration
    frozen.supplemental_registration=matched
    # The supplement stores the native provider in its receipt, and the logical
    # arm in its matching reservation. Supply that field in the verifier view.
    read_raw = frozen.audit.read
    def read_evidence(path):
        record = read_raw(path)
        if path.parent == sup/"responses/deepseek" and "arm" not in record:
            reservation = read_raw(sup/"attempts/deepseek"/path.name)
            need(reservation["provider"]=="deepseek" and
                 record["provider"] in ("deepseek-account","deepseek-official") and
                 reservation["packet"]==record["packet"] and
                 reservation["prompt_sha256"]==record["prompt_sha256"],
                 "Unmatched supplemental arm identity")
            return {**record, "arm":reservation["provider"]}
        return record
    frozen.audit.read=read_evidence
    try:
        return frozen.run(sup,reference.resolve())
    finally:
        frozen.audit.read=read_raw


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study",type=Path,default=HERE)
    parser.add_argument("--reference",type=Path,default=HERE.parent/"frozen-reader-study")
    args=parser.parse_args()
    print(json.dumps(replay(args.study,args.reference)["combined"],indent=2))
