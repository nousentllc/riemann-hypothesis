/** A one-shot Cordis host. Native credential providers own every authentication operation. */
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { join } from 'node:path';

const packages = '/Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai';
const endpoint = 'https://api.deepseek.com/anthropic/v1/messages';
const catalog = 'https://api.deepseek.com/models';
const model = 'deepseek-flash';
const mode = process.argv[2];
const response = {status:'failure', content:'', usage:null, model, provider:null,
                  finish_reason:null, http_status:null, charged_request_sent:false};
// Some SDK diagnostics include provider errors. Only this program's public JSON is returned.
console.warn=()=>{};
console.error=()=>{};
const fetchNative = globalThis.fetch;
let request, checkedBody = false, catalogCalled = false;
const stable = x => JSON.stringify(x);
class Invariant extends Error {}
function requireThat(ok, code) { if (!ok) throw new Invariant(code); }
async function pkg(name) {
  return import(pathToFileURL(join(packages, name, 'lib/index.js')));
}
function assertWire(body) {
  const allowed = ['model','stream','messages','max_tokens','thinking','output_config','tools'];
  requireThat(Object.keys(body).every(k=>allowed.includes(k)), 'WIRE_FIELDS');
  requireThat(body.model===model && body.stream===true && body.max_tokens===1536, 'WIRE_CONFIG');
  requireThat(body.output_config?.effort==='high' && body.thinking?.type==='enabled', 'WIRE_REASONING');
  requireThat(!body.tools || Array.isArray(body.tools) && !body.tools.length, 'WIRE_TOOLS');
  const [m] = body.messages;
  requireThat(body.messages.length===1 && m.role==='user', 'WIRE_HISTORY');
  const parts=m.content;
  const message=typeof parts==='string' ? parts
    : Array.isArray(parts) && parts.length===1 && parts[0].type==='text' ? parts[0].text : null;
  requireThat(message===request.prompt && Object.keys(m).every(k=>['role','content'].includes(k)), 'WIRE_TEXT');
  requireThat(Buffer.byteLength(stable(body))<3000,'WIRE_INPUT');
}
globalThis.fetch = async (input, init={}) => {
  const url=String(input);
  if(url===catalog && (init.method||'GET').toUpperCase()==='GET') {
    requireThat(mode!=='preflight' && !catalogCalled,'UNEXPECTED_CATALOG');
    catalogCalled=true;
    if(mode==='wirecheck') return Response.json({data:[{id:model,api_capabilities:{anthropic_messages:{}}}]});
    return fetchNative(input,{...init,redirect:'error'});
  }
  requireThat(mode!=='preflight' && url===endpoint && init.method==='POST' && !checkedBody,'UNEXPECTED_NETWORK');
  assertWire(JSON.parse(init.body));
  checkedBody = true;
  response.wire_body_sha256=createHash('sha256').update(init.body).digest('hex');
  response.prompt_sha256=createHash('sha256').update(request.prompt).digest('hex');
  if(mode==='wirecheck') {
    const events=[
      {type:'message_start',message:{usage:{input_tokens:101}}},
      {type:'content_block_start',index:0,content_block:{type:'text',text:''}},
      {type:'content_block_delta',index:0,delta:{type:'text_delta',text:'wirecheck'}},
      {type:'content_block_stop',index:0},
      {type:'message_delta',delta:{stop_reason:'end_turn'},usage:{output_tokens:8}},
      {type:'message_stop'}
    ];
    response.http_status=200;
    return new Response(events.map(e=>'event: '+e.type+'\ndata: '+JSON.stringify(e)+'\n\n').join(''),{headers:{'content-type':'text/event-stream'}});
  }
  response.charged_request_sent = true;
  const out=await fetchNative(input,{...init,redirect:'error'});
  response.http_status=out.status;
  return out;
};
async function main() {
  requireThat(['preflight','wirecheck','run'].includes(mode),'MODE');
  const {Context}=await pkg('cordis'); const ctx=new Context();
  async function mount(name, config={}) {
    const imp=await pkg(name);
    const plugin=imp.default ?? imp;
    const fiber=ctx.plugin(plugin,config);
    await fiber.await();
    requireThat(!fiber.error,'MOUNT_'+name);
  }
  await mount('dsh-credentials-local',{watch:false});
  await mount('dsh-authorization');
  await mount('dsh-deepseek-account',{inferenceOrigin:'https://api.deepseek.com'});
  const keyConfigured=(await ctx.credentials.describe('DEEPSEEK_API_KEY')).configured;
  const signedIn=(await ctx.deepseekAccount.getState()).status==='credential-stored';
  response.provider=keyConfigured ? 'deepseek-official' : signedIn ? 'deepseek-account' : null;
  if(mode==='preflight') {
    Object.assign(response,{status:'preflight',endpoint,key_configured:keyConfigured,signed_in:signedIn});
    return;
  }
  request=JSON.parse(readFileSync(0,'utf8'));
  requireThat(response.provider && request.model===model && request.reasoning_effort==='high' &&
    request.max_output_tokens===1536 && typeof request.prompt==='string' &&
    request.prompt.length>0 && Buffer.byteLength(request.prompt)<=2048 && /^p\d{3}$/.test(request.packet),'REQUEST');
  await mount('dsh-llm');
  await mount(keyConfigured?'dsh-llm-deepseek-api-key':'dsh-llm-deepseek-account',
              {baseURL:'https://api.deepseek.com/anthropic',maxTokens:1536});
  const options={provider:response.provider,model,reasoningEffort:'high',maxTokens:1536,
    messages:[{role:'user',content:[{type:'text',text:request.prompt}]}],tools:[],
    signal:AbortSignal.timeout(180000)};
  for await(const chunk of ctx.llm.stream(options)) {
    if(chunk.type==='text-delta') response.content+=chunk.text;
    else if(chunk.type==='usage') {
      const usage=chunk.usage;
      response.usage={input_tokens:usage.inputTokens+(usage.cacheReadTokens??0)+(usage.cacheWriteTokens??0),output_tokens:usage.outputTokens};
    } else if(chunk.type==='finish') {
      const code=chunk.reason?.kind;
      if (code==='error') {
        const candidate=chunk.reason?.failure?.code || '';
        response.error_code=/^[A-Z_]{2,40}$/.test(candidate)?candidate:'PROVIDER_ERROR';
      }
      response.finish_reason=typeof code==='string'?code:'unknown';
      if(response.http_status===200 && response.usage && ['stop','max-tokens'].includes(code))
        response.status='returned';
      else response.status='provider_failure';
    }
  }
}
main().catch(error=>{
  response.error_code=error instanceof Invariant ? error.message : 'HARNESS_ERROR';
}).finally(()=>{
  process.stdout.write(JSON.stringify(response)+'\n',()=>process.exit(0));
});
