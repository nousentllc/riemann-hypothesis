"""Replay the nonthinking supplement, matched primary runs and cumulative spending ledger."""
import argparse
from collections import Counter
import csv
from decimal import Decimal
from hashlib import sha256
import io
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import audit_hosted as audit
import score_hosted as scoring

SUP = "flash_nonthinking"
HIGH = "flash_high"
NAMES = {"gptoss20": "GPT-OSS 20B (local)", "llama32":"Llama 3.2 3B (local)",
         "qwen25":"Qwen2.5 3B (local)", "openai":"GPT-6.2 Sol (hosted)", HIGH:"DeepSeek Flash High",
         SUP:"DeepSeek Flash nonthinking"}
STATES = ("Y","N","A","I","R","U")


def supplemental_registration(folder):
    path = folder / "FROZEN.json"
    pins = json.loads(path.read_bytes())
    audit.check("report.py" in pins and len(pins) >= 2, "Missing supplemental preregistration inputs")
    for name, value in pins.items():
        audit.check((folder/name).resolve().is_relative_to(folder.resolve()), "Invalid supplemental freeze path")
        audit.checked_bytes(folder/name,value)
    study = folder.parent
    if not (study/".git").exists():
        return sha256(path.read_bytes()).hexdigest(), None, None
    def git(*args):
        return subprocess.check_output(["git","-C",str(study),*args])
    c = git("log","--diff-filter=A","--format=%H","--","supplement/FROZEN.json").decode().splitlines()
    audit.check(len(c) == 1, "Ambiguous supplemental registration in local Git")
    commit = c[0]
    git("merge-base","--is-ancestor",audit.FREEZE,commit)
    for name in ("FROZEN.json",*pins):
        audit.check(git("show",f"{commit}:supplement/{name}") == (folder/name).read_bytes(),
                    "Supplement differs from its registration commit: "+name)
    timestamp = datetime.fromtimestamp(int(git("show","-s","--format=%ct",commit)),timezone.utc)
    return sha256(path.read_bytes()).hexdigest(), commit, timestamp


def reports(rows, keys):
    output = []
    for key in keys:
        c = scoring.counts(rows, key)
        valid = lambda t: sum(c[t,a] for a in scoring.VALID)
        guess = c["A","Y"] + c["A","N"]
        settled = c["N","N"] + c["Y","Y"]
        output.append([NAMES[key], *[sum(c[t,a] for t in scoring.VALID) for a in STATES],
                       scoring.fraction(guess,valid("A")), scoring.fraction(settled,valid("Y")+valid("N")),
                       scoring.fraction(c["Y","Y"],valid("Y")), scoring.fraction(c["N","N"],valid("N"))])
    return scoring.table(["Reader","Y","N","A","Invalid","Reserved","Unrun","Guesses / valid ambiguous",
                          "Accurate / valid settled","Accurate / valid yes","Accurate / valid no"], output)


def comparison(rows):
    c = Counter((r["answers"][HIGH],r["answers"][SUP]) for r in rows)
    jointly = [r for r in rows if all(r["answers"][k] in scoring.VALID for k in (HIGH,SUP))]
    paired = []
    for target,name in (("A","Required abstention"),("Y","Settled yes"),("N","Settled no")):
        group = [r for r in jointly if r["action"]==target]
        agreement = Counter((r["answers"][HIGH]==target,r["answers"][SUP]==target) for r in group)
        paired.append([name,len(group),agreement[True,True],agreement[True,False],agreement[False,True],
                       agreement[False,False]])
    valid = set(scoring.VALID)
    coverage = {
        "both_valid":len(jointly),
        "high_valid_only":sum(n for (a,b),n in c.items() if a in valid and b not in valid),
        "nonthinking_valid_only":sum(n for (a,b),n in c.items() if a not in valid and b in valid),
        "neither_valid":sum(n for (a,b),n in c.items() if a not in valid and b not in valid)}
    transitions = {a:{b:c[a,b] for b in STATES} for a in STATES}
    return coverage, paired, transitions


def benchmark(rows,key,packet_valid):
    c = scoring.counts(rows,key)
    guesses = c["A","Y"]+c["A","N"]
    precise = c["Y","Y"]+c["N","N"]
    qualified = packet_valid==38
    return {"full_valid_panel":qualified,"unsupported_guesses":guesses,"settled_accurate":precise,
            "ambiguous_abstentions":c["A","A"],"licensed_actions":precise+c["A","A"],
            "beats_local_benchmark": (precise==109 and guesses<25) if qualified else None}


def run(sup, reference):
    study = sup.parent
    digest, commit, registered = supplemental_registration(sup)
    orig = audit.audit(study,reference)
    packets,labels,_ = audit.input_evidence(study,reference)
    for name in ("attempts","responses"):
        audit.discover(sup, name, ("deepseek",), {p["id"]+".json" for p in packets})
    nonthink, cost = audit.arm(sup,"deepseek",packets,labels,registered)
    prior = scoring.checked_json(reference/"results.json",scoring.LOCAL_RESULTS_SHA)
    panel = scoring.checked_json(reference/"frozen/panel.json",scoring.PANEL_SHA)
    old = {r["row"]:r["responses"] for r in prior["observations"]}
    hosted = {k:scoring.read_records(d,n,packets)[0] for k,d,n in
              ((HIGH,study,"deepseek"),("openai",study,"openai"),(SUP,sup,"deepseek"))}
    position = {i:(p["id"],j) for p in packets for j,i in enumerate(p["rows"],1)}
    rows = panel["rows"]
    for r in rows:
        i = r["id"]
        r["packet"],r["position"] = position[i]
        r["answers"] = {**old[i],**{key:d[i] for key,d in hosted.items()}}
    fresh = [r for r in rows if r["z"]>64]
    cal = [r for r in rows if r["z"]==64]
    arms = {HIGH:orig["providers"]["deepseek"], "openai":orig["providers"]["openai"], SUP:nonthink}
    for key,item in arms.items():
        c = scoring.counts(fresh,key)
        audit.check(all(c[t,a]==item["fresh_support_then_action"][t][a] for t in scoring.VALID for a in STATES),
                    "Independent parser disagrees on fresh actions: "+key)

    def dollars_total(field):
        return sum(Decimal(item[field]) for item in arms.values())
    reserved = Decimal(sum(item["reservations_micro_usd"] for item in arms.values()))/1_000_000
    exposure = dollars_total("capped_exposure_usd")
    usage = dollars_total("usage_peak_uncached_usd")
    unknown = dollars_total("unreconciled_reservations_usd")
    audit.check(exposure==usage+unknown and exposure<=reserved<=Decimal("1.128448")<=Decimal("1.25"),
                "Cumulative reservation or cost exceeds the authorized envelope")
    money = {"authorized_usd":"1.25","max_all_three_reservations_usd":"1.128448",
             "reservations_usd":str(reserved),"usage_peak_uncached_usd":str(usage),
             "uncertain_reservations_usd":str(unknown),"capped_exposure_usd":str(exposure)}
    coverage, paired, changes = comparison(fresh)
    bench = {key:benchmark(fresh,key,item["valid_packets"]) for key,item in arms.items()}
    pairs = []
    for e in (80,65):
        ends = [next(r for r in fresh if r["z"]==z and r["tag"]==e and r["e"]==e and r["residues"]==[e])
                for z in (80,81)]
        pairs.append([e,"Y → A",*[" → ".join(r["answers"][k] for r in ends) for k in NAMES]])
    verification = {"supplement_registration_commit":commit,"supplement_manifest_sha256":digest,
                    "supplement_commit_time":registered.isoformat() if registered else None,
                    "original_registration_commit":orig["freeze_commit"],"original_manifest_sha256":orig["freeze_manifest_sha256"],
                    "panel_sha256":orig["original_panel_sha256"],"local_results_sha256":orig["original_local_results_sha256"],
                    "public_prompts_verified":orig["original_public_prompts_identical"],
                    "providers":arms,"combined":money,"benchmark":bench,"joint_coverage_fresh":coverage,
                    "high_to_nonthinking_fresh":changes}
    result = [
        "# Matched DeepSeek Flash comparison", "## Full-set coverage and selective answers",
        "Both DeepSeek configurations were assigned the same 38 packets at the same 1,536-token ceiling. "
        "The primary sample contains 271 distinct fresh record–query observations. Of those, 162 require abstention "
        "and 109 are settled, including 13 yes and 96 no. Outcomes describe this finite panel with one packet order "
        "and one generation opportunity per packet.",
        reports(fresh,NAMES),
        "Y, N and A are explicit public decisions. I denotes finalized failure, R a reservation with no receipt and U a "
        "packet with no recorded reservation. Fractions in the last four columns condition on valid actions within "
        "each support class. A reader that returns few valid rows may look successful on the part it answers. "
        "The scheduled-denominator table below counts every failed or missing response as earning zero accuracy "
        "or abstention credit; the unsupported-guess numerator counts only observed Y or N actions.",
        scoring.table(["Hosted configuration","Valid packets / 38","Accurate / all settled","Justified abstentions / all ambiguous",
                       "Observed guesses / all ambiguous","Beat original GPT-OSS target"],
                      [[NAMES[k],scoring.fraction(arms[k]["valid_packets"],38),scoring.fraction(b["settled_accurate"],109),
                        scoring.fraction(b["ambiguous_abstentions"],162),scoring.fraction(b["unsupported_guesses"],162),
                        {None:"Unassessable (incomplete valid panel)",True:"Yes",False:"No"}[b["beats_local_benchmark"]]]
                       for k,b in bench.items()]),
        "The threshold requires a valid public response to all 38 packets, all 109 settled answers and fewer than "
        "25 unsupported guesses. The local GPT-OSS result supplied that reference. The supplement followed observations "
        "from the High run and retains its own registration.",
        "## Matched observations with and without usable answers",
        f"On the fresh panel both modes returned valid actions on {coverage['both_valid']} rows. High alone returned "
        f"valid actions on {coverage['high_valid_only']}, nonthinking alone on {coverage['nonthinking_valid_only']}, "
        f"and neither supplied an action on {coverage['neither_valid']}. Because failures affect entire packets, "
        "one failed return can remove eight eligible observations. The next table conditions on both modes returning a valid action.",
        scoring.table(["Supported outcome","Both valid","Both accurate","High alone accurate",
                       "Nonthinking alone accurate","Neither accurate"],paired),
        "A gain in usable output under one setting is an operational result. Comparisons of which mode selected "
        "the justified action on identical records use only the jointly valid subset. Extending such a comparison "
        "to the unobserved questions would require further assumptions.",
        "## When the cutoff changes from 80 to 81",
        scoring.table(["Query","Required",*NAMES.values()],pairs),
        "Each record here permits three integer lifts of the same remainder. All three satisfy the earlier query, "
        "and one satisfies the later query. A reader must change from yes to abstain even though the number on the "
        "saved tag and the query are identical. Both examples were known before the supplemental run.",
        "## Separate cutoff-64 calibration", reports(cal,NAMES),
        "## Reconciled token usage and shared cap",
        scoring.table(["Configuration","Reserved requests","Usage-reported requests","Input tokens","Output tokens",
                       "Peak uncached usage USD","Unpriced held USD","Conservative exposure USD"],
                      [[NAMES[k],item["attempts"],item["priced_packets"],item["reported_input_tokens"],
                        item["reported_output_tokens"],item["usage_peak_uncached_usd"],
                        item["unreconciled_reservations_usd"],item["capped_exposure_usd"]] for k,item in arms.items()]),
        f"The three configurations together reserved USD {reserved}. Reported token usage prices at USD {usage} using "
        f"the frozen peak uncached DeepSeek and standard OpenAI tariffs. Allowing USD {unknown} for unpriced reservations "
        f"gives conservative exposure of USD {exposure} against the USD 1.25 shared cap. The maximum combined reservation "
        "for all 114 scheduled packets is USD 1.128448. Usage-based amounts can differ from provider invoices or account "
        "balance movements. Verification data include per-packet costs and raw response parsing checks.",
    ]
    buf = io.StringIO(newline="")
    w = csv.writer(buf)
    w.writerow(["row","packet","position","panel","z","e","tag","residues","yes","no","support",*NAMES])
    for r in rows:
        w.writerow([r["id"],r["packet"],r["position"],"fresh" if r["z"]>64 else "calibration",r["z"],r["e"],r["tag"],
                    " ".join(map(str,r["residues"])),r["yes"],r["no"],r["action"],*[r["answers"][k] for k in NAMES]])
    scoring.write_atomic(sup/"results.md","\n\n".join(result)+"\n")
    scoring.write_atomic(sup/"decisions.csv",buf.getvalue())
    scoring.write_atomic(sup/"verification.json",json.dumps(verification,indent=2)+"\n")
    return verification


if __name__=="__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--supplement",type=Path,default=HERE)
    parser.add_argument("--reference",type=Path,default=HERE.parent.parent/"frozen-reader-study")
    args = parser.parse_args()
    print(json.dumps(run(args.supplement,args.reference)["combined"],indent=2))
