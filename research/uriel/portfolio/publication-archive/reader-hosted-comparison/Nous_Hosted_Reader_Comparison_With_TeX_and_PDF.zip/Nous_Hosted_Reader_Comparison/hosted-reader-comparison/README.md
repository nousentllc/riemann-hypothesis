# Can a hosted reader recognize when the record is insufficient?

GPT-6.2 Sol matched the exact finite arithmetic rule on all **304 observations**, including all 33 calibration observations. On the 271 primary observations, it resolved all 109 settled questions and abstained on all 162 ambiguous ones. The strongest previously tested local reader, GPT-OSS 20B, matched all 109 settled answers but guessed on 25 ambiguous observations. The hosted GPT-6.2 Sol configuration met the target registered before its first request.

## Three settings on identical records

Each of the 38 eight-question packets was sent once to each configuration. Every model saw the same public question text. The primary run used High reasoning and the separately authorized DeepSeek follow-up explicitly disabled thinking. The table gives counts on the 271 primary observations. Each reader also saw 33 calibration observations at cutoff 64.

| Configuration | Packets returning eight valid actions | Justified sign on settled | Explicit abstentions on ambiguous | Definite guesses on ambiguous | Primary observations with unusable output |
|---|---:|---:|---:|---:|---:|
| GPT-6.2 Sol, High | 38/38 | 109/109 | 162/162 | 0 | 0 |
| DeepSeek Flash, High | 2/38 | 8/109 | 6/162 | 0 observed | 257 |
| DeepSeek Flash, thinking off | 37/38 | 76/109 | 69/162 | 89 | 7 |
| GPT-OSS 20B, original local reference | 38/38 | 109/109 | 137/162 | 25 | 0 |

**DeepSeek High leaves most of the question unanswered.** Thirty-six packets reached the 1,536-token ceiling without a valid final array. Among the 14 primary observations with usable actions, it abstained on six ambiguous observations and solved eight settled negatives. There are 156 ambiguous observations without a usable answer. Its possible full-panel guess count consequently ranges from zero to 156. A direct ranking of its abstention behavior against the other readers would rely on unobserved answers.

**Disabling thinking recovered measurable behavior.** At the same token ceiling, 37 packets yielded valid arrays. The remaining packet returned explanatory prose. Its eight observations were marked invalid according to the original parsing rule. On usable primary observations, Flash guessed on 89/158 ambiguous questions and supplied the justified sign on 76/106 settled questions. Of the latter successes, 11 were yes and 65 were no. Treating all four missing ambiguous actions as guesses would increase 89 to 93. Even its best-case completion would leave it above the 25-guess local reference. The slow-mode/fast-mode difference in usable packets is clear; comparative reasoning accuracy is poorly identified because almost all High responses were censored.

## Two hand-checkable boundary pairs

Suppose a writer saved the remainder 80 modulo 81. Three possible hidden values, 80, 161 and 242, all agree with a query of 80 modulo 81. When the cutoff increases from 80 to 81, the query instead asks for agreement modulo 243. Only 80 matches then, so the required action changes from yes to abstain. A record for remainder 65 has the same structure, with possible values 65, 146 and 227.

| Reader | Remainder 80 | Remainder 65 |
|---|---|---|
| Required action | Yes → abstain | Yes → abstain |
| GPT-6.2 Sol | Yes → abstain | Yes → abstain |
| DeepSeek Flash, thinking off | Yes → no | Yes → abstain |
| DeepSeek Flash, High | Both unavailable | Both unavailable |
| GPT-OSS 20B, local | Yes → abstain | Yes → yes |

For remainder 80 under the harder query, a no could match two of the three possible hidden values. It still asserts more than the record justifies. This distinction explains how a model can predict many hidden truths accurately and still make unwarranted claims about a particular record.

## Scope and cost

This is one paired comparison on reused, deliberately constructed arithmetic records. The candidate residues and both possible moduli were explicitly supplied. A fresh presentation, another randomization, unfamiliar arithmetic rules, and an independent item family would each test a different generalization. A score of 304/304 establishes exact agreement on these observations; it does not identify an internal algorithm. Decoding and model weights also differed between the local and hosted systems. The study includes no Lean verification.

The output receipts report 19,575 input and 2,492 output tokens for OpenAI, 20,563 and 57,900 for DeepSeek High, and 19,575 and 1,636 for DeepSeek with thinking disabled. At the frozen standard OpenAI and peak uncached DeepSeek rates, the **combined token-based upper bound is USD 0.1475546**, under the approved USD 1.25 ceiling. The calculation includes all invalid outputs. Actual DeepSeek charges may be lower because off-peak and cache prices differ. The figure is an upper bound derived from usage, rather than an account invoice.

## Replay and evidence

Use the two sibling folders in the ZIP. From hosted-reader-comparison, Python 3.11 or later can rebuild the tables without contacting a provider.

~~~sh
python3 -B score_hosted.py
python3 -B audit_hosted.py
python3 -B replay_supplement.py
~~~

The primary [protocol](PROTOCOL.md) and its model-request transports were committed at d4c2333 before any inference. The [supplement](supplement/PROTOCOL.md) was committed at 2dd5d49 after the High-mode failures were observed and before the first nonthinking request. The replay wrapper resolves two recorded parent-directory dependency pins against the committed study tree. It also reads the supplemental arm identity from the matching reservation, because the supplemental receipt records the native provider name. The raw receipts, original manifests and reporting code retain their pre-run bytes.

The [primary results](hosted_results.md), [combined comparison](supplement/results.md), [row-level decisions](supplement/decisions.csv), and [combined audit](supplement/verification.json) distinguish usable answers, invalid outputs and unrun rows. The archive contains the exact public prompts, public completion text, per-request timestamps, usage, original reference inputs and a local Git history bundle. To inspect the timing evidence, clone hosted-history.bundle as hosted-reader-comparison in a separate directory and place the frozen-reader-study reference alongside it. Commit times are workstation timestamps.

**Human–AI collaboration.** Justin Candler approved the spending ceiling, supplied access to the existing provider accounts, and authorized the nonthinking follow-up. Uriel in Codex prepared the protocol, dispatched the public packets, and scored and audited the responses. GPT-6.2 Sol and DeepSeek Flash were evaluated systems.
