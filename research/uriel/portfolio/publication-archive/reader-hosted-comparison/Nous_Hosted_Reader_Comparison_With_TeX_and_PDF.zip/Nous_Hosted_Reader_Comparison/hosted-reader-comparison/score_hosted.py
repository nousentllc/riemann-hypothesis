"""Score archived hosted reader outputs locally. No provider connections or credentials."""
import argparse
from collections import Counter
import csv
from hashlib import sha256
import io
import json
from pathlib import Path
from tempfile import NamedTemporaryFile

HERE = Path(__file__).resolve().parent
PANEL_SHA = "b6969f3d5d8343edc3f0fbda8c36cb0f09ccbc875e1dd7da8f79d5395c684320"
LOCAL_RESULTS_SHA = "3a7d1a45508eec37466aec754f6fc5e5b8422cc109cf415394bfb1ba78c31392"
NAMES = {"gptoss20": "GPT-OSS 20B (local)", "llama32": "Llama 3.2 3B (local)",
         "qwen25": "Qwen2.5 3B (local)", "deepseek": "DeepSeek Flash (hosted)",
         "openai": "GPT-6.2 Sol (hosted)"}
HOSTED = ("deepseek", "openai")
VALID = ("Y", "N", "A")


def checked_json(path, expected_digest):
    data = path.read_bytes()
    if sha256(data).hexdigest() != expected_digest:
        raise ValueError(f"Frozen reference changed: {path}")
    return json.loads(data)


def read_records(study, provider, packets):
    outputs = {}
    statuses = Counter()
    known = {p["id"] for p in packets}
    for directory in ("responses", "attempts"):
        unexpected = {f.stem for f in (study / directory / provider).glob("*.json")} - known
        if unexpected:
            raise ValueError(f"{provider}: unexpected {directory} files {sorted(unexpected)}")
    for p in packets:
        pid = p["id"]
        receipt = study / "responses" / provider / (pid + ".json")
        reservation = study / "attempts" / provider / (pid + ".json")
        if receipt.is_file():
            r = json.loads(receipt.read_bytes())
            if r.get("packet") != pid or r.get("prompt_sha256") != p["prompt_sha256"]:
                raise ValueError(f"Receipt identity mismatch: {receipt}")
            if r["status"] == "ok":
                seq = r["actions"]
                if not isinstance(seq, list) or len(seq) != len(p["rows"]) or any(a not in VALID for a in seq):
                    raise ValueError(f"Malformed actions in successful receipt: {receipt}")
                if "content" in r and json.loads(r["content"]) != {"actions": seq}:
                    raise ValueError(f"Saved actions differ from public response: {receipt}")
                statuses["valid"] += 1
            else:
                if not isinstance(r["status"], str) or not r["status"]:
                    raise ValueError(f"Missing receipt status: {receipt}")
                seq = ["I"] * len(p["rows"])
                statuses["invalid"] += 1
        elif reservation.is_file():
            statuses["reserved"] += 1
            seq = ["R"] * len(p["rows"])
        else:
            statuses["unrun"] += 1
            seq = ["U"] * len(p["rows"])
        outputs.update(zip(p["rows"], seq))
    return outputs, statuses


def table(headers, data):
    lines = [headers, ["---"] * len(headers), *data]
    return "\n".join("| " + " | ".join(map(str, line)) + " |" for line in lines)


def counts(group, provider):
    return Counter((r["action"], r["answers"][provider]) for r in group)


def fraction(numerator, denominator):
    return f"{numerator}/{denominator}" if denominator else "—"


def metrics(group, provider):
    c = counts(group, provider)
    # Partial denominators include finalized failures. Reservations and unrun rows have no response.
    observed = {t: sum(c[t, a] for a in (*VALID, "I")) for t in VALID}
    guesses = c["A", "Y"] + c["A", "N"]
    settled = c["Y", "Y"] + c["N", "N"]
    coverage = [sum(c[t, a] for t in VALID) for a in ("I", "R", "U")]
    numbers = [fraction(guesses, observed["A"]), fraction(c["A", "A"], observed["A"]),
               fraction(settled, observed["Y"] + observed["N"]), fraction(c["Y", "Y"], observed["Y"]),
               fraction(c["N", "N"], observed["N"]), *coverage]
    return numbers, guesses, settled, sum(coverage)


def write_atomic(path, text):
    with NamedTemporaryFile("w", encoding="utf-8", newline="", dir=path.parent,
                            suffix=".tmp", delete=False) as handle:
        handle.write(text)
    Path(handle.name).replace(path)


def score(study, reference):
    panel = checked_json(reference / "frozen/panel.json", PANEL_SHA)
    prior = checked_json(reference / "results.json", LOCAL_RESULTS_SHA)
    packets = panel["packets"]
    packet_position = {rid: (p["id"], pos) for p in packets for pos, rid in enumerate(p["rows"], 1)}
    rows = panel["rows"]
    hosted, coverage = {}, {}
    for name in HOSTED:
        hosted[name], coverage[name] = read_records(study, name, packets)
    old = {r["row"]: r["responses"] for r in prior["observations"]}
    for r in rows:
        rid = r["id"]
        r["packet"], r["position"] = packet_position[rid]
        r["answers"] = {**old[rid], **{name: hosted[name][rid] for name in HOSTED}}

    fresh = [r for r in rows if r["z"] > 64]
    calibration = [r for r in rows if r["z"] == 64]
    headers = ["Reader", "Unsupported guesses / ambiguous", "Abstentions / ambiguous", "Accurate / settled",
               "Accurate yes", "Accurate no", "Invalid rows", "Reserved rows", "Unrun rows"]
    comparison, verdicts = [], []
    for name, label in NAMES.items():
        numbers, guesses, settled, missing = metrics(fresh, name)
        comparison.append([label, *numbers])
        if name in HOSTED:
            if missing:
                verdict = f"Incomplete coverage ({missing} fresh rows lack valid actions)."
            else:
                verdict = ("Met" if settled == 109 and guesses < 25 else "Did not meet")
                verdict += f" both thresholds ({settled}/109 settled and {guesses}/162 guesses)."
            verdicts.append([label, verdict])

    pairs = []
    for e in (80, 65):
        matched = [next(r for r in rows if r["z"] == z and r["e"] == e and r["tag"] == e
                        and r["residues"] == [e]) for z in (80, 81)]
        pairs.append([e, "Y → A", *[" → ".join(r["answers"][name] for r in matched) for name in NAMES]])
    packet_header = ["Hosted reader", "Valid", "Finalized invalid", "Reserved with no receipt", "Unrun"]
    packet_rows = [[NAMES[n], *[coverage[n][k] for k in ("valid", "invalid", "reserved", "unrun")]] for n in HOSTED]
    report = [
        "# Hosted readers on the frozen cutoff panel", "## Primary comparison",
        "Each full reader received the same 38 eight-question packets. Primary measures use the 271 fresh observations "
        "spanning eight cutoffs. The exact support rule licenses abstention on 162 observations and a definitive answer "
        "on 109, including 13 yes and 96 no. The local comparison was recorded before this hosted study.",
        table(headers, comparison),
        "Each fraction uses the observed, finalized rows in its own support class. Invalid finalized responses earn "
        "zero accuracy and zero abstention credit. Blank denominators mean that no rows of that class have a finalized "
        "receipt. Counts for a partial run describe its returned subset. A full-panel comparison requires coverage of "
        "the entire panel. An invalid response does not reveal whether the model would have guessed.",
        "## Registered hosted comparison", "The target requires all 109 settled answers and fewer than the local "
        "GPT-OSS reader’s 25 unsupported guesses among 162 ambiguous rows. The verdict requires valid answers on "
        "all 271 fresh observations. The same records and earlier local outcomes were already known at design time.",
        table(["Reader", "Fresh-panel result"], verdicts),
        "## Packet accounting", table(packet_header, packet_rows),
        "I denotes a finalized failure with no usable answer. R denotes a recorded reservation without a final "
        "receipt; actual dispatch and billing can be uncertain. U denotes a packet with neither a reservation nor "
        "a final response file. Paid usage requires the collector’s separate billing ledger.",
        "## The cutoff boundary", table(["Query", "Supported action", *NAMES.values()], pairs),
        "At the first cutoff, each of the three possible hidden integers matches the query modulo 81. At the "
        "second cutoff, only one matches modulo 243. Their low remainder and the query did not change. Other "
        "questions in each packet can differ. Both cases had been examined in the local run.",
        "## Cutoff-64 calibration", table(headers, [[label, *metrics(calibration, key)[0]] for key, label in NAMES.items()]),
        "## Interpretation", "This is a paired evaluation on a finite, deliberately selected panel. It measures how "
        "each configured reader uses a public record. The comparison changes model and serving configuration together. "
        "Each question appeared in one fixed packet position. The row-level CSV retains every individual answer and "
        "all prompt positions for subsequent matched analyses.",
    ]
    csv_buffer = io.StringIO(newline="")
    out = csv.writer(csv_buffer)
    out.writerow(["row", "packet", "position", "panel", "z", "e", "tag", "residues", "hidden_yes", "hidden_no",
                  "licensed_action", *NAMES])
    for r in rows:
        out.writerow([r["id"], r["packet"], r["position"], "fresh" if r["z"] > 64 else "calibration", r["z"],
                      r["e"], r["tag"], " ".join(map(str, r["residues"])), r["yes"], r["no"], r["action"],
                      *[r["answers"][k] for k in NAMES]])
    write_atomic(study / "hosted_decisions.csv", csv_buffer.getvalue())
    write_atomic(study / "hosted_results.md", "\n\n".join(report) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, default=HERE)
    parser.add_argument("--reference", type=Path, default=HERE.parent / "frozen-reader-study")
    options = parser.parse_args()
    score(options.study, options.reference)
