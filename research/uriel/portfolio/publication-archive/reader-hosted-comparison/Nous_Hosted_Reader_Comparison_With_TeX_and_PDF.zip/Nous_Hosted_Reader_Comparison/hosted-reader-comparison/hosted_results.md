# Hosted readers on the frozen cutoff panel

## Primary comparison

Each full reader received the same 38 eight-question packets. Primary measures use the 271 fresh observations spanning eight cutoffs. The exact support rule licenses abstention on 162 observations and a definitive answer on 109, including 13 yes and 96 no. The local comparison was recorded before this hosted study.

| Reader | Unsupported guesses / ambiguous | Abstentions / ambiguous | Accurate / settled | Accurate yes | Accurate no | Invalid rows | Reserved rows | Unrun rows |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-OSS 20B (local) | 25/162 | 137/162 | 109/109 | 13/13 | 96/96 | 0 | 0 | 0 |
| Llama 3.2 3B (local) | 152/162 | 10/162 | 85/109 | 0/13 | 85/96 | 0 | 0 | 0 |
| Qwen2.5 3B (local) | 84/162 | 78/162 | 24/109 | 6/13 | 18/96 | 0 | 0 | 0 |
| DeepSeek Flash (hosted) | 0/162 | 6/162 | 8/109 | 0/13 | 8/96 | 257 | 0 | 0 |
| GPT-6.2 Sol (hosted) | 0/162 | 162/162 | 109/109 | 13/13 | 96/96 | 0 | 0 | 0 |

Each fraction uses the observed, finalized rows in its own support class. Invalid finalized responses earn zero accuracy and zero abstention credit. Blank denominators mean that no rows of that class have a finalized receipt. Counts for a partial run describe its returned subset. A full-panel comparison requires coverage of the entire panel. An invalid response does not reveal whether the model would have guessed.

## Registered hosted comparison

The target requires all 109 settled answers and fewer than the local GPT-OSS reader’s 25 unsupported guesses among 162 ambiguous rows. The verdict requires valid answers on all 271 fresh observations. The same records and earlier local outcomes were already known at design time.

| Reader | Fresh-panel result |
| --- | --- |
| DeepSeek Flash (hosted) | Incomplete coverage (257 fresh rows lack valid actions). |
| GPT-6.2 Sol (hosted) | Met both thresholds (109/109 settled and 0/162 guesses). |

## Packet accounting

| Hosted reader | Valid | Finalized invalid | Reserved with no receipt | Unrun |
| --- | --- | --- | --- | --- |
| DeepSeek Flash (hosted) | 2 | 36 | 0 | 0 |
| GPT-6.2 Sol (hosted) | 38 | 0 | 0 | 0 |

I denotes a finalized failure with no usable answer. R denotes a recorded reservation without a final receipt; actual dispatch and billing can be uncertain. U denotes a packet with neither a reservation nor a final response file. Paid usage requires the collector’s separate billing ledger.

## The cutoff boundary

| Query | Supported action | GPT-OSS 20B (local) | Llama 3.2 3B (local) | Qwen2.5 3B (local) | DeepSeek Flash (hosted) | GPT-6.2 Sol (hosted) |
| --- | --- | --- | --- | --- | --- | --- |
| 80 | Y → A | Y → A | N → N | Y → Y | I → I | Y → A |
| 65 | Y → A | Y → Y | N → N | N → Y | I → I | Y → A |

At the first cutoff, each of the three possible hidden integers matches the query modulo 81. At the second cutoff, only one matches modulo 243. Their low remainder and the query did not change. Other questions in each packet can differ. Both cases had been examined in the local run.

## Cutoff-64 calibration

| Reader | Unsupported guesses / ambiguous | Abstentions / ambiguous | Accurate / settled | Accurate yes | Accurate no | Invalid rows | Reserved rows | Unrun rows |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-OSS 20B (local) | 0/7 | 7/7 | 26/26 | 3/3 | 23/23 | 0 | 0 | 0 |
| Llama 3.2 3B (local) | 6/7 | 1/7 | 23/26 | 0/3 | 23/23 | 0 | 0 | 0 |
| Qwen2.5 3B (local) | 2/7 | 5/7 | 9/26 | 2/3 | 7/23 | 0 | 0 | 0 |
| DeepSeek Flash (hosted) | 0/7 | 0/7 | 2/26 | 0/3 | 2/23 | 31 | 0 | 0 |
| GPT-6.2 Sol (hosted) | 0/7 | 7/7 | 26/26 | 3/3 | 23/23 | 0 | 0 | 0 |

## Interpretation

This is a paired evaluation on a finite, deliberately selected panel. It measures how each configured reader uses a public record. The comparison changes model and serving configuration together. Each question appeared in one fixed packet position. The row-level CSV retains every individual answer and all prompt positions for subsequent matched analyses.
