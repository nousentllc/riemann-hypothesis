"""Independently check original hosted-panel evidence and conservative USD billing bounds."""
import argparse
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
from tempfile import NamedTemporaryFile

HERE = Path(__file__).resolve().parent
FREEZE = "d4c23336766d39762931d106fe57d2b398069629"
FREEZE_SHA = "ba9fd78453e09b0a7336d73fa05add9a931bf72f67d8cf76593d35030c0eb805"
PANEL_SHA = "b6969f3d5d8343edc3f0fbda8c36cb0f09ccbc875e1dd7da8f79d5395c684320"
LOCAL_RESULTS_SHA = "3a7d1a45508eec37466aec754f6fc5e5b8422cc109cf415394bfb1ba78c31392"
RATES_NANO = {"deepseek": (300, 1_200), "openai": (2_000, 10_000)}
MAX_RESERVE_MICRO = {"deepseek": 3_072, "openai": 23_552}
USD_CAP_NANO = 1_250_000_000
INPUT_LIMIT, OUTPUT_LIMIT = 4096, 1536


def check(ok, detail):
    if not ok:
        raise ValueError(detail)


def read(path):
    return json.loads(path.read_bytes())


def checked_bytes(path, digest):
    b = path.read_bytes()
    check(sha256(b).hexdigest() == digest, "Digest mismatch: " + str(path))
    return b


def git_time(study, pins):
    if not (study / ".git").exists():
        return None

    def git(*args):
        return subprocess.check_output(["git", "-C", str(study), *args])
    git("merge-base", "--is-ancestor", FREEZE, "HEAD")
    for name in ["FROZEN.json", *pins]:
        check(git("show", f"{FREEZE}:{name}") == (study / name).read_bytes(),
              "Historical hosted freeze mismatch: " + name)
    return datetime.fromtimestamp(int(git("show", "-s", "--format=%ct", FREEZE)), timezone.utc)


def instant(value):
    t = datetime.fromisoformat(value)
    check(t.utcoffset() is not None, "Missing timezone in journal")
    return t


def decode_actions(content):
    if not isinstance(content, str):
        return None
    try:
        result = json.loads(content)
    except ValueError:
        return None
    if not isinstance(result, dict) or list(result) != ["actions"]:
        return None
    actions = result["actions"]
    if isinstance(actions, list) and len(actions) == 8 and all(a in ("Y", "N", "A") for a in actions):
        return actions
    return None


def usd(nano):
    dollars, frac = divmod(nano, 10**9)
    return f"{dollars}.{frac:09d}"


def discover(study, group, providers, expected_packets):
    root = study / group
    if not root.exists():
        return
    for entry in root.iterdir():
        check(entry.name in providers and entry.is_dir(), f"Unexpected original-study entry: {entry}")
        for path in entry.iterdir():
            check(path.is_file() and path.name in expected_packets, "Unexpected receipt or journal: " + str(path))


def input_evidence(study, reference):
    pins = json.loads(checked_bytes(study / "FROZEN.json", FREEZE_SHA))
    for name, digest in pins.items():
        checked_bytes(study / name, digest)
    panel = json.loads(checked_bytes(reference / "frozen/panel.json", PANEL_SHA))
    prior = json.loads(checked_bytes(reference / "results.json", LOCAL_RESULTS_SHA))
    check(prior["panel_sha256"] == PANEL_SHA, "Local results refer to another panel")
    packets = panel["packets"]
    check([p["id"] for p in packets] == [f"p{i:03d}" for i in range(1,39)], "Panel packet sequence differs")
    public = [json.loads(line) for line in (study / "public_packets.jsonl").read_bytes().splitlines()]
    check(public == [{"packet": p["id"], "prompt_sha256": p["prompt_sha256"], "prompt": p["prompt"]}
                     for p in packets], "Hosted text differs from the pinned local messages")
    check(all(sha256(p["prompt"].encode()).hexdigest() == p["prompt_sha256"] for p in packets),
          "Original message hashes disagree")
    labels = {r["id"]: (r["z"],r["action"]) for r in panel["rows"]}
    check(Counter(key for p in packets for key in p["rows"]) == Counter({key:1 for key in labels}),
          "Public records must cover all unique observations once")
    return packets, labels, git_time(study, pins)


def arm(study, name, packets, labels, freeze_at):
    count = Counter()
    fresh = Counter()
    split_counts = {"fresh": Counter(), "calibration": Counter()}
    costs = []
    start_time = None
    last_end = None
    closed = False
    expected_reserve = MAX_RESERVE_MICRO[name]
    price_in, price_out = RATES_NANO[name]
    check(INPUT_LIMIT*price_in + OUTPUT_LIMIT*price_out == expected_reserve*1000, "Reserve tariff mismatch")

    for p in packets:
        pid = p["id"]
        receipt = study / "responses" / name / (pid+".json")
        journal = study / "attempts" / name / (pid+".json")
        if not journal.is_file():
            check(not receipt.exists(), "Result without original reservation: " + pid)
            closed = True
            count["unrun_packets"] += 1
            actions = ["U"] * 8
        else:
            check(not closed, f"{name}/{pid} was reserved after missing, uncertain, or failed predecessor")
            j = read(journal)
            check((j["provider"],j["packet"],j["prompt_sha256"],j["reservation_micro_usd"]) ==
                  (name,pid,p["prompt_sha256"],expected_reserve), "Reservation identity mismatch: "+pid)
            started = instant(j["started"])
            if start_time is None:
                start_time = started
            check(last_end is None or started >= last_end, "Overlapping or unordered reservations: "+pid)
            check(freeze_at is None or started >= freeze_at, "Reservation predates protocol commit: "+pid)
            count["reserved_packets"] += 1
            cost_row = {"packet":pid, "reserved_micro_usd":expected_reserve,
                        "usage_peak_uncached_usd":None, "capped_exposure_usd":usd(expected_reserve*1000)}
            costs.append(cost_row)
            if not receipt.is_file():
                closed = True
                count["pending_receipt_packets"] += 1
                count["unreconciled_reserve_micro_usd"] += expected_reserve
                actions = ["R"] * 8
            else:
                rec = read(receipt)
                check(all(rec[k] == j[k] for k in ("packet","started","prompt_sha256","reservation_micro_usd")),
                      "Saved receipt and reservation differ: "+pid)
                check(rec.get("arm", rec.get("provider")) == name, "Receipt arm differs: "+pid)
                last_end = instant(rec["ended"])
                check(started <= last_end, "Receipt completion precedes dispatch: "+pid)
                status = rec["status"]
                cost_row["status"] = status
                count["finalized_packets"] += 1
                parsed = decode_actions(rec.get("content"))
                if status in ("ok", "invalid_output"):
                    check(rec.get("http_status") == 200 and rec.get("charged_request_sent") is True,
                          "Scorable response lacks provider dispatch evidence: "+pid)
                    if name == "deepseek":
                        check(rec.get("provider") in ("deepseek-account","deepseek-official")
                              and rec.get("model") == "deepseek-flash"
                              and re.fullmatch(r"[0-9a-f]{64}",rec.get("wire_body_sha256","")),
                              "DeepSeek origin/model/digest metadata differs: "+pid)
                    else:
                        model = rec.get("model") or ""
                        check(rec.get("provider")=="OpenAI" and (model=="gpt-6.2-sol" or model.startswith("gpt-6.2-sol-"))
                              and rec.get("service_tier") in (None,"default","standard"), "OpenAI model/tier metadata differs: "+pid)
                    check(("content" in rec and isinstance(rec["content"], str)) and
                          ((parsed is not None) == (status == "ok")), "Independent parse disagrees: "+pid)
                else:
                    check(isinstance(status,str) and status, "Missing provider outcome")
                    closed = True
                if status == "ok":
                    check(parsed == rec.get("actions"), "Saved decisions differ from returned JSON: "+pid)
                    actions = parsed
                    count["valid_packets"] += 1
                else:
                    check(not rec.get("actions"), "Failed result includes scored actions: "+pid)
                    actions = ["I"] * 8
                    count["invalid_packets"] += 1
                usage = rec.get("usage") or {}
                for k,limit in (("input_tokens",INPUT_LIMIT),("output_tokens",OUTPUT_LIMIT)):
                    n = usage.get(k)
                    if n is not None:
                        check(type(n) is int and 0 <= n <= limit, "Token count outside bound: "+pid+"/"+k)
                        count["reported_"+k] += n
                        count["max_"+k] = max(n, count["max_"+k])
                ni, no = usage.get("input_tokens"), usage.get("output_tokens")
                if ni is not None and no is not None:
                    cached = usage.get("cached_input_tokens")
                    check(cached is None or (type(cached) is int and 0 <= cached <= ni),
                          "Invalid cache count: "+pid)
                    nano = ni*price_in + no*price_out
                    check(nano <= expected_reserve*1000, "Usage-price bound exceeds reservation: "+pid)
                    count["usage_priced_packets"] += 1
                    count["usage_peak_nano_usd"] += nano
                    cost_row.update(input_tokens=ni, output_tokens=no, usage_peak_uncached_usd=usd(nano),
                                    capped_exposure_usd=usd(nano))
                else:
                    count["unreconciled_reserve_micro_usd"] += expected_reserve
        for key, action in zip(p["rows"],actions):
            z, support = labels[key]
            split = "fresh" if z > 64 else "calibration"
            split_counts[split][action] += 1
            if z > 64:
                fresh[support,action] += 1

    held_nano = count["reserved_packets"]*expected_reserve*1000
    unknown_nano = count["unreconciled_reserve_micro_usd"]*1000
    exposure = count["usage_peak_nano_usd"] + unknown_nano
    check(exposure <= held_nano, "Total held amount is too small")
    fresh_table = {a:{b:fresh[a,b] for b in ("Y","N","A","I","R","U")} for a in ("Y","N","A")}
    result = {
        "attempts":count["reserved_packets"], "reservations_micro_usd":held_nano//1000,
        "valid_packets":count["valid_packets"], "finalized_invalid_packets":count["invalid_packets"],
        "unrun_packets":count["unrun_packets"], "reserved_without_receipt":count["pending_receipt_packets"],
        "priced_packets":count["usage_priced_packets"],
        "reported_input_tokens":count["reported_input_tokens"], "reported_output_tokens":count["reported_output_tokens"],
        "max_reported_input_tokens":count["max_input_tokens"], "max_reported_output_tokens":count["max_output_tokens"],
        "usage_peak_uncached_usd":usd(count["usage_peak_nano_usd"]),
        "unreconciled_reservations_usd":usd(unknown_nano), "capped_exposure_usd":usd(exposure),
        "rows_by_panel":{k:dict(v) for k,v in split_counts.items()}, "fresh_support_then_action":fresh_table,
        "first_reserved_utc":start_time.isoformat() if start_time else None, "packet_costs":costs
    }
    return result, (held_nano, count["usage_peak_nano_usd"], unknown_nano, exposure)


def audit(study, reference):
    packets,labels,freeze_at = input_evidence(study, reference)
    expected_packets = {p["id"] + ".json" for p in packets}
    for directory in ("attempts","responses"):
        discover(study, directory, RATES_NANO, expected_packets)
    providers = {}
    costs = []
    for name in RATES_NANO:
        providers[name], totals = arm(study,name,packets,labels,freeze_at)
        costs.append(totals)
    held, usage, uncertain, exposure = map(sum, zip(*costs))
    check(exposure <= held <= USD_CAP_NANO, "Combined cap exceeded")
    return {
        "study":"Original two hosted configurations with 1,536 maximum output tokens. Supplemental experiments are outside this audit.",
        "freeze_commit":FREEZE, "freeze_manifest_sha256":FREEZE_SHA,
        "original_panel_sha256":PANEL_SHA,"original_local_results_sha256":LOCAL_RESULTS_SHA,
        "git_freeze_utc":freeze_at.isoformat() if freeze_at else None,
        "git_sequence":"Verified against this workstation's Git commit time" if freeze_at else "No hosted Git checkout available; manifest verified by digest",
        "original_public_prompts_identical":len(packets), "providers":providers,
        "combined":{"cap_usd":usd(USD_CAP_NANO),"reservations_usd":usd(held),"usage_peak_uncached_usd":usd(usage),
                    "unreconciled_reservations_usd":usd(uncertain),"capped_exposure_usd":usd(exposure)},
        "billing_interpretation":"Token-derived upper bound at the registered peak uncached or standard rates. Unknown charges retain their full reservations; these figures are not provider invoices."
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--study",type=Path,default=HERE)
    p.add_argument("--reference",type=Path,default=HERE.parent/"frozen-reader-study")
    p.add_argument("--output",type=Path)
    args = p.parse_args()
    data = audit(args.study,args.reference)
    dest = args.output or args.study/"verification.json"
    with NamedTemporaryFile("w",dir=dest.parent,delete=False,encoding="utf-8") as output:
        json.dump(data,output,indent=2)
        output.write("\n")
    Path(output.name).replace(dest)
    print(json.dumps(data["combined"],indent=2))
