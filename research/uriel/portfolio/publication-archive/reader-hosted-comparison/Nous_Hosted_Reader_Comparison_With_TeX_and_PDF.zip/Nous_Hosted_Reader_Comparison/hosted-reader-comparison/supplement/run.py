"""Execute the separately authorized DeepSeek nonthinking panel once."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
STUDY=HERE.parent
sys.path.insert(0,str(STUDY))
import run_hosted as original


def run():
    pins=json.loads((HERE/"FROZEN.json").read_bytes())
    for name, expected in pins.items():
        if hashlib.sha256((HERE/name).read_bytes()).hexdigest()!=expected:
            raise ValueError("Supplement freeze mismatch: "+name)
    packets=original.verify_freeze()
    reservation=original.RATES["deepseek"]
    scheduled_total=len(packets)*(2*reservation+original.RATES["openai"])
    if scheduled_total>original.CAP_MICRO_USD:
        raise RuntimeError("Total worst-case reservations exceed the study cap")
    attempts=HERE/"attempts/deepseek"
    returns=HERE/"responses/deepseek"
    attempts.mkdir(parents=True,exist_ok=True)
    returns.mkdir(parents=True,exist_ok=True)
    with (STUDY/"dispatch.lock").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        for p in packets:
            pid=p["packet"]
            j=attempts/(pid+".json")
            dest=returns/(pid+".json")
            if j.exists():
                if not dest.exists() or json.loads(dest.read_bytes())["status"] not in ("ok","invalid_output"):
                    raise RuntimeError("Unresolved or failed request; cannot redispatch "+pid)
                continue
            held=sum(json.loads(f.read_bytes())["reservation_micro_usd"] for side in (HERE,STUDY)
                     for f in (side/"attempts").glob("*/*.json"))
            if dest.exists() or held+reservation>original.CAP_MICRO_USD:
                raise RuntimeError("Dispatch cap or unique packet invariant violated")
            rec={"packet":pid,"started":original.now(),"prompt_sha256":p["prompt_sha256"],
                 "provider":"deepseek","reservation_micro_usd":reservation}
            with j.open("x") as out:
                json.dump(rec,out)
                out.flush()
                os.fsync(out.fileno())
            try:
                data={"packet":pid,"prompt":p["prompt"],"reasoning_effort":"off",
                      "max_output_tokens":1536,"model":"deepseek-flash"}
                proc=subprocess.run([str(HERE/"reader.sh"),"run"],input=json.dumps(data),text=True,
                                     stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=420)
                result=json.loads(proc.stdout)
                for key in ("status","content","provider","model","finish_reason","usage","wire_body_sha256",
                            "http_status","charged_request_sent","error_code"):
                    if key in result:
                        rec[key]=result[key]
                if result.get("status") in ("ok","returned") and result.get("http_status")==200:
                    actions=original.actions_from(result.get("content"))
                    rec["status"]="ok" if actions is not None else "invalid_output"
                    if actions is not None:
                        rec["actions"]=actions
            except Exception as exc:
                rec.update(status="transport_unknown",error_type=type(exc).__name__,charged_request_sent=None)
            rec["ended"]=original.now()
            original.write_receipt(dest,rec)
            print(rec["ended"],"deepseek-nonthinking",pid,rec["status"],flush=True)
            if rec["status"] not in ("ok","invalid_output"):
                raise RuntimeError("Operational stop at "+pid)
            usage=rec.get("usage") or {}
            if (usage.get("input_tokens") or 0)>4096 or (usage.get("output_tokens") or 0)>1536:
                raise RuntimeError("Usage exceeds frozen budget")


if __name__=="__main__":
    run()
