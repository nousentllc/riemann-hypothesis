"""Rebuild vector figures from the archived audit CSVs. Requires matplotlib."""
import argparse
import csv
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

INK = "#172F35"
MUTED = "#4E6668"
TEAL = "#006C69"
OCHRE = "#9E5A12"
PALE = "#E1ECE9"
GRID = "#CEDAD8"
SLATE = "#64797B"
LIGHT = "#F2F6F5"
LABELS = {"Llama": "Llama 3.2", "Qwen": "Qwen2.5", "GPT-OSS": "GPT-OSS",
          "DeepSeek-R1": "DeepSeek-R1*", "Sol High": "Sol High", "Flash High": "Flash High",
          "Flash off": "Flash off"}
TRANSITIONS = ["YN", "NY", "NA", "AN", "YY", "NN", "AA"]
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.labelcolor": INK, "text.color": INK,
    "xtick.color": MUTED, "ytick.color": MUTED, "pdf.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.spines.left": False, "axes.spines.bottom": False,
    "figure.facecolor": "white", "axes.facecolor": "white",
})


def read_table(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def save(fig, destination):
    fig.savefig(destination, metadata={"Creator": "Matplotlib", "CreationDate": None,
                                       "ModDate": None})
    plt.close(fig)


def grid_axis(ax, num_rows):
    ax.set_xlim(-3, 103)
    ax.set_ylim(num_rows - 0.5, -0.5)
    ax.set_xticks([0, 50, 100], ["0%", "50%", "100%"])
    ax.set_yticks([])
    ax.tick_params(axis="x", labelsize=7, length=0, pad=3)
    ax.set_axisbelow(True)
    ax.grid(axis="x", color=GRID, linewidth=0.55)


def interval(ax, row, lo, hi, denominator, color):
    start, stop = 100 * lo / denominator, 100 * hi / denominator
    if lo < hi:
        ax.plot([start, stop], [row, row], linewidth=2.4, color=color,
                alpha=0.65, solid_capstyle="butt")
        ax.plot([stop], [row], marker="|", color=color, markersize=8)
    ax.plot([start], [row], marker="o", color=color, markersize=4.8)


def column_header(fig, x, y, text):
    fig.text(x, y, text, fontsize=8.5, fontweight="bold", va="baseline")


def coverage(audit, out):
    scores = {r["reader"]: r for r in read_table(audit / "scores.csv")
              if r["family"] == "linear" and r["group"] == "primary"}
    fig = plt.figure(figsize=(6.3, 3.43))
    ypos, height = 0.24, 0.59
    labels = fig.add_axes([0.012, ypos, 0.21, height])
    axes = [fig.add_axes([0.233, ypos, 0.215, height]),
            fig.add_axes([0.655, ypos, 0.215, height])]
    text_axes = [fig.add_axes([0.455, ypos, 0.14, height]),
                 fig.add_axes([0.878, ypos, 0.116, height])]
    order = ["Llama", "Qwen", "GPT-OSS", "DeepSeek-R1", "Sol High", "Flash High", "Flash off"]
    for ax in [labels, *text_axes]:
        ax.set_ylim(len(order) - 0.5, -0.5)
        ax.axis("off")
    for ax in axes:
        grid_axis(ax, len(order))
    column_header(fig, 0.012, 0.885, "Reader")
    column_header(fig, 0.233, 0.885, "Guesses on ambiguity")
    column_header(fig, 0.655, 0.885, "Licensed settled answers")
    fig.text(0.233, 0.845, "162 scheduled rows", fontsize=7, color=MUTED)
    fig.text(0.655, 0.845, "109 scheduled rows", fontsize=7, color=MUTED)
    for i, reader in enumerate(order):
        row = scores[reader]
        counts = {k: int(row[k]) for k in row if len(k) == 3 and k[1] == "_"}
        n_amb = sum(v for k, v in counts.items() if k[0] == "A")
        n_signed = sum(v for k, v in counts.items() if k[0] in "YN")
        assert (n_amb, n_signed) == (162, 109)
        guessed = counts["A_Y"] + counts["A_N"]
        signed = counts["Y_Y"] + counts["N_N"]
        miss_amb = sum(counts["A_" + o] for o in "IU")
        miss_signed = sum(counts[t + "_" + o] for t in "YN" for o in "IU")
        labels.text(0, i, LABELS[reader], va="center", fontsize=7.9)
        for j, (lo, hi, den, shade) in enumerate([(guessed, guessed + miss_amb, n_amb, OCHRE),
                                                   (signed, signed + miss_signed, n_signed, TEAL)]):
            interval(axes[j], i, lo, hi, den, shade)
            text_axes[j].text(0, i, str(lo) if lo == hi else f"{lo}–{hi}",
                              color=shade, va="center", fontsize=8, fontweight="bold")
    for ax in [labels, *axes, *text_axes]:
        ax.axhline(3.5, color=GRID, lw=0.75)
    fig.text(0.012, 0.102, "Dots count explicit observed actions. Bars extend to the largest count allowed by missing rows.",
             fontsize=7.2, color=MUTED)
    fig.text(0.012, 0.044, "* Local R1 stopped after four unusable packets. Its ranges include the undispatched rows.",
             fontsize=7.2, color=MUTED)
    save(fig, out / "linear_coverage.pdf")


def conflict(audit, out):
    decisions = read_table(audit / "decisions.csv")
    flash = [r for r in decisions if r["family"] == "square" and r["reader"] == "Flash off"]
    sol = [r for r in decisions if r["family"] == "square" and r["reader"] == "Sol High"]
    assert len(flash) == len(sol) == 304 and all(r["target"] == r["answer"] for r in sol)
    fig = plt.figure(figsize=(6.3, 3.8))
    ax = fig.add_axes([.171, .195, .789, .655])
    ax.set_xlim(0, 100)
    ax.set_ylim(7.4, -.63)
    ax.set_xticks([0, 25, 50, 75, 100], ["0%", "25%", "50%", "75%", "100%"])
    ax.tick_params(axis="x", length=0, labelsize=7)
    ax.set_yticks([])
    fig.text(.018, .914, "Old → new", fontsize=8, fontweight="bold")
    fig.text(.186, .914, "Share of Flash (thinking off) actions within each transition", fontsize=8.3, fontweight="bold")
    for i, transition in enumerate(TRANSITIONS):
        y = i if i < 4 else i + .59
        old, new = transition
        rows = [r for r in flash if r["old"] == old and r["target"] == new]
        n = len(rows)
        colors = [TEAL, OCHRE, SLATE] if old != new else [TEAL, SLATE]
        counts = [sum(r["answer"] == new for r in rows)]
        if old != new:
            counts.append(sum(r["answer"] == old for r in rows))
        counts.append(n - sum(counts))
        ax.text(-3.7, y, f"{old} → {new}", va="center", ha="right", fontsize=9,
                color=INK, clip_on=False)
        start = 0.0
        for count, color in zip(counts, colors):
            if not count:
                continue
            width = 100 * count / n
            ax.barh(y, width, left=start, height=.64, color=color, edgecolor="white", lw=.55)
            ax.text(start + width / 2, y, str(count), color="white", fontsize=8,
                    fontweight="bold", va="center", ha="center")
            start += width
    ax.axhline(3.8, color=GRID, lw=.65)
    handles = [Patch(facecolor=c, edgecolor="none", label=label) for c, label in
               [(TEAL, "Square action"), (OCHRE, "Old action on conflicts"),
                (SLATE, "Other response")]]
    fig.legend(handles=handles, loc="lower left", bbox_to_anchor=(.147, .065), frameon=False,
               ncol=3, fontsize=7.2, handlelength=1.1, columnspacing=1.1)
    fig.text(.018, .035, "Numerals count observations. The last three rows are agreement controls.", fontsize=7.2, color=MUTED)
    save(fig, out / "rule_conflicts.pdf")


def enrichment(audit, out):
    census = read_table(audit / "census.csv")
    transitions = {}
    for unit in ("population", "eligible", "selected"):
        counter = Counter()
        for r in census:
            if r["unit"] == unit:
                counter[r["old"] + r["new"]] += int(r["count"])
        transitions[unit] = counter
    fig = plt.figure(figsize=(6.3, 3.85))
    fig.text(.017, .915, "Conflict share by sampling unit", fontsize=8.6, fontweight="bold")
    fig.text(.50, .915, "Coverage of eligible keys by transition", fontsize=8.6, fontweight="bold")
    left = fig.add_axes([.018, .11, .434, .76])
    left.set_xlim(0, 100)
    left.set_ylim(0, 3.55)
    left.axis("off")
    labels = ["Cutoff-specific questions", "Fresh semantic keys", "Administered records"]
    for k, unit in enumerate(("population", "eligible", "selected")):
        counter = transitions[unit]
        total = sum(counter.values())
        conflicts = sum(n for t, n in counter.items() if t[0] != t[1])
        pct = 100 * conflicts / total
        y = 3.10 - 1.14 * k
        left.text(0, y, labels[k], fontsize=8.1, fontweight="bold", va="center")
        left.barh(y - .31, 100, height=.13, color=PALE)
        left.barh(y - .31, pct, height=.13, color=OCHRE)
        left.text(0, y - .58, f"{conflicts:,} / {total:,}", color=MUTED, fontsize=7.2, va="center")
        left.text(100, y - .58, f"{pct:.2f}%", ha="right", color=OCHRE,
                  fontsize=7.9, fontweight="bold", va="center")
    right = fig.add_axes([.598, .162, .213, .688])
    right.set_xlim(-2, 102)
    right.set_ylim(6.6, -.63)
    right.set_xticks([0, 100], ["0%", "100%"])
    right.tick_params(axis="x", length=0, pad=2, labelsize=7)
    right.set_yticks([])
    for i, t in enumerate(TRANSITIONS):
        selected, eligible = transitions["selected"][t], transitions["eligible"][t]
        pct = 100 * selected / eligible
        right.plot([0, 100], [i, i], color=PALE, lw=3.3, solid_capstyle="round")
        right.plot([0, pct], [i, i], color=TEAL, lw=3.3, solid_capstyle="round")
        right.plot(pct, i, marker="o", color=TEAL, ms=3.6)
        right.text(-8, i, " → ".join(t), ha="right", va="center", fontsize=7.4, clip_on=False)
        right.text(115, i, f"{selected} / {eligible:,}", fontsize=7.2, va="center", clip_on=False)
    fig.add_artist(Line2D([.474,.474],[.115,.865], transform=fig.transFigure, color=GRID, lw=.65))
    fig.text(.018, .053, "A fresh key combines the tag, full residue list, modulus and query. One cutoff was displayed per selected key.",
             color=MUTED, fontsize=7.2)
    save(fig, out / "panel_enrichment.pdf")


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", type=Path, default=here.parent / "audit")
    parser.add_argument("--out", type=Path, default=here)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    coverage(args.audit, args.out)
    conflict(args.audit, args.out)
    enrichment(args.audit, args.out)


if __name__ == "__main__":
    main()
