# When a Saved Record Justifies an Answer

**Justin Candler · Nous Independent Research · 23 November 2026**

Start with the PDF. The single LuaLaTeX source contains its own Nous PNG, vector figures and bibliography. No external chapter or image is needed to compile it. The paper synthesizes the three model studies completed after the flagship editorial, including the stopped local arm, the original hosted comparison, its outcome-informed supplement and the full quadratic transfer study. The earlier finite writer and trained-tree experiments supply the mathematical and empirical baseline.

## What the evidence supports

Sol High gave the action licensed by the record on 304/304 linear and 304/304 quadratic observations. These presentations contain 170 and 304 distinct mathematical keys respectively. On the quadratic panel, DeepSeek Flash with thinking off gave 117/304 licensed actions and made 68 unsupported definitive assertions on 100 ambiguous records. Constant N would match the historical rule on 144/240 conflicts compared with Flash's 140/240. The post-run audit also finds responses that vary across mathematically equivalent presentations. The paper gives individual examples, signed error counts and missing-response bounds.

## Contents

- The root PDF and TeX are the finished manuscript and its standalone source.
- The **evidence** directory holds all three original experiment ZIPs, including protocols, model settings, public completions and Git history bundles. Its **antecedents** directory holds the programs and a pinned arithmetic fixture from the earlier CPU studies.
- The **audit** directory holds a fresh offline reconstruction from the three ZIPs, complete decision and witness tables, and the post-run diagnostics. Its README defines the columns.
- The **figures** directory holds the editable chart-generation script and its three vector exhibits.
- **SHA256SUMS** authenticates the files in the paper snapshot. The outer ZIP also contains a Git history bundle for this manuscript. The study ZIPs preserve each study's own history.

## Reproduce the findings

From the extracted package root, run the following with Python 3 and Git available. The first two commands perform no network requests and generate no model inference.

~~~sh
python3 -B evidence/antecedents/replay.py
python3 -B audit/replay.py evidence --output replayed
~~~

Compare the seven generated CSV/JSON tables in the destination with the corresponding files under **audit**. The expected ledger covers nine study-by-configuration arms, 308 dispatched packets and 2,736 scheduled row slots. The 34 unrun packets belong to local DeepSeek-R1. Historical CPU replay should match six archived JSON results byte for byte and pass six original unit tests. The ZIP digests verified by the cross-study replay are pinned in its source. To redraw the charts with Matplotlib installed, run the following.

~~~sh
python3 figures/plot.py --out redrawn
~~~

To rebuild the paper, copy the single TeX file to a writable directory and run LuaLaTeX twice there. A current TeX Live distribution with Latin Modern, fontspec, booktabs and the other packages listed in the preamble is sufficient. The release used LuaHBTeX 1.24.0 (TeX Live 2026). To recover the local manuscript history, clone the included paper-history.bundle with Git.

The source-study histories are local registrations. The paper combines two related finite question panels, one generation per packet and a fixed presentation order. The provider usage figures are token-based upper bounds at registered rates. This synthesis ran no new model generations or Lean build.

