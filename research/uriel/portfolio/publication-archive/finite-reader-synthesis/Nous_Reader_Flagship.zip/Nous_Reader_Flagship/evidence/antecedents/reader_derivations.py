"""Verify the manuscript's held-out response profiles, exact query risks and raw decision rule.

Run with Python 3.9+ and one positional argument, the frozen changing-cutoff-reader/results.json.
Only the standard library is required. The JSON file must match the original study digest.
"""
import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path


def modulus(cutoff):
    value = 1
    band = 0
    while value * 3 <= cutoff:
        value *= 3
        band += 1
    return value * 3, band


def truth(center, cutoff, weight):
    m, _ = modulus(cutoff)
    return (center - weight) % m == 0


def read(tree, record, cutoff, weight):
    digits = 0
    while digits < 4 and (record - weight) % (3 ** (digits + 1)) == 0:
        digits += 1
    features = {"tag": record, "cutoff": cutoff, "weight": weight,
                "power_band": modulus(cutoff)[1], "matching_digits": digits}
    while isinstance(tree, list):
        name, boundary, left, right = tree
        tree = left if features[name] <= boundary else right
    return tree


def check(results_path):
    raw = results_path.read_bytes()
    if sha256(raw).hexdigest() != "2de65ff566b1a3748708e97b89a02b14c2af2ab98342d2392b7bdba68d3682ee":
        raise ValueError("Expected the original frozen changing-cutoff-reader results.")
    result = json.loads(raw)
    centers = tuple(range(81))
    empty_fiber = (0, *range(65, 81))
    all_questions = tuple((z, e) for z in result["test_cutoffs"] for e in range(1, z + 1))
    two_cuts = tuple((z, e) for z in (26, 64) for e in range(1, z + 1))
    profiles = {tuple(truth(s, z, e) for z, e in two_cuts) for s in centers}
    if len(profiles) != 81:
        raise ValueError("The two-cutoff alphabet lower bound failed.")
    totals = Counter()
    for z, e in all_questions:
        boundary = z in (24, 25, 26)
        ambiguous = boundary and e >= 11
        truth_yes = {s for s in centers if truth(s, z, e)}
        expected_yes = {e, e + 27, e + 54} if boundary else {e}
        if truth_yes != expected_yes:
            raise ValueError((z, e, "truth profile"))
        yes = sum(s in truth_yes for s in empty_fiber)
        if min(yes, len(empty_fiber) - yes) != int(ambiguous):
            raise ValueError((z, e, "Bayes error"))
        totals["boundary_queries"] += boundary
        totals["ambiguous_observations"] += ambiguous
        totals["writer_floor_terminal"] += min(yes, len(empty_fiber) - yes)
        for channel, record in (("terminal_list", lambda s: s if s <= 64 else 0),
                                ("residue", lambda s: s)):
            for name in ("informed_support", "informed_truth"):
                tree = result["channels"][channel]["trees"][name]
                outputs = {s: read(tree, record(s), z, e) for s in centers}
                if any(label != ("yes" if s == e else "no") for s, label in outputs.items()):
                    raise ValueError((z, e, channel, name, "equality-only prediction"))
                errors = sum((label == "yes") != (s in truth_yes) for s, label in outputs.items())
                if errors != 2 * boundary:
                    raise ValueError((z, e, "pointwise risk"))
                totals[channel + "_" + name + "_mistakes"] += errors
    n = len(centers) * len(all_questions)
    return {"queries": len(all_questions), "center_query_pairs": n,
            "two_cutoff_profiles": len(profiles), "counts": dict(totals),
            "uniform_fitted_risk": str(Fraction(2 * totals["boundary_queries"], n)),
            "uniform_terminal_floor": str(Fraction(totals["writer_floor_terminal"], n)),
            "uniform_residue_floor": "0"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    args = parser.parse_args()
    print(json.dumps(check(args.results), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
