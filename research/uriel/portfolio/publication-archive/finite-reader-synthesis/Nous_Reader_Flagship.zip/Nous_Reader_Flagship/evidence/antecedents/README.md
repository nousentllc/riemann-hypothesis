# Earlier finite reader experiments

These are antecedents to the two panels on which the language models were evaluated. From this directory, run `python3 -B replay.py` using Python 3.9+ and Git with SHA-1 support. The replay verifies the source manifest, restores the original 2,415-byte arithmetic fixture in a temporary bare repository, reproduces six archived JSON outputs byte for byte and runs the six original pilot unit tests. All writes are confined to a temporary directory. It uses no network, model, package downloads or Lean installation.

| Input or program | What it establishes here |
|---|---|
| `source/weights.json` | The 81 terminal lists for designated residues at cutoff 64. The adjacent 3 KB Git pack holds exactly eight objects, the original commit, six trees along the named path and the fixture blob. Git verifies the path through the actual commit. |
| `slot3-witness-memory/benchmark.py` | Compares the archived lists to strict valuation tests. Recounts storage and coverage for zero through four observed digits, query-dependent tag bounds and identity controls. |
| `slot3-witness-memory/allocation/allocation.py` | Enumerates the optimum for 27 tags and evaluates the explicit construction, including small-population brute-force controls. |
| `research-assessment/check_cutoffs.py` | Antecedent cutoff census. The frozen trainer authenticates its file digest. |
| `changing-cutoff-reader/run.py` and `test_reader.py` | Refit six depth-limited trees on the historical training cutoffs and score the held-out state–query pairs. Tests check the split, strict arithmetic oracle and source fixture. |
| `changing-cutoff-reader/audit_guard.py` | Reinterprets the frozen trees and compares exact and rotated abstention guards on the identical holdout. This addendum followed the original protocol. |
| `reader_derivations.py` | Checks the observed prediction law on held-out data, the two-cutoff fingerprint and the binary error decomposition. |
| `witness_distinctions.py` | Recomputes every two-way refinement of the 17-state empty terminal cell. The earlier compound report's original script also computes an orbit control, which plays no role in the reader scores. |

The archival computations, protocols and expected outputs are copied without changes. Only this guide, the manifest, the temporary replay wrapper and the compact Git path packaging were prepared for this release. `SHA256SUMS` covers all files in this directory except itself. A Git object path identifies the original mathematical fixture. The eight objects do not contain the full Git history or a build of the proof.

*Which distinctions must a witness preserve?* (22 November 2026) assembled the trained trees, guard and refinement results. The 23 November editorial assessment following *The fixed cyclotomic slot at seven* proposed the new common-record model tests. The older arithmetic and model results have separate scopes. The designated-center fixture gives no procedure for recovering a center chosen by existence in the source proof. [Pinned source fixture](https://github.com/nousentllc/riemann-hypothesis/blob/4b1c9fbbfb9bc50a3f791c2c1f3d7f2adb336c87/research/uriel/experiments/slot-three/results/weights.json)
