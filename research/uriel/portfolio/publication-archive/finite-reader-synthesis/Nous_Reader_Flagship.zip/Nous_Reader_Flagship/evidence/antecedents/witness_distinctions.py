"""Exact post-hoc controls for the revised retained-host and reader manuscript."""
from collections import Counter
from fractions import Fraction
from itertools import combinations
from math import comb
import json


def placements():
    even = range(0, 16, 2)
    odd = range(1, 16, 2)

    def pairs(points):
        return sum((t + 2) % 16 in points for t in points)

    groups = [frozenset(a + b) for a in combinations(even, 4) for b in combinations(odd, 3)]
    distribution = Counter(pairs(points) for points in groups)
    assert all(pairs(points) == pairs({(t + 2) % 16 for t in points}) for points in groups)
    assert all(sum((-1)**t for t in points) == 1 for points in groups)
    assert len(groups) == comb(8, 4)*comb(8, 3) == 3920
    assert pairs(set(range(7))) == 5 and pairs({0, 4, 8, 12, 1, 5, 9}) == 0
    assert distribution[0] == 32 and distribution[5] == 64
    mean = Fraction(sum(k*v for k, v in distribution.items()), len(groups))
    assert mean == Fraction(18, 7)
    return {"sets": len(groups), "directed_pairs_by_count": dict(sorted(distribution.items())),
            "mean": str(mean), "quotient_parity_sum": 1}


def empty_fiber_questions():
    centers = (0, *range(65, 81))
    cutoffs = (*range(24, 30), *range(59, 65))
    frequencies = Counter({s: 0 for s in centers})
    singleton_answers = []
    for z in cutoffs:
        modulus = 3
        while modulus <= z:
            modulus *= 3
        for e in range(1, z + 1):
            yes = {s for s in centers if (s-e) % modulus == 0}
            if yes:
                assert len(yes) == 1
                s, = yes
                frequencies[s] += 1
                singleton_answers.append(s)
    assert sorted(frequencies.values()) == [0, 1, 2] + [3]*14
    return centers, frequencies, singleton_answers


def shapes(total, parts, smallest=1):
    if parts == 1:
        if total >= smallest:
            yield (total,)
        return
    for size in range(smallest, total//parts + 1):
        for tail in shapes(total-size, parts-1, size):
            yield (size,) + tail


def counts(group_sizes, weights):
    start = 0
    forced_errors = ambiguous = 0
    for size in group_sizes:
        if size > 1:
            questions = sum(weights[start:start+size])
            forced_errors += questions
            ambiguous += size*questions
        start += size
    return forced_errors, ambiguous


def efficient(points):
    best = float("inf")
    frontier = []
    for error, ambiguous in sorted(set(points)):
        if ambiguous < best:
            frontier.append((error, ambiguous))
            best = ambiguous
    return frontier


def refinements():
    centers, weights, singleton_answers = empty_fiber_questions()
    ordered_weights = sorted(weights.values(), reverse=True)
    report = {}
    for k in range(1, 18):
        by_cost = {}
        for shape in shapes(17, k):
            key = counts(shape, ordered_weights)
            by_cost.setdefault(key, shape)
        report[k] = [{"unavoidable_binary_errors": p[0], "ambiguous_state_queries": p[1],
                      "one_optimal_shape": by_cost[p]} for p in efficient(by_cost)]
    # Separate enumeration of all unlabeled two-cell partitions, fixing center 0 in cell one.
    # Bit masks select which of the remaining 16 centers belong to that cell.
    direct = set()
    for mask in range(2**16-1):
        first = {0} | {s for bit, s in enumerate(centers[1:]) if mask & (1 << bit)}
        group_sizes = {s: len(first) if s in first else 17-len(first) for s in centers}
        nonconstant = [group_sizes[s] for s in singleton_answers if group_sizes[s] > 1]
        direct.add((len(nonconstant), sum(nonconstant)))
    assert efficient(direct) == [(r["unavoidable_binary_errors"], r["ambiguous_state_queries"]) for r in report[2]]
    assert report[1][0]["ambiguous_state_queries"] == 765
    assert report[17][0]["ambiguous_state_queries"] == 0
    return {"cutoffs": [24,25,26,27,28,29,59,60,61,62,63,64], "empty_centers": list(centers),
            "singleton_question_frequencies": dict(weights), "all_unlabeled_two_cell_partitions": 65535,
            "pareto_by_number_of_empty_fiber_labels": report}


def main():
    print(json.dumps({"placement": placements(), "refinement": refinements()}, indent=2))


if __name__ == "__main__":
    main()
