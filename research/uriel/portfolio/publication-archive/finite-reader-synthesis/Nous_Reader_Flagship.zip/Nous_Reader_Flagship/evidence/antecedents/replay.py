"""Reproduce the paper's antecedent computations using a temporary, offline workspace."""
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE_COMMIT = "4b1c9fbbfb9bc50a3f791c2c1f3d7f2adb336c87"
SOURCE_PATH = "research/uriel/experiments/slot-three/results/weights.json"


def verify_manifest():
    for line in (ROOT / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        if sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"Archived item differs from the manifest: {name}")


def run_replay():
    verify_manifest()
    with tempfile.TemporaryDirectory(prefix="nous-reader-prior-") as temp:
        work = Path(temp)
        study = work / "evidence"
        shutil.copytree(ROOT, study)
        repo = work / "riemann-experiments"
        subprocess.run(["git", "init", "--bare", "--quiet", "--object-format=sha1", str(repo)], check=True)
        git = ["git", "-C", str(repo)]
        with (study / "source" / "slot-three-path.pack").open("rb") as packed:
            subprocess.run(git + ["unpack-objects", "-q"], stdin=packed, check=True)
        original = subprocess.check_output(git + ["cat-file", "blob", f"{SOURCE_COMMIT}:{SOURCE_PATH}"])
        if original != (study / "source" / "weights.json").read_bytes():
            raise ValueError("The readable fixture differs from the archived Git path")
        print("Recovered the original slot-three fixture at the pinned commit")
        pilot = study / "changing-cutoff-reader"
        writer = study / "slot3-witness-memory"
        tasks = [
            (writer, ["benchmark.py", "--repo", str(repo)], "results.json"),
            (writer / "allocation", ["allocation.py", "--repo", str(repo)], "results.json"),
            (pilot, ["run.py"], "results.json"),
            (pilot, ["audit_guard.py"], "audit_guard.json"),
            (study, ["reader_derivations.py", "changing-cutoff-reader/results.json"], "reader_derivations.json"),
            (study, ["witness_distinctions.py"], "witness_distinctions.json"),
        ]
        python = [sys.executable, "-E", "-B"]
        for directory, args, expected in tasks:
            actual = subprocess.check_output(python + args, cwd=directory)
            if actual != (directory / expected).read_bytes():
                raise ValueError(f"The new output differs from {directory.name}/{expected}")
            print(f"{args[0]}: byte-identical {expected}")
        subprocess.run(python + ["-m", "unittest", "-v", "test_reader"], cwd=pilot, check=True)


if __name__ == "__main__":
    run_replay()
