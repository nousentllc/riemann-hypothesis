# Audit of the two reader panels

Use Python 3 and a directory holding the three original archives named in `replay.py`. The analysis runs offline. In the paper package, run the following from the folder containing this audit and the evidence archives.

```sh
python3 audit/replay.py evidence --output replayed
```

The replay checks each archive against its SHA-256 digest, the 76 distinct packet prompts against their stored digests, each printed row against the saved fields, and the absence of shared semantic keys between the square panel and the historical linear records. The original six writers give 127 distinct tag and residue-set combinations. The replay derives their full transfer design census from their mappings, then scans every compatible integer to reconstruct the licensed actions on both measured panels. For each scheduled reader–packet it aligns public final text with the request journal, applies the eight-action validity rule, checks the observed action codes, and prices reported hosted usage at the frozen peak uncached tariffs. This is a consistency check on saved local records. SHA-256 and local Git do not independently attest the provider’s identity or a historical timestamp.

## Outputs

- `decisions.csv` contains one row per scheduled reader–observation. The two mathematical panels have 608 unique panel observations in total. Conditional on a panel, the same observation repeats for each assigned reader. Every row lists its finite witness counts, and the smallest compatible integer in each nonempty truth class.
- `scores.csv` contains one confusion matrix per family, group and reader. In a name such as `A_N`, the first letter is the license and the second is the returned decision. I denotes a finalized invalid response. U denotes an undispatched packet. The guess upper bound assigns every ambiguous I or U a hypothetical definite response. The final field averages hidden-truth agreement over explicit guesses under a uniform conditional distribution on each observation’s compatible integers. A blank indicates no observed guesses.
- `strata.csv` repeats those totals separately by modulus, singleton status, and source of ambiguity. Strata across different dimensions overlap.
- `administration.csv` lists packet dispositions and hosted token counts. USD equals the nanodollar field divided by one billion. Local inference incurred zero paid API fees. Unreported billing fields for local readers are blank.
- `census.csv` tabulates the old and new oracle labels by modulus. Population counts each public cutoff-specific question, eligible counts distinct fresh keys after removing historical keys, and selected counts the 304 administered transfer questions. Only the selected sample has model outputs.
- `semantic_repeats.csv` groups linear observations with identical tag, residues, effective modulus and query. A repeated key has at least two different cutoff renderings. A differing-answer key has at least two valid, distinct explicit actions. The 304 linear records reduce to 170 effective keys. The transfer design supplies 304 additional effective keys. Packet position and neighboring rows can also vary across appearances.
- `diagnostics.json` gives the exploratory constant-N comparison and the old-action marginal reference within conflict strata. The permutation reference describes hypothetical rearrangements with the same returned action counts. There is no independence assumption or significance test. Conditioning on the new target, effective modulus, and singleton status leaves exactly one old target per observed conflict stratum.

All count comparisons are finite-panel statements. A provider receipt supplies the model's reported public text and usage. Running this script does not perform new inference or reproduce provider generation.
