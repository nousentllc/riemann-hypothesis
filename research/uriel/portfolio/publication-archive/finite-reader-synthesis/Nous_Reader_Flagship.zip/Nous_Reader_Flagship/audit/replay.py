#!/usr/bin/env python3
"""Offline replay of paper tables from the three frozen ZIPs, using only Python 3."""
import argparse
import csv
import hashlib
import io
import json
import zipfile
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
PINS = {
    "local": ("Nous_Frozen_Reader_Challenge", "36239d4d27033febaabe4c2d606f2327c0a60ee4cba3fc7f49075ca0f6b936af"),
    "hosted": ("Nous_Hosted_Reader_Comparison", "2afa5c8afe834b64a2952653a334b807dc5632234c98eb0bb3019be2ea07ed66"),
    "transfer": ("Nous_Square_Rule_Transfer", "ba3c9f78b2705ddd3ac6d3b4797e9777e467e622e5b4a81b050f984e506d325e"),
}
ARM = [
    ("linear", "local", "", "llama32", "Llama"), ("linear", "local", "", "qwen25", "Qwen"),
    ("linear", "local", "", "gptoss20", "GPT-OSS"), ("linear", "local", "", "deepseek8", "DeepSeek-R1"),
    ("linear", "hosted", "hosted-reader-comparison/", "openai", "Sol High"),
    ("linear", "hosted", "hosted-reader-comparison/", "deepseek", "Flash High"),
    ("linear", "hosted", "hosted-reader-comparison/supplement/", "deepseek", "Flash off"),
    ("square", "transfer", "reader-rule-transfer/", "openai", "Sol High"),
    ("square", "transfer", "reader-rule-transfer/", "deepseek", "Flash off"),
]
ALPHABET = ("Y", "N", "A")


def check(test, message):
    if not test:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Sources:
    def __init__(self, folder):
        self.files = {}
        for study, (name, sha) in PINS.items():
            data = (folder / (name + ".zip")).read_bytes()
            check(digest(data) == sha, "Archive hash mismatch: " + name)
            self.files[study] = zipfile.ZipFile(io.BytesIO(data))

    def member(self, study, path):
        name = f"{PINS[study][0]}/{path}"
        return self.files[study].read(name)

    def obj(self, study, path):
        return json.loads(self.member(study, path))

    def exists(self, study, path):
        return f"{PINS[study][0]}/{path}" in self.files[study].NameToInfo


def packet_prompts(sources, panel, family):
    study, path = ("hosted", "hosted-reader-comparison") if family == "linear" else ("transfer", "reader-rule-transfer")
    public = {x["packet"]: x for x in map(json.loads, sources.member(study, path + "/public_packets.jsonl").splitlines())}
    check(set(public) == {p["id"] for p in panel["packets"]}, "Unmatched public packets")
    by_id = {r["id"]: r for r in panel["rows"]}
    seen = []
    for pkt in panel["packets"]:
        text = public[pkt["id"]]["prompt"]
        sha = digest(text.encode())
        check(sha == pkt["prompt_sha256"] == public[pkt["id"]]["prompt_sha256"], "Prompt hash mismatch")
        if family == "linear":
            check(pkt["prompt"] == text, "Hosted and local user prompts differ")
        rendered = text.split("Rows (tag, R, Z, e):\n", 1)[1].splitlines()
        check(len(rendered) == len(pkt["rows"]) == 8, "Incorrect packet size")
        for pos, (line, key) in enumerate(zip(rendered, pkt["rows"]), 1):
            row = by_id[key]
            expected = f"{pos}. tag={row['tag']}, R={row['residues']}, Z={row['z']}, e={row['e']}"
            check(expected == line, "Public observation differs from saved panel")
            seen.append(key)
    check(len(seen) == len(set(seen)) == len(by_id) == 304, "Packet coverage differs from panel")


def label(yes, total):
    return "N" if yes == 0 else "Y" if yes == total else "A"


def derive(row, family):
    rset = row["residues"]
    e, z = row["e"], row["z"]
    m = 1
    while m <= z:
        m *= 3
    check(1 <= e <= z and rset and len(set(rset)) == len(rset) and all(0 <= r < 81 for r in rset), "Bad support")
    states = [s for s in range(243) if s % 81 in rset]
    lin = [s for s in states if (s - e) % m == 0]
    yes = [s for s in states if (s * s - e) % m == 0] if family == "square" else lin
    ys = set(yes)
    no = [s for s in states if s not in ys]
    target, old = label(len(ys),len(states)), label(len(lin),len(states))
    if family == "square":
        check((len(lin), old, len(yes), len(no), target) ==
              (row["old_yes"],row["old_action"],row["new_yes"],row["new_no"],row["new_action"]), "Quadratic oracle mismatch")
    else:
        check((len(yes), len(no), target) == (row["yes"], row["no"], row["action"]), "Linear oracle mismatch")
    groups = [sum(r + 81*k in ys for k in range(3)) for r in rset]
    if target != "A":
        source = "settled"
    elif not any(count in (1,2) for count in groups):
        source = "between-uniform-triples"
    elif all(count in (1,2) for count in groups):
        source = "all-triples-split"
    else:
        source = "mixed-split-and-uniform"
    return {"id":row["id"], "z":z, "e":e, "tag":row["tag"], "residues":" ".join(map(str,rset)),
            "m":m, "width":len(rset), "old":old, "target":target, "yes":len(yes), "no":len(no),
            "yes_witness":min(yes, default=""), "no_witness":min(no, default=""), "ambiguity":source}


def parse_content(text):
    try:
        obj = json.loads(text)
        if isinstance(obj, dict) and set(obj) == {"actions"}:
            a = obj["actions"]
            if isinstance(a,list) and len(a) == 8 and all(x in ALPHABET for x in a):
                return a
    except (TypeError, ValueError):
        pass
    return ["I"] * 8


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def census(panels):
    """Derive the 127 tag/record cells by applying each writer to all 81 residues."""
    by_writer = defaultdict(list)
    for r in range(81):
        term = r if 1 <= r <= 64 else 0
        opt = term if term <= 11 else 12 + (r - 12)//3 if r <= 32 else 19 + (r - 33)//4
        codes = (r%27, opt, term, 65 if r == 65 else term, 65 if 65 <= r <= 72 else term, r)
        for writer,tag in enumerate(codes):
            by_writer[writer,tag].append(r)
    cells = {(tag,tuple(rs)) for (_,tag),rs in by_writer.items()}
    previous = {(r["tag"],tuple(r["residues"]),81 if r["z"]<81 else 243,r["e"]) for r in panels["linear"]["rows"]}
    new = panels["square"]
    counts = defaultdict(Counter)
    for tag,rs in cells:
        support = [s for s in range(243) if s%81 in rs]
        for m in (81,243):
            old_mass = Counter(s%m for s in support)
            new_mass = Counter(s*s%m for s in support)
            cutoffs = [z for z in new["cutoffs"] if (81 if z<81 else 243)==m]
            for e in range(1,max(cutoffs)+1):
                tr = label(old_mass[e],len(support)) + label(new_mass[e],len(support))
                counts["population",m][tr] += sum(e<=z for z in cutoffs)
                if (tag,rs,m,e) not in previous:
                    counts["eligible",m][tr] += 1
    for row in new["rows"]:
        counts["selected",row["modulus"]][row["old_action"]+row["new_action"]] += 1
    output = []
    for (unit,modulus),counts_by_transition in sorted(counts.items()):
        for left in ALPHABET:
            for right in ALPHABET:
                transition = left+right
                n = counts_by_transition[transition]
                check(n==new[unit+"_census"][str(modulus)][transition],"Census mismatch")
                output.append({"unit":unit,"m":modulus,"old":left,"new":right,"count":n})
    check(len(cells)==new["public_codebook_cells"]==127,"Codebook count mismatch")
    return output


def build(sources):
    panels = {"linear":sources.obj("local", "frozen/panel.json"), "square":sources.obj("transfer","reader-rule-transfer/panel.json")}
    rows = {}
    for family,panel in panels.items():
        packet_prompts(sources,panel,family)
        rows[family] = {r["id"]:derive(r,family) for r in panel["rows"]}
    keys = lambda family: [(r["tag"],r["residues"],r["m"],r["e"]) for r in rows[family].values()]
    check(len(set(keys("square"))) == 304 and set(keys("square")).isdisjoint(keys("linear")), "Semantic overlap")
    decisions, administration = [], []
    for family, study, prefix, reader, name in ARM:
        count = Counter()
        for pkt in panels[family]["packets"]:
            p = pkt["id"]
            path = f"{prefix}responses/{reader}/{p}.json"
            att = f"{prefix}attempts/{reader}/{p}" + (".1.json" if study == "local" else ".json")
            journaled = sources.exists(study,att)
            if sources.exists(study,path):
                receipt = sources.obj(study,path)
                check(journaled and receipt["packet"] == p and receipt["prompt_sha256"] == pkt["prompt_sha256"], "Receipt mismatch")
                actions = parse_content(receipt.get("content"))
                check(actions == receipt.get("actions",["I"]*8),"Raw final and saved actions differ")
                count["dispatches"] += 1
                count["valid_packets" if actions[0] != "I" else "invalid_packets"] += 1
                if study != "local":
                    usage = receipt["usage"]
                    ni,no = usage["input_tokens"], usage["output_tokens"]
                    rate_in,rate_out = (2000,10000) if reader == "openai" else (300,1200)
                    count.update(input_tokens=ni,output_tokens=no,cost_nanodollars=ni*rate_in+no*rate_out)
            else:
                check(not journaled, "Reserved, unresolved packet")
                actions = ["U"]*8
                count["unrun_packets"] += 1
            for i,(key,action) in enumerate(zip(pkt["rows"],actions),1):
                row = rows[family][key]
                group = "calibration" if family == "linear" and row["z"] == 64 else "primary"
                decisions.append(dict(family=family,group=group,reader=name,packet=p,position=i,**row,answer=action))
        administration.append({"family":family,"reader":name,**count})
    return decisions, administration, census(panels)


def summarize(raw):
    arms = defaultdict(list)
    for row in raw:
        arms[row["family"],row["group"],row["reader"]].append(row)
    summaries, subgroups = [], []
    for (fam,group,arm), records in arms.items():
        scopes = defaultdict(list)
        for r in records:
            for key in ["all",f"m={r['m']}","R-single" if r["width"]==1 else "R-multiple",r["ambiguity"]]:
                scopes[key].append(r)
        for scope,subset in scopes.items():
            c = Counter((r["target"],r["answer"]) for r in subset)
            guesses = c["A","Y"] + c["A","N"]
            invalid_a = c["A","I"] + c["A","U"]
            line = dict(family=fam,group=group,reader=arm,scope=scope,n=len(subset),
                        **{a+"_"+b:c[a,b] for a in ALPHABET for b in ("Y","N","A","I","U")},
                        exact=sum(c[x,x] for x in ALPHABET),guesses=guesses,guess_upper=guesses+invalid_a)
            guessed = [r for r in subset if r["target"]=="A" and r["answer"] in ("Y","N")]
            hidden_credit = sum((Fraction(r["yes"] if r["answer"]=="Y" else r["no"],r["yes"]+r["no"])
                                 for r in guessed), Fraction(0))
            line["conditional_uniform_hidden_agreement_on_guesses"] = str(hidden_credit/len(guessed)) if guessed else ""
            if scope=="all":
                summaries.append(line)
            else:
                subgroups.append(line)
    return summaries,subgroups


def derivative_analysis(raw):
    t = [r for r in raw if r["reader"]=="Flash off" and r["family"]=="square"]
    compare = Counter()
    for r in t:
        x,y = r["answer"]==r["target"], r["target"]=="N"
        compare["both" if x and y else "only_flash" if x else "only_constant_N" if y else "neither"]+=1
    conflict = [r for r in t if r["old"] != r["target"]]
    def partition(key):
        groups = defaultdict(list)
        for r in conflict:
            groups[tuple(k(r) for k in key)].append(r)
        output, expected = [], Fraction(0)
        for group, members in sorted(groups.items()):
            old = Counter(r["old"] for r in members)
            action = Counter(r["answer"] for r in members)
            weighted = Fraction(sum(old[k]*action[k] for k in ALPHABET),len(members))
            output.append({"stratum":list(group),"n":len(members),"old_actions":dict(old),"returned":dict(action),
                           "old_matches":sum(r["old"]==r["answer"] for r in members),"marginal_reference":str(weighted)})
            expected += weighted
        return {"old_match_expected_under_within_stratum_permutation":str(expected),"strata":output}
    key = [lambda r:r["target"],lambda r:r["m"]]
    return {"classification":"exploratory fixed-panel descriptions; no hypothesis test",
            "square_flash_vs_constant_N":dict(compare),
            "constant_N_new_matches_on_conflicts":sum(r["target"]=="N" for r in conflict),
            "constant_N_old_matches_on_conflicts":sum(r["old"]=="N" for r in conflict),
            "flash_new_matches_on_conflicts":sum(r["target"]==r["answer"] for r in conflict),
            "flash_old_matches_on_conflicts":sum(r["old"]==r["answer"] for r in conflict),
            "target_modulus":partition(key),"target_modulus_width":partition(key+[lambda r:"singleton" if r["width"]==1 else "multiple"])}


def semantic_repeats(raw):
    """Compare valid replies at distinct cutoffs that denote the same arithmetic question."""
    groups = defaultdict(list)
    for row in raw:
        if row["family"]=="linear":
            for subset in (["full","primary"] if row["group"]=="primary" else ["full"]):
                groups[subset,row["reader"]].append(row)
    totals = []
    for (subset,reader),rows in groups.items():
        by_key = defaultdict(list)
        for r in rows:
            by_key[r["tag"],r["residues"],r["m"],r["e"]].append(r)
        repeated = [group for group in by_key.values() if len(group)>1]
        accessible = []
        for repeated_rows in repeated:
            check(len(set(r["target"] for r in repeated_rows))==1,"Semantic key has multiple target labels")
            check(len(set(r["z"] for r in repeated_rows))==len(repeated_rows),"Duplicate cutoff for a semantic key")
            valid = [r["answer"] for r in repeated_rows if r["answer"] in ALPHABET]
            if len(valid)>=2:
                accessible.append(valid)
        totals.append({"subset":subset,"reader":reader,"distinct_rows":len(rows),"distinct_semantic_keys":len(by_key),
                       "repeated_keys":len(repeated),"rows_in_repeated_keys":sum(map(len,repeated)),
                       "keys_with_two_or_more_valid_actions":len(accessible),
                       "keys_with_different_observed_actions":sum(len(set(a))>1 for a in accessible)})
    return totals


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("archive_directory",type=Path,help="directory containing the three original named ZIPs")
    p.add_argument("--output",type=Path,default=HERE,help="destination for output CSVs and diagnostics.json")
    args = p.parse_args()
    raw,admin,census_rows = build(Sources(args.archive_directory))
    complete,strata = summarize(raw)
    interpretation = derivative_analysis(raw)
    check(sum(a.get("dispatches",0) for a in admin)==308, "Dispatch accounting differs")
    check(sum(a.get("cost_nanodollars",0) for a in admin)==288491200, "Cost accounting differs")
    check(all(len(bin_["old_actions"])==1 for bin_ in interpretation["target_modulus_width"]["strata"]), "Confounding pattern differs")
    args.output.mkdir(parents=True,exist_ok=True)
    write_csv(args.output/"decisions.csv",raw)
    write_csv(args.output/"scores.csv",complete)
    write_csv(args.output/"strata.csv",strata)
    write_csv(args.output/"census.csv",census_rows)
    write_csv(args.output/"semantic_repeats.csv",semantic_repeats(raw))
    fields = ("family","reader","dispatches","valid_packets","invalid_packets","unrun_packets","input_tokens","output_tokens","cost_nanodollars")
    write_csv(args.output/"administration.csv",[{k:r.get(k,"" if k.endswith("tokens") or k=="cost_nanodollars" else 0) for k in fields} for r in admin])
    (args.output/"diagnostics.json").write_text(json.dumps(interpretation,indent=2)+"\n",encoding="utf-8")
    print(f"Verified {len(admin)} study arms, 308 dispatches and {len(raw)} scheduled arm-observations.")

if __name__ == "__main__":
    main()
