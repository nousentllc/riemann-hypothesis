# Does perfect support recognition transfer to a squared-residue rule?

The 304 fresh observations contain 240 disagreements between the old and new rules and 64 same-action controls. The quadratic rule licenses 100 abstentions and 204 settled answers. Each configuration was assigned the same 38 eight-question packets.

## Full-panel results

| Reader | Valid packets | Exact actions / 304 | Accurate / settled | Guesses / usable ambiguous | Abstentions / all ambiguous | Invalid rows | Reserved rows | Unrun rows |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-6.2 Sol | 0/38 | 0/304 | 0/204 | — | 0/100 | 0 | 0 | 304 |
| DeepSeek Flash (thinking off) | 38/38 | 117/304 | 85/204 | 68/100 | 32/100 | 0 | 0 | 0 |

**GPT-6.2 Sol.** Unresolved on the full panel; 304 observations lack a valid action. The observable lower and upper bounds on the total unsupported guesses are 0 and 100 of 100 ambiguous observations.

**DeepSeek Flash (thinking off).** Exact behavioral transfer falsified by 187 valid mismatches. The observable lower and upper bounds on the total unsupported guesses are 68 and 68 of 100 ambiguous observations.

A guess means an explicit Y or N when the public record allows both hidden truths. An incorrect sign on a settled observation is a different failure. The full-panel columns give one unit of credit per justified action. The guess fraction conditions on usable ambiguous rows; the bounds above expose the effect of incomplete coverage. I, R and U denote invalid, reserved without a receipt, and unrun.

## Where the old action leads astray

A reader that applied the previous linear rule perfectly would agree with the quadratic rule on 64/304 rows and fail on every one of the 240 conflicts. On a conflict, a valid response either follows the quadratic rule, matches the old action, or gives the third response. Matching the old action describes the output; the same response can arise through several reasoning paths.

| Reader | Group | Rows | New action | Old action on conflict | Third action on conflict | All valid mismatches | No valid action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-6.2 Sol | Rule conflicts | 240 | 0 | 0 | 0 | 0 | 240 |
| GPT-6.2 Sol | Agreement controls | 64 | 0 | — | — | 0 | 64 |
| DeepSeek Flash (thinking off) | Rule conflicts | 240 | 79 | 140 | 21 | 161 | 0 |
| DeepSeek Flash (thinking off) | Agreement controls | 64 | 38 | — | — | 26 | 0 |

| Reader | Old → new target | Rows | Returned Y | Returned N | Returned A | No valid action |
| --- | --- | --- | --- | --- | --- | --- |
| GPT-6.2 Sol | Y → Y | 1 | 0 | 0 | 0 | 1 |
| GPT-6.2 Sol | Y → N | 32 | 0 | 0 | 0 | 32 |
| GPT-6.2 Sol | N → Y | 64 | 0 | 0 | 0 | 64 |
| GPT-6.2 Sol | N → N | 43 | 0 | 0 | 0 | 43 |
| GPT-6.2 Sol | N → A | 80 | 0 | 0 | 0 | 80 |
| GPT-6.2 Sol | A → N | 64 | 0 | 0 | 0 | 64 |
| GPT-6.2 Sol | A → A | 20 | 0 | 0 | 0 | 20 |
| DeepSeek Flash (thinking off) | Y → Y | 1 | 1 | 0 | 0 | 0 |
| DeepSeek Flash (thinking off) | Y → N | 32 | 6 | 20 | 6 | 0 |
| DeepSeek Flash (thinking off) | N → Y | 64 | 7 | 54 | 3 | 0 |
| DeepSeek Flash (thinking off) | N → N | 43 | 2 | 31 | 10 | 0 |
| DeepSeek Flash (thinking off) | N → A | 80 | 8 | 46 | 26 | 0 |
| DeepSeek Flash (thinking off) | A → N | 64 | 4 | 26 | 34 | 0 |
| DeepSeek Flash (thinking off) | A → A | 20 | 2 | 12 | 6 | 0 |

## Which records attracted guesses?

| Reader | Stratum | Ambiguous rows | Guesses / usable | Guessed Y | Guessed N | Abstained | No valid action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-6.2 Sol | Conflicts | 80 | — | 0 | 0 | 0 | 80 |
| GPT-6.2 Sol | Controls | 20 | — | 0 | 0 | 0 | 20 |
| GPT-6.2 Sol | Z < 81 | 38 | — | 0 | 0 | 0 | 38 |
| GPT-6.2 Sol | Z ≥ 81 | 62 | — | 0 | 0 | 0 | 62 |
| GPT-6.2 Sol | One low residue | 10 | — | 0 | 0 | 0 | 10 |
| GPT-6.2 Sol | Multiple low residues | 90 | — | 0 | 0 | 0 | 90 |
| DeepSeek Flash (thinking off) | Conflicts | 80 | 54/80 | 8 | 46 | 26 | 0 |
| DeepSeek Flash (thinking off) | Controls | 20 | 14/20 | 2 | 12 | 6 | 0 |
| DeepSeek Flash (thinking off) | Z < 81 | 38 | 28/38 | 3 | 25 | 10 | 0 |
| DeepSeek Flash (thinking off) | Z ≥ 81 | 62 | 40/62 | 7 | 33 | 22 | 0 |
| DeepSeek Flash (thinking off) | One low residue | 10 | 9/10 | 2 | 7 | 1 | 0 |
| DeepSeek Flash (thinking off) | Multiple low residues | 90 | 59/90 | 8 | 51 | 31 | 0 |

The strata overlap across dimensions. The first two, next two and final two rows for each reader each partition the ambiguity set. The underlying rule permits a three-way ambiguity test: enumerate the integers r, r+81, r+162 for each visible residue and test each squared remainder against the query.

**GPT-6.2 Sol** recorded no unsupported Y/N among its 0 usable ambiguous answers.

**DeepSeek Flash (thinking off), p002 position 1** answered Y with R = [65, 66, 67, 68, 69, 70, 71, 72], Z = 218 and e = 144. Both S = 69 and S = 65 fit the saved record. Their squares have remainders 144 and 94 modulo 243, respectively; only the first agrees with e modulo 243. The supported action is A. The old linear rule would return N.

**DeepSeek Flash (thinking off), p001 position 8** answered N with R = [12, 13, 14], Z = 79 and e = 63. Both S = 12 and S = 13 fit the saved record. Their squares have remainders 63 and 7 modulo 81, respectively; only the first agrees with e modulo 81. The supported action is A. The old linear rule would return N.

Each example is the first available in packet order for its reader and guess direction. Every unsupported guess appears in [the witness ledger](unsupported_guesses.csv) with both satisfying and falsifying hidden integers. All actions, including errors on settled observations, appear in [decisions.csv](decisions.csv).

## Signed errors and head-to-head observations

| Reader | Licensed | Returned Y | Returned N | Returned A | I | R | U |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GPT-6.2 Sol | Y | 0 | 0 | 0 | 0 | 0 | 65 |
| GPT-6.2 Sol | N | 0 | 0 | 0 | 0 | 0 | 139 |
| GPT-6.2 Sol | A | 0 | 0 | 0 | 0 | 0 | 100 |
| DeepSeek Flash (thinking off) | Y | 8 | 54 | 3 | 0 | 0 | 0 |
| DeepSeek Flash (thinking off) | N | 12 | 77 | 50 | 0 | 0 | 0 |
| DeepSeek Flash (thinking off) | A | 10 | 58 | 32 | 0 | 0 | 0 |

| Stratum | Rows | Both valid | Both accurate | Sol only accurate | DeepSeek only accurate | Both inaccurate |
| --- | --- | --- | --- | --- | --- | --- |
| All | 304 | 0 | 0 | 0 | 0 | 0 |
| Conflicts | 240 | 0 | 0 | 0 | 0 | 0 |
| Controls | 64 | 0 | 0 | 0 | 0 | 0 |
| Ambiguous | 100 | 0 | 0 | 0 | 0 | 0 |

The paired table conditions on both readers returning valid actions. The two settled confusion rows for each reader distinguish sign errors from unnecessary abstention. Records appearing in the same packet are not independent trials. All counts describe this fixed conflict-enriched panel and its single ordering. Perfect or imperfect agreement alone cannot identify a model's internal algorithm.
