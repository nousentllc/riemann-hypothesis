#!/bin/sh
set -eu
export ELECTRON_RUN_AS_NODE=1
exec '/Applications/DeepSeek Harness.app/Contents/MacOS/DeepSeek Harness' --expose-internals "$(dirname "$0")/reader.mjs" "$@"
