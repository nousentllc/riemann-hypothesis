"""Render the completed transfer study's ambiguous-record counts as a printable PNG."""
import argparse
from collections import Counter
import csv
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
STRATA = (
    ("low residues disagree and each is uniform", 58, "Each triple agrees internally",
     "Different saved residues give different answers."),
    ("split and uniform low residues", 32, "Some triples split",
     "Some residues allow both answers. Others give only one."),
    ("every low residue splits", 10, "Every triple splits",
     "Every saved residue allows both answers among its three hidden integers."),
)
READERS = (("openai", "GPT-6.2 Sol"), ("deepseek", "DeepSeek Flash"))
ACTIONS = ("Y", "N", "A", "I")
INK, MUTED, RULE = "#192A32", "#40545C", "#CAD5D4"
COLORS = {"Y":"#D17727","N":"#846142","A":"#176F72","I":"#869298"}


def fonts(size, bold=False):
    names = ("Arial Bold.ttf","DejaVuSans-Bold.ttf") if bold else ("Arial.ttf","DejaVuSans.ttf")
    places = (Path("/System/Library/Fonts/Supplemental")/names[0],
              Path("/usr/share/fonts/truetype/dejavu")/names[1],
              Path("C:/Windows/Fonts")/("arialbd.ttf" if bold else "arial.ttf"))
    for path in places:
        if path.is_file():
            return ImageFont.truetype(str(path),size=size)
    return ImageFont.truetype(names[1],size=size)


def read_counts(study):
    panel = json.loads((study/"panel.json").read_bytes())
    rows = {r["id"]:r for r in panel["rows"]}
    if len(rows) != 304 or sum(r["new_action"]=="A" for r in rows.values()) != 100:
        raise ValueError("Figure expects the 304-row transfer panel with 100 ambiguous observations")
    counts = Counter()
    seen = set()
    with (study/"decisions.csv").open(newline="") as stream:
        for record in csv.DictReader(stream):
            key=record["row"]
            row=rows[key]
            if key in seen or record["new_action"]!=row["new_action"]:
                raise ValueError("Repeated row or oracle mismatch in decisions.csv")
            seen.add(key)
            for alias,_ in READERS:
                action=record[alias+"_action"]
                if action not in ACTIONS:
                    raise ValueError("Both readers need finalized receipts before drawing the figure")
                if row["new_action"]=="A":
                    counts[row["ambiguity_source"],alias,action]+=1
    if seen!=set(rows):
        raise ValueError("Incomplete row coverage")
    for source,total,_,_ in STRATA:
        for alias,_ in READERS:
            if sum(counts[source,alias,a] for a in ACTIONS)!=total:
                raise ValueError("Ambiguity stratum or action counts changed")
    return counts


def render(study, output):
    counts=read_counts(study)
    canvas=Image.new("RGB",(1700,1010),"#FFFFFF")
    d=ImageDraw.Draw(canvas)
    def label(x,y,text,size=24,color=INK,bold=False,anchor=None):
        d.text((x,y),text,fill=color,font=fonts(size,bold),anchor=anchor)
    margin=60
    label(margin,32,"When the squared-residue rule requires abstention",48,bold=True)
    label(margin,99,"100 records allow both hidden answers. Any yes or no is an unsupported guess.",27,MUTED)
    label(margin,145,"The three hidden integers compatible with a saved residue r are r, r + 81 and r + 162.",24,MUTED)
    d.line((margin,205,1640,205),fill=RULE,width=2)
    label(margin,223,"Source of ambiguity",23,bold=True)
    label(497,223,"Reader",23,bold=True)
    label(728,223,"Share of records",23,bold=True)
    xs={"Y":1240,"N":1366,"A":1488,"I":1605}
    for a,title in zip(ACTIONS,("Yes","No","Abstain","Invalid")):
        label(xs[a],236,title,23,bold=True,anchor="mm")
        d.rectangle((xs[a]-18,259,xs[a]+18,266),fill=COLORS[a])
    for index,(source,total,title,explain) in enumerate(STRATA):
        y=286+index*213
        d.line((margin,y,1640,y),fill=RULE,width=2)
        label(margin,y+23,title,29,bold=True)
        label(margin,y+66,str(total)+" records",24,MUTED)
        label(margin,y+168,explain,23,MUTED)
        for j,(alias,name) in enumerate(READERS):
            center=y+48+j*61
            label(497,center,name,25,anchor="lm")
            x0,x1=728,1145
            left=x0;running=0
            for a in ACTIONS:
                n=counts[source,alias,a];running+=n
                right=x0+round((x1-x0)*running/total)
                if right>left:
                    d.rectangle((left,center-12,right-1,center+12),fill=COLORS[a])
                left=right
                label(xs[a],center,str(n),29,bold=n>0,anchor="mm")
    d.line((margin,925,1640,925),fill=RULE,width=2)
    label(margin,948,"Counts are paired within each stratum. DeepSeek Flash used thinking off. Invalid outputs contribute zero abstentions.",23,MUTED)
    canvas.save(output,format="PNG",dpi=(180,180),optimize=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study",type=Path,default=ROOT)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    render(args.study,args.output or args.study/"guess_map.png")
