"""Independently score the visible actions in the squared-residue transfer experiment."""
import argparse
from collections import Counter
import csv
from hashlib import sha256
import io
import json
from pathlib import Path
from tempfile import NamedTemporaryFile


HERE = Path(__file__).resolve().parent
READERS = {"openai": "GPT-6.2 Sol", "deepseek": "DeepSeek Flash (thinking off)"}
ACTIONS = ("Y", "N", "A")
MISSING = ("I", "R", "U")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def render_table(columns, rows):
    items = [columns, ["---"] * len(columns), *rows]
    return "\n".join("| " + " | ".join(str(x) for x in line) + " |" for line in items)


def fraction(numerator, denominator):
    return f"{numerator}/{denominator}" if denominator else "—"


def support(yes, no):
    if not yes:
        return "N"
    return "A" if no else "Y"


def causal_witnesses(row):
    """Enumerate the 0..242 integers and retain the least witness for each truth value."""
    m = 81 if row["z"] < 81 else 243
    possible = [s for s in range(243) if s % 81 in row["residues"]]
    yes = [s for s in possible if (s*s - row["e"]) % m == 0]
    no = [s for s in possible if (s*s - row["e"]) % m != 0]
    old_yes = sum((s - row["e"]) % m == 0 for s in possible)
    old_no = len(possible) - old_yes
    require((len(yes), len(no), old_yes, old_no) == tuple(row[k] for k in
            ("new_yes", "new_no", "old_yes", "old_no")), "Oracle-count mismatch " + row["id"])
    require(support(len(yes), len(no)) == row["new_action"] and
            support(old_yes, old_no) == row["old_action"], "Target mismatch " + row["id"])
    return m, yes[0] if yes else None, no[0] if no else None


def decoded(content):
    if not isinstance(content, str):
        return None
    try:
        raw = json.loads(content)
    except ValueError:
        return None
    if not isinstance(raw, dict) or set(raw) != {"actions"}:
        return None
    actions = raw["actions"]
    if isinstance(actions, list) and len(actions) == 8 and all(a in ACTIONS for a in actions):
        return actions
    return None


def outputs(study, packets, reader):
    answers = {}
    packet_counts = Counter()
    expected = {p["id"] for p in packets}
    for kind in ("attempts", "responses"):
        extra = {f.stem for f in (study/kind/reader).glob("*.json")} - expected
        require(not extra, "Unexpected packets " + str(extra))
    for p in packets:
        pid = p["id"]
        path = study/"responses"/reader/(pid+".json")
        reservation = study/"attempts"/reader/(pid+".json")
        if path.is_file():
            record = read(path)
            require(record.get("packet") == pid and record.get("prompt_sha256") == p["prompt_sha256"],
                    "Receipt identity differs " + str(path))
            actions = decoded(record.get("content"))
            if record.get("status") == "ok":
                require(actions is not None and actions == record.get("actions"), "Invalid accepted receipt " + str(path))
                status = "valid"
            else:
                require(isinstance(record.get("status"), str) and record["status"], "Absent status " + str(path))
                if record["status"] == "invalid_output":
                    require(actions is None, "Valid response marked malformed " + str(path))
                actions = ["I"]*8
                status = "invalid"
        elif reservation.is_file():
            status, actions = "reserved", ["R"]*8
        else:
            status, actions = "unrun", ["U"]*8
        packet_counts[status] += 1
        answers.update(zip(p["rows"], actions, strict=True))
    return answers, packet_counts


def tally(rows, reader):
    return Counter((r["new_action"], r[reader]) for r in rows)


def coverage(group, reader):
    return sum(r[reader] not in ACTIONS for r in group)


def guesses(group, reader):
    return sum(r["new_action"] == "A" and r[reader] in ("Y", "N") for r in group)


def correct(group, reader):
    return sum(r[reader] == r["new_action"] for r in group)


def diagnosis(row, reader):
    answer, target = row[reader], row["new_action"]
    if answer not in ACTIONS:
        return {"I":"invalid", "R":"reserved", "U":"unrun"}[answer]
    if answer == target:
        return "justified abstention" if target == "A" else "justified sign"
    if target == "A":
        return "unsupported guess"
    return "unwarranted abstention" if answer == "A" else "wrong sign"


def relation(row, reader):
    if row[reader] not in ACTIONS:
        return "no valid action"
    if row["new_action"] == row["old_action"]:
        return "agreement control"
    if row[reader] == row["new_action"]:
        return "new action"
    return "old action" if row[reader] == row["old_action"] else "third action"


def file_text(path, text):
    with NamedTemporaryFile(mode="w", newline="", encoding="utf-8", dir=path.parent, delete=False) as handle:
        handle.write(text)
    Path(handle.name).replace(path)


def csv_text(columns, data):
    buff = io.StringIO(newline="")
    writer = csv.writer(buff)
    writer.writerow(columns)
    writer.writerows(data)
    return buff.getvalue()


def score(study):
    panel = read(study/"panel.json")
    rows, packets = panel["rows"], panel["packets"]
    positions = {key:(p["id"],i) for p in packets for i,key in enumerate(p["rows"],1)}
    require(len(rows) == 304 and len(packets) == 38 and all(len(p["rows"])==8 for p in packets), "Panel size")
    require(len(positions) == 304 and {r["id"] for r in rows} == set(positions), "Row coverage")
    public = [json.loads(line) for line in (study/"public_packets.jsonl").read_bytes().splitlines()]
    require(len(public) == 38 and all(
        pub["packet"] == p["id"] and sha256(pub["prompt"].encode()).hexdigest() == pub["prompt_sha256"] == p["prompt_sha256"]
        for p,pub in zip(packets,public)), "Prompt mismatch")
    counts = {}
    for reader in READERS:
        answers, counts[reader] = outputs(study, packets, reader)
        for r in rows:
            r[reader] = answers[r["id"]]
    for r in rows:
        r["packet"],r["position"] = positions[r["id"]]
        r["modulus"],r["yes_witness"],r["no_witness"] = causal_witnesses(r)
    rows = sorted(rows, key=lambda r: (r["packet"], r["position"]))
    ambiguous = [r for r in rows if r["new_action"] == "A"]
    settled = [r for r in rows if r["new_action"] != "A"]
    conflicts = [r for r in rows if r["new_action"] != r["old_action"]]
    controls = [r for r in rows if r["new_action"] == r["old_action"]]
    totals, split, flow, matrix, locations, examples, verdicts = [], [], [], [], [], [], []
    for reader,name in READERS.items():
        t = tally(rows,reader)
        bad = coverage(rows,reader)
        g = guesses(ambiguous,reader)
        valid_amb = len(ambiguous)-coverage(ambiguous,reader)
        pcount = counts[reader]
        totals.append([name, f"{pcount['valid']}/38", fraction(correct(rows,reader),304),
                       fraction(correct(settled,reader),len(settled)),fraction(g,valid_amb),
                       fraction(t["A","A"],len(ambiguous)),pcount["invalid"]*8,pcount["reserved"]*8,pcount["unrun"]*8])
        definite_errors = sum(r[reader] in ACTIONS and r[reader] != r["new_action"] for r in rows)
        if definite_errors:
            verdict = f"Exact behavioral transfer falsified by {definite_errors} valid mismatches."
        elif bad:
            verdict = f"Unresolved on the full panel; {bad} observations lack a valid action."
        else:
            verdict = "Exact behavioral transfer observed on all 304 observations."
        verdicts.append(f"**{name}.** {verdict} The observable lower and upper bounds on the total unsupported guesses "
                        f"are {g} and {g + coverage(ambiguous,reader)} of {len(ambiguous)} ambiguous observations.")
        for k in ACTIONS:
            matrix.append([name,k,*[t[k,a] for a in (*ACTIONS,*MISSING)]])
        for label,group in (("Rule conflicts",conflicts),("Agreement controls",controls)):
            split.append([name,label,len(group),correct(group,reader),
                          sum(relation(r,reader)=="old action" for r in group) if group is conflicts else "—",
                          sum(relation(r,reader)=="third action" for r in group) if group is conflicts else "—",
                          sum(r[reader] in ACTIONS and r[reader]!=r["new_action"] for r in group),
                          coverage(group,reader)])
        for old in ACTIONS:
            for new in ACTIONS:
                group=[r for r in rows if r["old_action"]==old and r["new_action"]==new]
                if group:
                    flow.append([name,f"{old} → {new}",len(group),*[sum(r[reader]==a for r in group) for a in ACTIONS],
                                 coverage(group,reader)])
        for label,subgroup in (("Conflicts",conflicts),("Controls",controls),
                               ("Z < 81",[r for r in rows if r["z"]<81]),("Z ≥ 81",[r for r in rows if r["z"]>=81]),
                               ("One low residue",[r for r in rows if len(r["residues"])==1]),
                               ("Multiple low residues",[r for r in rows if len(r["residues"])>1])):
            arows=[r for r in subgroup if r["new_action"]=="A"]
            v=len(arows)-coverage(arows,reader)
            locations.append([name,label,len(arows),fraction(guesses(arows,reader),v),
                              sum(r[reader]=="Y" for r in arows),sum(r[reader]=="N" for r in arows),
                              sum(r[reader]=="A" for r in arows),coverage(arows,reader)])
        for sign in ("Y","N"):
            r=next((r for r in ambiguous if r[reader]==sign),None)
            if r:
                y,n,m=r["yes_witness"],r["no_witness"],r["modulus"]
                examples.append(f"**{name}, {r['packet']} position {r['position']}** answered {sign} with "
                                f"R = {r['residues']}, Z = {r['z']} and e = {r['e']}. Both S = {y} and S = {n} "
                                f"fit the saved record. Their squares have remainders {y*y%m} and {n*n%m} modulo "
                                f"{m}, respectively; only the first agrees with e modulo {m}. The supported action "
                                f"is A. The old linear rule would return {r['old_action']}.")
        if not g:
            examples.append(f"**{name}** recorded no unsupported Y/N among its {valid_amb} usable ambiguous answers.")
    paired = []
    for label,group in (("All",rows),("Conflicts",conflicts),("Controls",controls),("Ambiguous",ambiguous)):
        pair=Counter((r["openai"]==r["new_action"],r["deepseek"]==r["new_action"]) for r in group
                     if all(r[k] in ACTIONS for k in READERS))
        paired.append([label,len(group),sum(pair.values()),pair[True,True],pair[True,False],pair[False,True],pair[False,False]])
    canonical_cols=["row","packet","position","z","e","m","tag","residues","writers","old_action","new_action",
                    "old_yes","old_no","new_yes","new_no","yes_witness","no_witness"]
    def fixed(r):
        return [r["id"],r["packet"],r["position"],r["z"],r["e"],r["modulus"],r["tag"]," ".join(map(str,r["residues"])),
                " ".join(r["writers"]),*[r[k] for k in canonical_cols[9:]]]
    pred_cols=[k+suffix for k in READERS for suffix in ("_action","_diagnosis","_rule_relation")]
    file_text(study/"decisions.csv",csv_text(canonical_cols+pred_cols,
              (fixed(r)+[value for k in READERS for value in (r[k],diagnosis(r,k),relation(r,k))] for r in rows)))
    file_text(study/"unsupported_guesses.csv",csv_text(["reader","guess","rule_relation",*canonical_cols],
              ([k,r[k],relation(r,k),*fixed(r)] for r in rows for k in READERS if diagnosis(r,k)=="unsupported guess")))
    report=[
        "# Does perfect support recognition transfer to a squared-residue rule?",
        f"The 304 fresh observations contain {len(conflicts)} disagreements between the old and new rules and "
        f"{len(controls)} same-action controls. The quadratic rule licenses {len(ambiguous)} abstentions and "
        f"{len(settled)} settled answers. Each configuration was assigned the same 38 eight-question packets.",
        "## Full-panel results",
        render_table(["Reader","Valid packets","Exact actions / 304","Accurate / settled","Guesses / usable ambiguous",
                      "Abstentions / all ambiguous","Invalid rows","Reserved rows","Unrun rows"],totals),*verdicts,
        "A guess means an explicit Y or N when the public record allows both hidden truths. An incorrect sign "
        "on a settled observation is a different failure. The full-panel columns give one unit of credit per "
        "justified action. The guess fraction conditions on usable ambiguous rows; the bounds above expose the "
        "effect of incomplete coverage. I, R and U denote invalid, reserved without a receipt, and unrun.",
        "## Where the old action leads astray",
        f"A reader that applied the previous linear rule perfectly would agree with the quadratic rule on "
        f"{len(controls)}/304 rows and fail on every one of the {len(conflicts)} conflicts. On a conflict, a valid "
        "response either follows the quadratic rule, matches the old action, or gives the third response. Matching "
        "the old action describes the output; the same response can arise through several reasoning paths.",
        render_table(["Reader","Group","Rows","New action","Old action on conflict","Third action on conflict",
                      "All valid mismatches","No valid action"],split),
        render_table(["Reader","Old → new target","Rows","Returned Y","Returned N","Returned A","No valid action"],flow),
        "## Which records attracted guesses?",
        render_table(["Reader","Stratum","Ambiguous rows","Guesses / usable","Guessed Y","Guessed N","Abstained",
                      "No valid action"],locations),
        "The strata overlap across dimensions. The first two, next two and final two rows for each reader each "
        "partition the ambiguity set. The underlying rule permits a three-way ambiguity test: enumerate the "
        "integers r, r+81, r+162 for each visible residue and test each squared remainder against the query.",
        *examples,
        "Each example is the first available in packet order for its reader and guess direction. Every unsupported "
        "guess appears in [the witness ledger](unsupported_guesses.csv) with both satisfying and falsifying "
        "hidden integers. All actions, including errors on settled observations, appear in [decisions.csv](decisions.csv).",
        "## Signed errors and head-to-head observations",
        render_table(["Reader","Licensed","Returned Y","Returned N","Returned A","I","R","U"],matrix),
        render_table(["Stratum","Rows","Both valid","Both accurate","Sol only accurate","DeepSeek only accurate",
                      "Both inaccurate"],paired),
        "The paired table conditions on both readers returning valid actions. The two settled confusion rows for "
        "each reader distinguish sign errors from unnecessary abstention. Records appearing in the same packet are "
        "not independent trials. All counts describe this fixed conflict-enriched panel and its single ordering. "
        "Perfect or imperfect agreement alone cannot identify a model's internal algorithm.",
    ]
    file_text(study/"RESULTS.md","\n\n".join(report)+"\n")
    return totals


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--study",type=Path,default=HERE)
    args=cli.parse_args()
    for row in score(args.study.resolve()):
        print(*row,sep=" | ")
