"""Use an already-authorized API key transiently. Never print or persist it."""
import os
import re
import subprocess
import urllib.error
import urllib.request


def read_existing():
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    source = os.environ.get("HOSTED_OPENAI_KEY_SOURCE", "")
    if not key and source == "confirmed-copy":
        # Only after the named OpenAI API item was selected and copied by its owner.
        got = subprocess.run(["/usr/bin/pbpaste"], capture_output=True, check=True)
        candidate = got.stdout.decode("ascii", errors="ignore").strip()
        if re.fullmatch(r"sk-[A-Za-z0-9_-]{16,}",candidate):
            key = candidate
            if subprocess.check_output(["/usr/bin/pbpaste"]) == got.stdout:
                subprocess.run(["/usr/bin/pbcopy"],input=b"",check=True)
    if not key and source == "named-keychain":
        for opt in ("-l","-s"):
            p = subprocess.run(["/usr/bin/security","find-generic-password",opt,"openai research key","-w"],
                               capture_output=True,check=False)
            if p.returncode==0:
                key=p.stdout.decode("ascii",errors="ignore").strip()
                break
    if not re.fullmatch(r"sk-[A-Za-z0-9_-]{16,}",key):
        return None
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args):
            raise RuntimeError("Declined redirect during model-access verification")
    req=urllib.request.Request("https://api.openai.com/v1/models/gpt-6.2-sol",
                               headers={"Authorization":"Bearer "+key})
    client=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    try:
        with client.open(req,timeout=30) as reply:
            if reply.status!=200:
                raise RuntimeError("The existing key could not verify access to the selected model")
    except urllib.error.HTTPError as e:
        # Restricted keys can permit completions while hiding the model catalog.
        if e.code in (403,404):
            return key
        raise RuntimeError(f"OpenAI model-access lookup returned HTTP {e.code}; no generation was requested") from None
    return key
