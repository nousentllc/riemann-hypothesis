"""Independent, offline verification of the square-rule transfer study."""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess


HERE = Path(__file__).resolve().parent
OLD_Z = (64, 65, 74, 80, 81, 90, 101, 121, 162)
OLD_PANEL_SHA = "b6969f3d5d8343edc3f0fbda8c36cb0f09ccbc875e1dd7da8f79d5395c684320"
WRITERS = ("raw27", "opt27", "terminal", "split1", "split8", "full")
ACTIONS = ("Y", "N", "A")
PACKETS = tuple(f"p{i:03}" for i in range(1, 39))
TARIFF = {"deepseek": (300, 1_200), "openai": (2_000, 10_000)}  # nanodollars per token
RESERVE = {"deepseek": 3_072, "openai": 23_552}  # microdollars per packet
TOTAL_LIMIT_NANO = 1_250_000_000
LINE = re.compile(r"([1-8])\. tag=(\d+), R=(\[\d+(?:, \d+)*\]), Z=(\d+), e=(\d+)")


def require(test, error):
    if not test:
        raise ValueError(error)


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return sha256(data).hexdigest()


def public_key(row):
    return row["tag"], tuple(row["residues"]), row["z"], row["e"]


def record_dictionary():
    """Build the historical writers by partitioning low residues, independent of the generator."""
    by_writer = {}
    empty = (0, *range(65, 81))
    singles = [(r,) for r in range(1, 65)]
    by_writer["raw27"] = [(i, i + 27, i + 54) for i in range(27)]
    by_writer["opt27"] = ([empty] + singles[:11]
                          + [tuple(range(i, i + 3)) for i in range(12, 33, 3)]
                          + [tuple(range(i, i + 4)) for i in range(33, 65, 4)])
    by_writer["terminal"] = [empty, *singles]
    for name, width in (("split1", 1), ("split8", 8)):
        by_writer[name] = [(0, *range(65 + width, 81)), *singles, tuple(range(65, 65 + width))]
    by_writer["full"] = [(r,) for r in range(81)]
    records = defaultdict(list)
    for writer in WRITERS:
        cells = by_writer[writer]
        require(sorted(r for cell in cells for r in cell) == list(range(81)), "Writer partition")
        for tag, cell in enumerate(cells):
            records[tag, cell].append(writer)
    return records


def exact_counts(rs, z, e):
    """(r+81k)^2 = r² + 162rk modulo 243; solve its linear congruence in k."""
    modulus = 81 if z < 81 else 243
    if modulus == 81:
        new = 3 * sum((r*r - e) % 81 == 0 for r in rs)
        old = 3 * int(e % 81 in rs)
    else:
        new = 0
        for r in rs:
            delta = e-r*r
            if delta % 81 == 0:
                # 2rk = delta/81 (mod 3). A unit coefficient gives exactly one k.
                if r % 3:
                    new += 1
                elif delta % 243 == 0:
                    new += 3
        old = int(e % 81 in rs)
    return old, new


def label(nyes, total):
    return "N" if nyes == 0 else "Y" if nyes == total else "A"


def test_lift_identity():
    """Cross-check the closed form directly for each e modulo 243 in both bands."""
    for r in range(81):
        centers = (r, r+81, r+162)
        for z in (79, 82):
            modulus = 81 if z < 81 else 243
            for e in range(243):
                oracle = exact_counts((r,), z, e)
                direct = (sum((s-e)%modulus == 0 for s in centers),
                          sum((s*s-e)%modulus == 0 for s in centers))
                require(oracle == direct, f"Closed form disagrees at {r}/{z}/{e}")
    return 81*2*243


def nested_transitions(counter):
    return {a:{b:counter[a,b] for b in ACTIONS} for a in ACTIONS}


def panel_check(study, prior_panel=None):
    p = read(study/"panel.json")
    rows = {r["id"]:r for r in p["rows"]}
    require(len(rows) == len(p["rows"]) == 304, "Panel size or duplicate IDs")
    require([pkt["id"] for pkt in p["packets"]] == list(PACKETS), "Packet IDs/order")
    bounds = sorted({r["z"] for r in rows.values()})
    require(set(bounds).isdisjoint(OLD_Z) and min(bounds)>=27 and max(bounds)<243 and
            any(z<81 for z in bounds) and any(z>=81 for z in bounds), "Nonfresh cutoffs or unsupported band")
    selected = Counter()
    records = record_dictionary()
    observations = set()
    for r in rows.values():
        tag, rs, z, e = public_key(r)
        require(all(type(q) is int for q in (tag,z,e,*rs)), "Noninteger public record")
        require(1 <= e <= z and (tag,rs) in records, "Out-of-domain weight or unknown record")
        require(set(r["writers"]) == set(records[tag,rs]) and len(r["writers"])==len(records[tag,rs]),
                "Historical writer provenance mismatch "+r["id"])
        key = (tag, rs, z, e)
        require(key not in observations,"Repeated visible observation")
        observations.add(key)
        ident = digest(json.dumps(key,separators=(",",":")).encode())[:18]
        require(ident == r["id"], "Public identifier mismatch")
        old, new = exact_counts(rs,z,e)
        for rule, count in (("old",old), ("new",new)):
            n = 3*len(rs)
            require((r[rule+"_yes"],r[rule+"_no"],r[rule+"_action"]) == (count,n-count,label(count,n)),
                    "Support mismatch "+ident+"/"+rule)
        selected[r["old_action"],r["new_action"]] += 1
    effective={(tag,rs,81 if z<81 else 243,e) for tag,rs,z,e in observations}
    require(len(effective)==len(observations),"Duplicate effective (tag,R,m,e) observations")
    prior_keys=None
    if prior_panel:
        old_bytes=prior_panel.read_bytes()
        require(digest(old_bytes)==OLD_PANEL_SHA,"Prior panel differs from published freeze")
        old=json.loads(old_bytes)["rows"]
        require(sorted({r["z"] for r in old})==list(OLD_Z) and observations.isdisjoint(public_key(r) for r in old),
                "Prior-panel overlap")
        prior_keys={(r["tag"],tuple(r["residues"]),81 if r["z"]<81 else 243,r["e"]) for r in old}
        require(effective.isdisjoint(prior_keys),"Effective public key seen on historical panel")
    population=Counter()
    bands={m:Counter() for m in (81,243)}
    eligible={m:Counter() for m in (81,243)}
    selected_bands={m:Counter() for m in (81,243)}
    for r in rows.values():
        selected_bands[81 if r["z"]<81 else 243][r["old_action"]+r["new_action"]]+=1
    seen_effective=set()
    for z in bounds:
        modulus=81 if z<81 else 243
        for tag, rs in records:
            for e in range(1,z+1):
                n = 3*len(rs)
                a,b = exact_counts(rs,z,e)
                old_label,new_label=label(a,n),label(b,n)
                population[old_label,new_label] += 1
                pair=old_label+new_label
                bands[modulus][pair]+=1
                key=(tag,rs,modulus,e)
                if prior_keys is not None and key not in prior_keys and key not in seen_effective:
                    eligible[modulus][pair]+=1
                    seen_effective.add(key)
    def table_bands(groups):
        return {str(m):{x+y:cell[x+y] for x in ACTIONS for y in ACTIONS} for m,cell in groups.items()}
    for field,counts in (("population_census",bands),("selected_census",selected_bands)):
        if field in p:
            require(table_bands(counts)==p[field], "Saved census differs: "+field)
    if "eligible_census" in p and prior_keys is not None:
        require(table_bands(eligible)==p["eligible_census"],"Historical-exclusion eligible census differs")
    require(0 < sum(v for (a,b),v in selected.items() if a!=b) < len(rows),"Need both conflicts and controls")
    require(all(selected[t] <= population[t] for t in selected), "Selected count exceeds cell population")
    pub = [json.loads(line) for line in (study/"public_packets.jsonl").read_bytes().splitlines()]
    require([x["packet"] for x in pub]==list(PACKETS),"Export/packet sequence")
    header=None
    covered=[]
    for packet, export in zip(p["packets"],pub):
        require(set(export)=={"packet","prompt","prompt_sha256"}, "Unexpected public fields")
        prompt=export["prompt"]
        require(len(packet["rows"])==8 and packet["prompt_sha256"]==export["prompt_sha256"]==digest(prompt.encode()),
                "Prompt row count or hash mismatch")
        lines=prompt.splitlines()
        intro="\n".join(lines[:-8])
        if header is None:header=intro
        require(intro==header and not any(LINE.fullmatch(x) for x in lines[:-8]), "Unexpected packet-specific prefix")
        for pos,(line,key) in enumerate(zip(lines[-8:],packet["rows"]),1):
            m=LINE.fullmatch(line)
            require(m is not None and int(m[1])==pos, "Unparseable public row "+packet["id"])
            visible=(int(m[2]),tuple(json.loads(m[3])),int(m[4]),int(m[5]))
            require(key in rows and visible==public_key(rows[key]), "Rendered row differs from oracle")
            covered.append(key)
    require(Counter(covered)==Counter(list(rows)), "Packet coverage mismatch")
    summary={"cutoffs":bounds,"rows":len(rows),"packets":len(pub),"public_record_types":len(records),
             "unique_effective_keys":len(effective),"prior_effective_overlap":0 if prior_keys is not None else None,
             "prior_effective_census_checked":prior_keys is not None,
             "prior_panel_sha256":OLD_PANEL_SHA,"prior_cutoffs":list(OLD_Z),"prior_cutoff_overlap":0,
             "disjoint_prior_rows_proved_by_disjoint_cutoffs":True,
             "closed_form_unit_checks":test_lift_identity(),"census_old_then_new":nested_transitions(population),
             "panel_old_then_new":nested_transitions(selected),"packet_instruction_sha256":digest(header.encode()),
             "selected_conflicts":sum(v for (a,b),v in selected.items() if a!=b)}
    return p, rows, summary


def freeze(study, required):
    path=study/"FROZEN.json"
    if not required and not path.is_file():return {}
    pins=read(path)
    require({"panel.json","public_packets.jsonl","audit.py"} <= set(pins), "Incomplete freeze registration")
    for name,d in pins.items():
        item=study/name
        require(item.resolve().is_relative_to(study.resolve()) and item.is_file() and
                digest(item.read_bytes())==d,"Frozen dependency mismatch: "+name)
    result={"manifest_sha256":digest(path.read_bytes())}
    if (study/".git").exists():
        def git(*args):
            return subprocess.check_output(["git","-C",str(study),*args])
        commits=git("log","--reverse","--diff-filter=A","--format=%H","--","FROZEN.json").decode().splitlines()
        if commits:
            require(len(commits)==1,"Ambiguous freeze history")
            rev=commits[0]
            for name in ("FROZEN.json", *pins):
                require(git("show",rev+":"+name)==(study/name).read_bytes(),"File differs from freeze commit: "+name)
            result["commit"]=rev
            result["committed_utc"]=datetime.fromtimestamp(int(git("show","-s","--format=%ct",rev)),timezone.utc).isoformat()
        else:
            require(not required,"Final audit before freeze commit")
    return result


def parsed_actions(content):
    try:
        obj=json.loads(content)
    except (TypeError,ValueError):
        return None
    if not isinstance(obj,dict) or set(obj)!={"actions"}: return None
    actions=obj["actions"]
    if type(actions) is list and len(actions)==8 and all(a in ACTIONS for a in actions):
        return actions
    return None


def clock(stamp):
    value=datetime.fromisoformat(stamp)
    require(value.utcoffset() is not None,"Timestamp missing zone")
    return value


def money(nano):
    return f"{nano//1_000_000_000}.{nano%1_000_000_000:09d}"


def check_returns(study, p, rows, reg):
    known={pid+".json" for pid in PACKETS}
    for group in ("attempts","responses"):
        sub=study/group
        require(sub.is_dir() and set(x.name for x in sub.iterdir())==set(TARIFF),"Missing or unexpected reader "+group)
        for provider in TARIFF:
            require({x.name for x in (sub/provider).iterdir()}==known,"Missing/extra "+provider+" "+group)
    out={}
    total_res=total_cost=unpriced=0
    for provider,(it,ot) in TARIFF.items():
        count=Counter()
        answers=Counter()
        previous=None
        for packet in p["packets"]:
            pid=packet["id"]
            j=read(study/"attempts"/provider/(pid+".json"))
            r=read(study/"responses"/provider/(pid+".json"))
            require((j["provider"],j["packet"],j["prompt_sha256"],j["reservation_micro_usd"])==
                    (provider,pid,packet["prompt_sha256"],RESERVE[provider]),"Bad attempt record: "+pid)
            require(all(r[key]==j[key] for key in ("packet","prompt_sha256","started","reservation_micro_usd")) and
                    r.get("arm")==provider,"Receipt identity mismatch: "+pid)
            start,end=clock(j["started"]),clock(r["ended"])
            require(start<=end and (previous is None or previous<=start),"Unordered request timestamps")
            if "committed_utc" in reg:
                require(start>=clock(reg["committed_utc"]),"Request predates freeze")
            previous=end
            reserve=RESERVE[provider]*1000
            total_res+=reserve
            actions=parsed_actions(r.get("content"))
            status=r["status"]
            require((status=="ok")==(actions is not None) and (actions or [])==(r.get("actions") or []),
                    "Public output parse mismatch: "+pid)
            if status in ("ok","invalid_output"):
                require(r.get("http_status")==200 and r["charged_request_sent"] is True, "Missing dispatch evidence")
                if provider=="deepseek":
                    require(r["provider"] in ("deepseek-account","deepseek-official") and r["model"]=="deepseek-flash"
                            and re.fullmatch(r"[a-f0-9]{64}",r["wire_body_sha256"]), "Unexpected DeepSeek route")
                else:
                    require(r["provider"]=="OpenAI" and (r["model"]=="gpt-6.2-sol" or r["model"].startswith("gpt-6.2-sol-"))
                            and r.get("service_tier") in (None,"default","standard"),"Unexpected OpenAI route/tier")
            count["valid_packets" if status=="ok" else "invalid_packets"]+=1
            for key,a in zip(packet["rows"],actions or ["I"]*8):
                answers[rows[key]["new_action"],a]+=1
            use=r.get("usage") or {}
            if use.get("input_tokens") is None or use.get("output_tokens") is None:
                unpriced+=reserve
                count["unpriced_nano"]+=reserve
            else:
                ni,no=use["input_tokens"],use["output_tokens"]
                require(type(ni) is int and 0 <= ni <=4096 and type(no) is int and 0 <= no <=1536,"Out-of-budget usage")
                require(use.get("cached_input_tokens") is None or 0<=use["cached_input_tokens"]<=ni, "Invalid cached token count")
                cost=it*ni+ot*no
                require(cost<=reserve,"Per-packet reservation exceeded")
                total_cost+=cost
                count.update(input_tokens=ni,output_tokens=no,priced_nano=cost)
        out[provider]={"packets":38,"valid_packets":count["valid_packets"],"invalid_packets":count["invalid_packets"],
                       "new_support_then_response":{a:{b:answers[a,b] for b in (*ACTIONS,"I")} for a in ACTIONS},
                       "input_tokens":count["input_tokens"],"output_tokens":count["output_tokens"],
                       "reserved_usd":money(38*RESERVE[provider]*1000),
                       "observed_usage_upper_usd":money(count["priced_nano"]),
                       "unknown_usage_reservation_usd":money(count["unpriced_nano"])}
    require(total_cost+unpriced<=total_res<=TOTAL_LIMIT_NANO,"Aggregate reserved or actual bounds exceeded")
    return {"providers":out,"total_reservations_usd":money(total_res),"total_usage_upper_usd":money(total_cost),
            "total_unpriced_reservations_usd":money(unpriced),"total_upper_usd":money(total_cost+unpriced),
            "cap_usd":money(TOTAL_LIMIT_NANO),"pricing_interpretation":"Standard/peak uncached token-based ceiling; excludes discounts and is not a provider invoice."}


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    mode=cli.add_mutually_exclusive_group(required=True)
    mode.add_argument("--preflight",action="store_true")
    mode.add_argument("--final",action="store_true")
    cli.add_argument("--study",type=Path,default=HERE)
    cli.add_argument("--prior-panel",type=Path)
    cli.add_argument("--output",type=Path)
    args=cli.parse_args()
    study=args.study.resolve()
    prior=args.prior_panel or (study.parent/"frozen-reader-study/frozen/panel.json")
    if args.prior_panel is not None and not prior.is_file():
        raise ValueError("Named prior panel is unavailable")
    p, rows, result=panel_check(study,prior if prior.is_file() else None)
    reg=freeze(study,args.final)
    result["registration"]=reg
    result["stage"]="final" if args.final else "preflight"
    if args.final:result["billing_and_decisions"]=check_returns(study,p,rows,reg)
    body=json.dumps(result,indent=2,sort_keys=True)+"\n"
    if args.output:args.output.write_text(body)
    else: print(body,end="")


if __name__=="__main__":
    main()
