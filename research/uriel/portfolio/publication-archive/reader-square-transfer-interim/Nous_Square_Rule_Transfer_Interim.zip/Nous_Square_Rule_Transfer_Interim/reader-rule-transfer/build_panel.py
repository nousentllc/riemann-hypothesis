"""Construct a deterministic, label-balanced quadratic-rule transfer benchmark."""
import argparse
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
HISTORICAL_SHA = "b6969f3d5d8343edc3f0fbda8c36cb0f09ccbc875e1dd7da8f79d5395c684320"
CUTS = (66, 70, 75, 79, 82, 89, 103, 139, 172, 218)
WRITERS = ("raw27", "opt27", "terminal", "split1", "split8", "full")
TRANSITIONS = tuple(a + b for a in "YNA" for b in "YNA")
QUOTAS = {
    81: {"YN": 32, "AN": 32, "NA": 32, "NY": 44, "AA": 6, "YY": 1, "NN": 21},
    243: {"AN": 32, "NA": 48, "NY": 20, "AA": 14, "NN": 22},
}
# (m, tag, compatible low residues, e) -> cutoff, selected before model dispatch.
ANCHORS = {
    (81, 2, (2,), 4): 79, (243, 2, (2,), 4): 82,
    (81, 3, (3,), 9): 79, (243, 3, (3,), 9): 82,
    (243, 9, (9,), 81): 82, (243, 9, (9, 36, 63), 81): 82,
}
PROMPT = """For each independent row a hidden integer S belongs to 0..242. The saved tag is only a label. R lists exactly the possible remainders of S modulo 81 for that tag. Every integer in the stated range with a listed remainder is possible.

For cutoff Z, m is the smallest power of 3 strictly greater than Z. Here m=81 for Z<81 and m=243 for Z>=81. The hidden answer is yes exactly when the SQUARE of S and e have the same remainder modulo m: S*S = e (mod m).

Return Y if EVERY possible S gives yes, N if EVERY possible S gives no, and A (abstain) if both outcomes are possible. Return only a JSON object with one key "actions" containing the eight ordered Y/N/A strings. No explanation.

Rows (tag, R, Z, e):
"""


def digest(data):
    return sha256(data).hexdigest()


def packed(value):
    return json.dumps(value, separators=(",", ":")).encode()


def rank(domain, identity):
    return digest(packed(["nous-square-transfer-v1", domain, identity]))


def mod(z):
    return 81 if z < 81 else 243


def codebooks():
    small = tuple((r,) for r in range(1, 65))
    residual = (0, *range(65, 81))
    books = {
        "raw27": tuple((r, r+27, r+54) for r in range(27)),
        "opt27": ((residual,) + small[:11]
                  + tuple(tuple(range(i, i+3)) for i in range(12, 33, 3))
                  + tuple(tuple(range(i, i+4)) for i in range(33, 65, 4))),
        "terminal": (residual,) + small,
        "full": tuple((r,) for r in range(81)),
    }
    for width in (1, 8):
        split = residual[1:width+1]
        books[f"split{width}"] = (tuple(r for r in residual if r not in split),) + small + (split,)
    cells = defaultdict(list)
    for name in WRITERS:
        assert sorted(x for cell in books[name] for x in cell) == list(range(81))
        for tag, cell in enumerate(books[name]):
            cells[tag, cell].append(name)
    return cells


def action(yes, size):
    return "N" if yes == 0 else "Y" if yes == size else "A"


def transition_table(counts):
    return {str(m): {tr: counts[m, tr] for tr in TRANSITIONS} for m in (81, 243)}


def rule_counts(rs, modulus):
    old, new = Counter(), Counter()
    for r in rs:
        for s in (r, r+81, r+162):
            old[s % modulus] += 1
            new[s*s % modulus] += 1
    return old, new


def bucket(rs, e, modulus):
    triple = sum(r % 3 == 0 for r in rs)
    kind = "all multiples of three" if triple == len(rs) else "all units" if triple == 0 else "mixed"
    per_residue = [sum(s*s % modulus == e for s in (r, r+81, r+162)) for r in rs]
    varies = any(0 < v < 3 for v in per_residue)
    if varies:
        why = "split and uniform low residues" if any(v in (0, 3) for v in per_residue) else "every low residue splits"
    elif len(set(per_residue)) > 1:
        why = "low residues disagree and each is uniform"
    else:
        why = "all candidates agree"
    return ("singleton" if len(rs)==1 else "multiple", kind, why)


def assemble(historical_path):
    raw = historical_path.read_bytes()
    assert digest(raw) == HISTORICAL_SHA
    previous = json.loads(raw)
    assert set(CUTS).isdisjoint(previous["cutoffs"])
    old_keys = {(mod(r["z"]), r["tag"], tuple(r["residues"]), r["e"]) for r in previous["rows"]}
    cells = codebooks()
    universe, eligible = Counter(), Counter()
    pools = defaultdict(lambda: defaultdict(list))
    records = {}
    bands = {m: [z for z in CUTS if mod(z) == m] for m in (81, 243)}
    for (tag, rs), writers in sorted(cells.items()):
        n = 3*len(rs)
        for m, cutoffs in bands.items():
            old, new = rule_counts(rs, m)
            for e in range(1, max(cutoffs)+1):
                oy, ny = old[e], new[e]
                tr = action(oy, n) + action(ny, n)
                allowed = [z for z in cutoffs if e <= z]
                universe[m, tr] += len(allowed)
                key = (m, tag, rs, e)
                if key in old_keys:
                    continue
                eligible[m, tr] += 1
                stratum = bucket(rs, e, m)
                pools[m, tr][stratum].append(key)
                records[key] = (tr, oy, ny, writers, stratum)

    selected = set(ANCHORS)
    assert selected <= records.keys()
    for m, quotas in QUOTAS.items():
        for tr, quota in quotas.items():
            groups = pools[m, tr]
            taken = Counter(records[k][4] for k in selected if k[0] == m and records[k][0] == tr)
            lists = {g: sorted((k for k in keys if k not in selected),
                               key=lambda k: rank("sample", k), reverse=True) for g, keys in groups.items()}
            g_order = sorted(groups, key=lambda g: rank("stratum", [m,tr,g]))
            while sum(taken.values()) < quota:
                candidates = [g for g in g_order if lists[g]]
                if not candidates:
                    raise ValueError(f"Insufficient {m} {tr} candidates")
                g = min(candidates, key=lambda group: taken[group])
                selected.add(lists[g].pop())
                taken[g] += 1

    assert len(selected) == 304
    per_cutoff = Counter(ANCHORS.values())
    assignments = dict(ANCHORS)
    for key in sorted(selected - ANCHORS.keys(), key=lambda k: rank("assign", k)):
        m, tag, rs, e = key
        legal = [z for z in bands[m] if z >= e]
        z = min(legal, key=lambda z: (per_cutoff[z], rank("cutoff", [key,z])))
        assignments[key] = z
        per_cutoff[z] += 1

    rows = []
    for key in selected:
        m, tag, rs, e = key
        tr, old_yes, new_yes, writers, stratum = records[key]
        z = assignments[key]
        n = 3*len(rs)
        rid = digest(packed([tag, rs, z, e]))[:18]
        rows.append(dict(id=rid,z=z,e=e,tag=tag,residues=list(rs),writers=writers,
                         old_action=tr[0],new_action=tr[1],old_yes=old_yes,old_no=n-old_yes,
                         new_yes=new_yes,new_no=n-new_yes,modulus=m,cell_size=stratum[0],
                         residue_kind=stratum[1],ambiguity_source=stratum[2],anchor=key in ANCHORS))
    assert len({x["id"] for x in rows}) == 304
    rows.sort(key=lambda x: x["id"])
    ordered = sorted(rows, key=lambda x: rank("packet order", x["id"]))
    packets, public = [], []
    for i in range(0, len(ordered), 8):
        batch = ordered[i:i+8]
        lines = [f"{n}. tag={r['tag']}, R={r['residues']}, Z={r['z']}, e={r['e']}"
                 for n, r in enumerate(batch, 1)]
        prompt = PROMPT + "\n".join(lines)
        assert len(prompt.encode()) <= 1644
        pid, checksum = f"p{i//8+1:03}", digest(prompt.encode())
        packets.append(dict(id=pid, rows=[r["id"] for r in batch], prompt_sha256=checksum))
        public.append(dict(packet=pid, prompt=prompt, prompt_sha256=checksum))
    chosen = Counter((r["modulus"],r["old_action"]+r["new_action"]) for r in rows)
    assert all(chosen[m,tr] == QUOTAS[m].get(tr,0) for m in bands for tr in TRANSITIONS)
    panel = dict(rule="S*S = e (mod m)", prior_rule="S = e (mod m)",cutoffs=list(CUTS),
                 historical_sha256=HISTORICAL_SHA, public_codebook_cells=len(cells),
                 universe_unit="distinct (tag,R,Z,e) before exclusions",
                 population_census=transition_table(universe),
                 eligible_unit="distinct (tag,R,m,e), excluding every key in the preceding 304 rows",
                 eligible_census=transition_table(eligible), selected_census=transition_table(chosen),
                 selection="Fixed transition and modulus quotas; anchored controls; round-robin over size, "
                           "divisibility mix and lift ambiguity; hash ranks within strata. Select one eligible "
                           "Z per key balancing cutoff totals, then independently hash-shuffle all rows.",
                 rows=rows, packets=packets)
    return panel, public


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--historical-path",type=Path,default=HERE.parent/"frozen-reader-study/frozen/panel.json")
    parser.add_argument("--output-dir",type=Path,default=HERE)
    args = parser.parse_args()
    panel, public = assemble(args.historical_path)
    args.output_dir.mkdir(exist_ok=True, parents=True)
    (args.output_dir/"panel.json").write_text(json.dumps(panel,indent=2)+"\n")
    (args.output_dir/"public_packets.jsonl").write_text("".join(json.dumps(x)+"\n" for x in public))
    print(json.dumps(panel["selected_census"]))
    print("Maximum prompt bytes:",max(len(x["prompt"].encode()) for x in public))


if __name__ == "__main__":
    main()
