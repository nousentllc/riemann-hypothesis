# Transfer from linear to quadratic residue queries

Start with [the findings](RESULTS.md) or [the complete ledger of unsupported guesses](unsupported_guesses.csv). Each guess has two compatible hidden integers witnessing opposite outcomes. The [row table](decisions.csv) also lists definite answers, explicit abstentions and settled errors, including the action the historical rule would have prescribed.

**Current collection status.** DeepSeek Flash completed all 38 packets. Its 68 guesses on 100 ambiguous records comprise 10 yes and 58 no. Its 117 exact actions include 32 abstentions and 85 settled signs. Its reported usage implies a peak uncached upper cost of USD 0.0052446. The OpenAI arm has zero dispatches while its saved credential awaits local unlock. The two-arm final audit and figure apply after both arms finish.

## A hand check that distinguishes the two rules

Take a record with just the residue 2 modulo 81, cutoff 82 and query 4. The possible integers are 2, 83 and 164. All three fail the old test of equality with 4 modulo 243. Under the new test their squares have remainders 4, 85 and 166. Both truth values occur, so the licensed answer is abstain. A reader that tests only the smallest possible integer would say yes; a reader that carries over the linear rule would say no.

Now use the residue 9 with query 81 at the same cutoff. The candidates 9, 90 and 171 all have square remainder 81 modulo 243. The old test again says no; this time the square test licenses an unconditional yes. These two cases show why a reader cannot pass the conflict set by blindly reversing the old rule or by abstaining whenever the cutoff exceeds 80.

For any listed residue r, the candidate integers are r+81k for k=0,1,2. Their squares modulo 243 are r²+162rk modulo 243. When 3 divides r, the extra term vanishes for every k. Otherwise, the three square remainders are distinct. Below cutoff 81 every lift shares the same square modulo 81. The enumerating generator and the independent algebraic checker implement these calculations separately.

## What counts as transfer

The exact-transfer criterion is a valid and oracle-matching action on every one of the 304 rows. Of these, 240 require a different action from the linear predicate and 64 retain their old action. The new target has 65 yes, 139 no and 100 abstentions. All ten cutoffs are fresh; the panel also excludes every public combination of tag, residue list, effective modulus and query that appeared previously. The new and old aggregate scores describe different challenge distributions. An exact or inexact score on the square panel answers a finite behavioral question; it does not identify a learned algorithm.

The 64 agreement controls include just one yes→yes case, the only remaining eligible such combination. The transition census in panel.json includes the empty cells. All 100 ambiguous records can be divided by the source of ambiguity, including disagreements between listed residues, uncertainty among lifts of every listed residue, and mixtures of split and uniform residues. These counts describe a deliberately selected challenge and one fixed batching order.

## Reproduction

The ZIP includes the prior frozen panel needed to verify disjointness and regenerate the fresh sample. Run these commands from reader-rule-transfer inside the extracted package. They use only Python’s standard library. For Git timing verification, clone study-history.bundle as reader-rule-transfer in a fresh folder next to a copy of frozen-reader-study.

~~~sh
python3 -B build_panel.py --output-dir /tmp/nous-square-rebuilt
python3 -B audit.py --preflight
python3 -B audit.py --final
python3 -B score.py
~~~

The optional chart generator plot_transfer.py uses Pillow. The original public messages are in public_packets.jsonl, the full answer key is in panel.json, and FROZEN.json records the inputs and programs committed before inference. Public answer text and usage totals are retained under responses. Attempts are journaled before dispatch and cannot be repeated by the collection program. No provider contact is required to verify or score a completed package.

**Human–AI collaboration.** Justin Candler commissioned the transfer test, chose the model settings and authorized the combined USD 1.25 cap. Uriel in Codex constructed the challenge, checked the oracle, collected the results and prepared the analysis. The two hosted readers supplied only the recorded experimental responses.
