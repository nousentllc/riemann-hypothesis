"""Run one planned generation per packet through an approved existing credential."""
import argparse
from datetime import datetime, timezone
import fcntl
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import time
from tempfile import NamedTemporaryFile
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
CAP_MICRO_USD = 1_250_000
RATES = {"deepseek": 3_072, "openai": 23_552}
MODELS = {"deepseek": "deepseek-flash", "openai": "gpt-6.2-sol"}


def now():
    return datetime.now(timezone.utc).isoformat()


def write_receipt(path, value):
    with NamedTemporaryFile(mode="w", dir=path.parent, delete=False, suffix=".tmp") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    Path(f.name).replace(path)


def verify_freeze():
    registry = json.loads((ROOT/"FROZEN.json").read_bytes())
    for name, expected in registry.items():
        if sha256((ROOT/name).read_bytes()).hexdigest() != expected:
            raise ValueError("Changed frozen file " + name)
    packets = [json.loads(line) for line in (ROOT/"public_packets.jsonl").read_bytes().splitlines()]
    if [p["packet"] for p in packets] != [f"p{i:03}" for i in range(1, 39)]:
        raise ValueError("Packet order changed")
    for p in packets:
        b = p["prompt"].encode()
        if len(b)>1900 or sha256(b).hexdigest()!=p["prompt_sha256"]:
            raise ValueError("Public message changed")
    return packets


def actions_from(content):
    try:
        obj = json.loads(content)
        if (isinstance(obj, dict) and set(obj)=={"actions"} and isinstance(obj["actions"],list)
                and len(obj["actions"])==8 and all(x in ("Y","N","A") for x in obj["actions"])):
            return obj["actions"]
    except (TypeError, ValueError):
        pass
    return None


def deepseek_call(packet):
    wire = {"packet":packet["packet"],"prompt":packet["prompt"],"model":MODELS["deepseek"],
            "max_output_tokens":1536,"reasoning_effort":"off"}
    result = subprocess.run([str(ROOT/"harness/reader.sh"),"run"],input=json.dumps(wire),
                            text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=420)
    # The adapter emits an allowlisted single JSON event, retaining no private reasoning.
    return json.loads(result.stdout)


class RejectRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        raise RuntimeError("External redirect declined")


def openai_call(packet, credential):
    data = {"model":MODELS["openai"], "messages":[{"role":"user","content":packet["prompt"]}],
            "reasoning_effort":json.loads((ROOT/"settings.json").read_bytes())["openai_reasoning_effort"],"max_completion_tokens":1536,"store":False,"service_tier":"default"}
    request = urllib.request.Request("https://api.openai.com/v1/chat/completions",
              data=json.dumps(data).encode(),headers={"Content-Type":"application/json","Authorization":"Bearer "+credential})
    client = urllib.request.build_opener(urllib.request.ProxyHandler({}), RejectRedirect())
    try:
        with client.open(request,timeout=300) as response:
            body = json.load(response)
    except urllib.error.HTTPError as exc:
        return {"status":"http_error","http_status":exc.code,"charged_request_sent":True}
    choice = body["choices"][0]
    usage = body.get("usage",{})
    return {"status":"ok","model":body.get("model"),"provider":"OpenAI","id":body.get("id"),
            "finish_reason":choice.get("finish_reason"),"http_status":200,"charged_request_sent":True,
            "content":choice["message"].get("content") or "",
            "usage":{"input_tokens":usage.get("prompt_tokens"),"output_tokens":usage.get("completion_tokens"),
                     "cached_input_tokens":(usage.get("prompt_tokens_details") or {}).get("cached_tokens")},
            "service_tier":body.get("service_tier")}


def dispatch(provider, packets, credential):
    attempts_dir = ROOT/"attempts"/provider
    responses_dir = ROOT/"responses"/provider
    attempts_dir.mkdir(parents=True,exist_ok=True)
    responses_dir.mkdir(parents=True,exist_ok=True)
    for packet in packets:
        pid = packet["packet"]
        journal = attempts_dir/(pid+".json")
        receipt_path = responses_dir/(pid+".json")
        if journal.exists():
            if not receipt_path.exists():
                raise RuntimeError("Unresolved reserved packet "+pid+"; refusing repeat")
            rec = json.loads(receipt_path.read_bytes())
            if rec["status"] not in ("ok","invalid_output"):
                raise RuntimeError("Operational stop at "+pid+"; refusing repeat")
            continue
        reserved = sum(json.loads(f.read_bytes())["reservation_micro_usd"] for f in (ROOT/"attempts").glob("*/*.json"))
        if reserved + RATES[provider] > CAP_MICRO_USD or receipt_path.exists():
            raise RuntimeError("Reservation or unique dispatch invariant violated")
        reservation = {"provider":provider,"packet":pid,"prompt_sha256":packet["prompt_sha256"],
                       "started":now(),"reservation_micro_usd":RATES[provider]}
        with journal.open("x") as stream:
            json.dump(reservation,stream)
            stream.flush()
            os.fsync(stream.fileno())
        rec = dict(reservation)
        try:
            returned = deepseek_call(packet) if provider=="deepseek" else openai_call(packet,credential)
            rec.update({k:returned[k] for k in ("status","content","model","provider","usage","http_status","id",
                        "finish_reason","charged_request_sent","service_tier","error_code","wire_body_sha256") if k in returned})
            # Stable identity for scoring independent of the adapter name.
            rec["arm"] = provider
            if returned.get("status") in ("ok","returned"):
                actions = actions_from(returned.get("content"))
                rec["status"] = "ok" if actions is not None else "invalid_output"
                if actions is not None:
                    rec["actions"]=actions
            if returned.get("http_status",200) not in (None,200):
                rec["status"]="http_error"
        except Exception as exc:
            rec.update(status="transport_unknown", error_type=type(exc).__name__, charged_request_sent=None)
        rec["ended"]=now()
        write_receipt(receipt_path,rec)
        print(now(),provider,pid,rec["status"],rec.get("http_status"),flush=True)
        if rec["status"] not in ("ok","invalid_output"):
            raise RuntimeError("Provider request stopped, remaining packets unrun")
        usage = rec.get("usage") or {}
        if (usage.get("input_tokens") or 0)>4096 or (usage.get("output_tokens") or 0)>1536:
            raise RuntimeError("Provider usage exceeded the frozen packet budget")


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("provider", choices=MODELS)
    ap.add_argument("--await-registration",action="store_true",help="hold authorized credential only in process memory until a study registration exists")
    args=ap.parse_args()
    credential=None
    if args.provider=="openai":
        from openai_auth import read_existing
        credential=read_existing()
        if not credential:
            raise SystemExit("Existing key unavailable; no requests were reserved.")
        print("Existing OpenAI key ready; no packet dispatched yet.",flush=True)
    if args.await_registration:
        deadline=time.monotonic()+900
        while not (ROOT/"FROZEN.json").exists() or not subprocess.check_output(
            ["git","-C",str(ROOT),"log","-1","--all","--format=%H","--","FROZEN.json"],
            stderr=subprocess.DEVNULL).strip():
            if time.monotonic()>deadline:
                raise SystemExit("Registration wait expired; no requests dispatched.")
            time.sleep(2)
    packets=verify_freeze()
    commit = subprocess.check_output(["git","-C",str(ROOT),"log","-1","--diff-filter=A","--format=%H","--","FROZEN.json"]).decode().strip()
    if not commit or subprocess.check_output(["git","-C",str(ROOT),"show",commit+":FROZEN.json"])!=(ROOT/"FROZEN.json").read_bytes():
        raise RuntimeError("Registration commit unavailable or changed")
    settings=json.loads((ROOT/"settings.json").read_bytes())
    if args.provider=="openai" and settings["openai_reasoning_effort"] not in ("high","low"):
        raise SystemExit("Sol disabled by the registered configuration.")
    with (ROOT/"dispatch.lock").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        dispatch(args.provider,packets,credential)


if __name__=="__main__":
    main()
