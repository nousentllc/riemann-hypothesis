# Final absorption in the arithmetic core

This private post-hoc check changes the final estimates of the pinned [CoreGm.lean](https://github.com/nousentllc/riemann-hypothesis/blob/40e56bab026552e089d7afcfeff08d2defb9c005/src/Development/AutomorphicArithmetic/PrimitiveCosets/CoreGm.lean). The source file has Git blob `3ba7a590e84c5993882ea6c5dcf9fdbed5f07d4d` and SHA-256 `73abeaad38ed40bde0c2f974f53cae9d851e72d23ae389dea129b2bbddc58bc8`. Through the identification of the main term and the estimate of the remainder, the mathematical argument is inherited. The new source retains both terms before absorption and proves an eventual inequality for arbitrary positive `α` and `eps`.

First run the public [retained-host verification](https://github.com/nousentllc/riemann-hypothesis/blob/9ac7e1b546b132edde02709e1c0af1bfccd40755/research/uriel/experiments/retained-host/REPRODUCE.md). Then run the command below from the private supplement directory, passing the same checkout, source archive, Lean toolchain and Mathlib installation as the public replay. REPLAY_WORK denotes its work directory and REPLAY_JSON denotes its output JSON.

```sh
python3 -B replay_core_budget.py --checkout "$CHECKOUT" --original "$ORIGINAL" \
  --toolchain "$LEAN_ROOT" --mathlib "$MATHLIB" --library "$REPLAY_WORK/lib" \
  --manifest "$REPLAY_JSON"
```

The script authenticates original source and object bytes using the public replay's inventory, compiles the private source and separately replays its resulting module with `leanchecker`. The expected axioms are `propext`, `Classical.choice` and `Quot.sound`. The original package prerequisites follow the public verifier's trust boundary. This supplement has its own two declarations, distinct from the 98-declaration audit of the public experiment.
