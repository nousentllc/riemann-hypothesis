# Research edition evidence

The manuscript is standalone LuaLaTeX. Build it twice from the edition directory. The clickable local evidence links in the PDF refer to the accompanying evidence directory. Some PDF viewers ask before opening local files. The evidence can also be opened directly.

## Reproduce the finite calculations

From the evidence directory, run the following with standard Python 3.11 or later. No network, model weights, or external math packages are required.

```sh
python3 -B witness_distinctions.py > /tmp/witness_distinctions_check.json
cmp witness_distinctions.json /tmp/witness_distinctions_check.json
python3 -B reader_derivations.py changing-cutoff-reader/results.json > /tmp/reader_derivations_check.json
cmp reader_derivations.json /tmp/reader_derivations_check.json
python3 -B changing-cutoff-reader/run.py > /tmp/fitted_trees_check.json
cmp changing-cutoff-reader/results.json /tmp/fitted_trees_check.json
python3 -B changing-cutoff-reader/audit_guard.py > /tmp/guard_check.json
cmp changing-cutoff-reader/audit_guard.json /tmp/guard_check.json
```

The first two programs accompany this revision. The first enumerates all 3,920 placements, all 65,535 two-way refinements, and the Pareto-optimal performance pairs at each of the 17 allowed refinement sizes. The second reads the original saved trees, checks the 81 distinct two-cutoff answer profiles, and independently evaluates both informed trees on both channels. The final two commands refit all six original trees and re-run the separate guard audit. The original reader study and its Markdown references are preserved as archival files. The four runs above are self-contained. The archived unit test also uses a pinned experiment fixture from a checkout at `<edition>/riemann-experiments`.

## Reproduce the Lean calculation

[The added Lean module](CoreBudgetFinal.lean) retains the two terms in the original prime comparison before absorbing a fixed constant. [Dedicated instructions](core_budget.md) describe authenticating the original import closure and replaying the two new theorems. This needs the repository, source archive, and pinned Lean and Mathlib installation used by the public experiment. The earlier 15-module formal replay and the new two-theorem check have separate inventories. [New verification record](core_budget_verification.json) · [Earlier pinned experiment](https://github.com/nousentllc/riemann-hypothesis/tree/9ac7e1b546b132edde02709e1c0af1bfccd40755/research/uriel/experiments/retained-host)

## Reference manuscript

Justin Candler, *Arithmetic Coding, Representation Geometry, and Revisable Memory*, dated November 20, 2026, supplied by the user. Source SHA-256 `aab704e064047b17d275ac88835b2bd510487be2ed0a0b57a566180fd0349b84`. Relevant sections include “An operational definition,” “Discarded information and reader mismatch,” “Query-conditioned geometry and changes in the task law,” and the P7, P9 and P10 experiments. The document supplied the framework and quality benchmark for this edition. Its propositions and experiments have their own stated conditions.

The ZIP is a private local package. Its manuscript and new supplements were prepared independently of the public fork. The root manifest lists a SHA-256 digest and relative path for every other file in the package.
