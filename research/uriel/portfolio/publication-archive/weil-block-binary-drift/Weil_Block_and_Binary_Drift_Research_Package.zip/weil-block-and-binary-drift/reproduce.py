"""Rerun the finite studies and optionally the pinned source and Lean checks.
Usage: python3 -B reproduce.py --help
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parent
BIN=ROOT/'evidence'/'binary'
WEIL=ROOT/'evidence'/'weil'

def python(script,*args):
    proc=subprocess.run([sys.executable,'-B',str(script),*map(str,args)],text=True,capture_output=True)
    if proc.returncode:
        raise RuntimeError(f'{script.name} exited {proc.returncode}\n{proc.stderr}\n{proc.stdout}')
    return proc.stdout

def same(text,stored,keys=None):
    now=json.loads(text);saved=json.loads(stored.read_text())
    if keys is None:
        if now!=saved:raise ValueError(f'Outputs differ: {stored.name}')
    elif any(now[k]!=saved[k] for k in keys):
        raise ValueError(f'Scoped fields differ: {stored.name}')
    print('PASS',stored.name)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,help='original repository content at the pin, including src/')
    parser.add_argument('--repo',type=Path,help='Git checkout with pinned tree objects, used for the second source audit')
    parser.add_argument('--toolchain',type=Path,help='Lean 4.33.1 SDK')
    parser.add_argument('--mathlib',type=Path,help='pinned built Mathlib checkout')
    args=parser.parse_args()
    if args.repo and not args.source:parser.error('--repo also needs --source')
    if args.mathlib and not args.toolchain:parser.error('--mathlib also needs --toolchain')
    with TemporaryDirectory() as tmp:
        work=Path(tmp)
        produced=python(BIN/'drift.py')
        same(produced,BIN/'results.json')
        fresh=work/'fresh.json';fresh.write_text(produced)
        same(python(BIN/'verify_drift.py',fresh),BIN/'verification.json')
        for folder,script,receipt in [(BIN,'horizon.py','horizons.json'),(BIN,'verify_binary_certificate.py','binary_certificate.json'),
            (BIN,'analytic_controls.py','analytic_controls.json'),(BIN,'bayesian_control.py','bayesian_control.json'),(WEIL,'weil_controls.py','weil_controls.json')]:
            same(python(folder/script),folder/receipt)
        if args.source:
            print(python(WEIL/'verify_weil_sources.py',args.source).strip())
        if args.repo:
            audited=work/'bridge.json'
            python(WEIL/'weil_source_audit.py','--source',args.source,'--repo',args.repo,'--out',audited,'--closures')
            same(audited.read_text(),WEIL/'bridge_receipt.json')
        if args.toolchain:
            same(python(BIN/'replay_reachability.py',args.toolchain),BIN/'reachability_replay.json',('source_sha256','compile','replay','theorem_scope'))
        if args.mathlib:
            same(python(WEIL/'replay_weil_support.py','--toolchain',args.toolchain,'--mathlib',args.mathlib),WEIL/'weil_support_receipt.json',('sha256','elaboration','kernel','mathlib_commit'))
        if args.source and args.mathlib:
            target=work/'finite-lean'
            python(WEIL/'replay_weil.py','--source',args.source,'--mathlib',args.mathlib,'--lean',args.toolchain,'--out',target)
            same((target/'slice_receipt.json').read_text(),WEIL/'slice_receipt.json',('source_sha256','mathlib_revision','slices','valid'))
            if (target/'WeilFiniteSlice.lean').read_bytes()!=(WEIL/'WeilFiniteSlice.lean').read_bytes():
                raise ValueError('Pinned extracted module differs')
            print('PASS extracted module bytes')
if __name__=='__main__':
    main()

