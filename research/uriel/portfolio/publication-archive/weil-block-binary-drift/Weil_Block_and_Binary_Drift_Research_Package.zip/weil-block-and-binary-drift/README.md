# Nonvanishing and belief drift
Uriel Research · 23 November 2026

The PDF and the single standalone LuaLaTeX source contain the complete research paper, including its three vector figures and references. The two investigations use different kinds of evidence.

## Results

- The pinned declaration named `compatibleSystem_weilBlock_ne_alt` produces linked-bundle existence. Inside its construction, an occupied source spectral label survives in each matched row. A character overlap provides a nonzero level vector; the stipulated dimension match rules out a zero row space. The reverse inclusion follows from the carrier definitions. A separate positive-rank argument supplies some occupied label when its hypotheses hold. Neither the index nor the coordinates of the original chosen vector were computed.
- For a binary prior and ordered finite caps on KL(updated law ∥ prior law), two monotone one-step recursions give the entire reachable interval. Its endpoints are attained. The maximum final-to-initial KL is the larger endpoint divergence. The hand-checkable path 1/2 → 11/20 → 3/5 attains 0.02013551355 nats using caps that sum to 0.01010197878 nats. Using the same caps, the second update can also return to 1/2.
- With prior one half and a total cap of 1/25 nat split evenly, 30 is the first integer horizon that permits certainty. At 29 the maximum probability is strictly below 0.999972415246. All earlier integer horizons are checked. The paper gives a separate all-priors sufficient condition for a path reaching the boundary.
- Under a designed Bayesian signal tree that respects each cap on every branch, the greatest probability of the exact specified two-step history is approximately 25.0846933%. This is an optimization over signal designs, not an observed frequency.

## Reproduce the finite work

From this folder, with Python 3.11 or newer:

```sh
python3 -B reproduce.py
```

The runner regenerates results in temporary storage and compares parsed outputs with the shipped evidence. It uses only the standard library. Python 3.13.2 was used in the primary run. The protocol for the primary sweep and the separately specified later horizon test indicate when each was formulated.

- `evidence/binary/results.json` gives all 18 schedules, feasible extreme paths, exterior bounds, and the reference controls. Probability coordinates in the integer paths are divided by 10^30.
- `evidence/binary/verification.json` records independent log enclosures, discrete-reachability tests and intentional mutations.
- `evidence/binary/horizons.json` contains a feasible and an outer upper-endpoint column at each step of every horizon from 1 through 30. Divide the integer coordinates by 10^12. A final inner value equal to 1 proves attainment.
- `evidence/binary/binary_certificate.json` is a separate equality-sensitive test that uses integer comparisons. `analytic_controls.json` includes the small-budget expansion, vanishing-prior stress tests and the larger-alphabet transfer. `bayesian_control.json` records the designed-signal construction.
- `evidence/weil/weil_controls.json` records exact finite-group convolutions and a carrier-mask ablation. `weil_source_trace.json` and `bridge_receipt.json` identify original sources and line anchors. The two source inventories overlap.
- `PROVENANCE.json` identifies the pinned mathematical sources, build tools and verification boundaries.

## Reproduce the source and kernel checks

Use an extracted repository tree containing `src/` from commit `40e56bab026552e089d7afcfeff08d2defb9c005`, a Git checkout that can read that commit, the Lean 4.33.1 SDK, and built Mathlib at `0df444a360eaa60ab8c11dca51a86af692955474` for that toolchain. Supply their actual local paths in place of the four environment variables in this command.

```sh
python3 -B reproduce.py --source "$ORIGINAL_TREE" --repo "$PINNED_CHECKOUT" --toolchain "$LEAN_SDK" --mathlib "$BUILT_MATHLIB"
```

The source-only audit can run with just `--source`, or with `--source` and `--repo` for both inventories. The abstract binary recurrence can run with just `--toolchain`. Lean output hashes can depend on the build platform; the driver compares the proof source, successful replays and the specified axiom inventories.

The three Lean modules have distinct roles. `WeilFiniteSlice.lean` is an extraction from four pinned files, checked with Mathlib. `WeilSupport.lean` proves new abstract lemmas for the carrier-support deduction; their application to the original definitions is written in the paper. `Reachability.lean` proves the abstract interval propagation argument. The analytic Bernoulli assumptions and the Bayesian named-path and horizon theorems have written proofs. The full automorphic import closure and RH development were not rebuilt.

## Build the standalone manuscript

```sh
latexmk -lualatex -halt-on-error Nonvanishing_and_Belief_Drift.tex
```

The LuaLaTeX source can be moved to an otherwise empty directory. It has no separate chapter, figure or bibliography files. The PDF uses clickable anchors for the original Lean sources. All results and software in this package are local research artifacts. The shared source manuscripts and the upstream proof were used read-only.

