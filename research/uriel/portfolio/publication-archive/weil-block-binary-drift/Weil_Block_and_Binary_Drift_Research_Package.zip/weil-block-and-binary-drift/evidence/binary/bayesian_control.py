"""Bound probabilities of named Bayesian paths with rational arithmetic.

Positive log arguments are bracketed by outward-rounded decimals. Decimal.ln
is correctly rounded to nearest by Python; its two adjacent representable
neighbors therefore bracket the true logarithm. Every other decision and
bound in this script uses rational arithmetic.
"""
from decimal import Decimal as D, localcontext, ROUND_FLOOR, ROUND_CEILING
from fractions import Fraction as F
from functools import lru_cache
import json


@lru_cache(maxsize=4096)
def log_bounds(x):
    if x == 1:
        return F(0), F(0)
    with localcontext() as c:
        c.prec = 76
        c.rounding = ROUND_FLOOR
        low = (D(x.numerator)/D(x.denominator)).ln().next_minus()
        c.rounding = ROUND_CEILING
        high = (D(x.numerator)/D(x.denominator)).ln().next_plus()
    return F(low), F(high)


def kl_bounds(q, p):
    lower = upper = F(0)
    for a, b in ((q,p), (1-q,1-p)):
        if a == 0:
            continue
        if b == 0:
            raise ValueError("Positive target mass outside prior support")
        l, u = log_bounds(a/b)
        lower += a*l
        upper += a*u
    return lower, upper


def compare_cost(q, target, p):
    if q == target or (p == F(1,2) and q == 1-target):
        return 0
    trial, cap = kl_bounds(q,p), kl_bounds(target,p)
    if trial[1] < cap[0]:
        return -1
    if trial[0] > cap[1]:
        return 1
    raise ArithmeticError("Log enclosures insufficient to order the two costs")


def opposite(p, target):
    if p == F(1,2):
        return 1-target, 1-target
    outside = F(0) if target>p else F(1)
    if compare_cost(outside,target,p)<=0:
        return outside, outside
    inside = p
    for _ in range(90):
        midpoint = (inside+outside)/2
        if compare_cost(midpoint,target,p)<=0:
            inside = midpoint
        else:
            outside = midpoint
    return inside, outside


def outward(x, direction):
    with localcontext() as c:
        c.prec = 80
        c.rounding = direction
        return format((D(x.numerator)/D(x.denominator)).quantize(D("1e-23")), "f")


def show(lo, hi):
    return [outward(lo,ROUND_FLOOR),outward(hi,ROUND_CEILING)]


def test_path(values):
    sequence = list(map(F,values))
    product_low = product_high = F(1)
    rows = []
    for p, q in zip(sequence,sequence[1:]):
        assert p!=q and 0<p<1
        inside, outside = opposite(p, q)
        # Exact posterior martingale construction using the feasible endpoint.
        weight = (p-inside)/(q-inside)
        weight_outer = (p-outside)/(q-outside)
        assert 0<weight<=weight_outer<1
        assert compare_cost(inside,q,p)<=0
        assert weight*q+(1-weight)*inside==p
        pos, neg = weight*q/p, weight*(1-q)/(1-p)
        assert 0<=pos<=1 and 0<=neg<=1
        assert p*pos/(p*pos+(1-p)*neg)==q
        assert p*(1-pos)/(p*(1-pos)+(1-p)*(1-neg))==inside
        too_high = (1+weight_outer)/2
        other = (p-too_high*q)/(1-too_high)
        if 0<=other<=1:
            assert compare_cost(other,q,p)>0
        product_low *= weight
        product_high *= weight_outer
        rows.append(dict(prior=str(p),target=str(q),
                         opposite=show(*sorted((inside,outside))),
                         max_probability=show(weight,weight_outer),
                         likelihood_giventrue=show(pos,weight_outer*q/p),
                         likelihood_givenfalse=show(neg,weight_outer*(1-q)/(1-p))))
    return dict(path=values, steps=rows,
                maximal_named_path_probability=show(product_low,product_high))


def main():
    sets=[["1/2","11/20","3/5"],["1/2","9/20","2/5"],["1/2","3/5","7/10","4/5"]]
    records=[test_path(vals) for vals in sets]
    assert records[0]["maximal_named_path_probability"]==records[1]["maximal_named_path_probability"]
    print(json.dumps(dict(working_log_precision=76,bisections_per_uncapped_branch=90,
                          budgets="exact d(target||prior) for each named step",
                          results=records),indent=2))


if __name__=="__main__":
    main()

