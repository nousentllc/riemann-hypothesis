"""Independent high-precision controls for longer-horizon binary drift formulas."""
from decimal import Decimal, localcontext
import json


D = Decimal
ZERO, ONE, TWO = D(0), D(1), D(2)


def kl_vector(target, source):
    value = ZERO
    for q, p in zip(target, source):
        if q == 0:
            continue
        if p == 0:
            return D("Infinity")
        value += q * (q / p).ln()
    return value


def kl(q, p):
    return kl_vector([q, ONE-q], [p, ONE-p])


def side(p, budget, sign):
    if p in (ZERO, ONE) or budget == ZERO:
        return p
    outside = ONE if sign == 1 else ZERO
    if kl(outside, p) <= budget:
        return outside
    inside = p
    for _ in range(180):
        midpoint = (inside + outside) / TWO
        if kl(midpoint, p) <= budget:
            inside = midpoint
        else:
            outside = midpoint
    return (inside + outside) / TWO


def schedule(p, budgets, sign):
    path = [p]
    for budget in budgets:
        path.append(side(path[-1], budget, sign))
    return path


def small_budget_control():
    p = D(".2")
    a = [ONE, D(4), D(9)]
    s = sum(x.sqrt() for x in a)
    total = sum(a)
    v = p*(ONE-p)
    rows = []
    previous = {}
    for h in map(D, [".01", ".005", ".0025", ".00125"]):
        for sign in (-1, 1):
            e = [h*h*x for x in a]
            q = schedule(p, e, sign)[-1]
            prob_prediction = (p + sign*h*(TWO*v).sqrt()*s + h*h*(ONE-TWO*p)*(s*s/TWO-total/D(6)))
            div_prediction = h*h*s*s + sign*h**3*(ONE-TWO*p)*(TWO/v).sqrt()*s*(s*s-total)/D(6)
            prob_error = abs(q-prob_prediction)
            div_error = abs(kl(q,p)-div_prediction)
            row = dict(h=h, direction=sign, q=q, probability_residual=prob_error,
                       endpoint_kl=kl(q,p), divergence_residual=div_error)
            if sign in previous:
                prob_ratio = previous[sign][0] / prob_error
                div_ratio = previous[sign][1] / div_error
                assert 7 < prob_ratio < 9
                assert 14 < div_ratio < 18
                row.update(probability_residual_ratio=prob_ratio, divergence_residual_ratio=div_ratio)
            previous[sign] = (prob_error, div_error)
            rows.append(row)
    return rows


def rare_prior_control():
    a = b = D(".1")
    rows = []
    for M in map(D, ["10", "100", "10000", "1000000"]):
        q = a / M
        r = b / (M/a).ln()
        p = (-M).exp()
        def initial_div(z):
            return z*(z.ln()+M)+(ONE-z)*((ONE-z).ln()-(ONE-p).ln())
        first, second, final = initial_div(q), kl(r,q), initial_div(r)
        assert first <= a and second <= b and final >= r*M-TWO.ln()
        rows.append(dict(M=M, q=q, r=r, step1=first, step2=second, endpoint=final))
    return rows


def four_outcome_control():
    p = [D(".5"), D(".6"), D(".7"), D(".8")]
    budgets = [kl(t, s) for s, t in zip(p, p[1:])]
    rows = []
    for size in range(5):
        start = D(size) / 4
        path = schedule(start, budgets, +1)
        rows.append(dict(initial_event_size=size, initial=start, final=path[-1], gain=path[-1]-start))
    winner = max(rows, key=lambda row: row["gain"])
    assert winner["initial_event_size"] == 1
    path = schedule(D(".25"), budgets, +1)
    lifted = [[x, (1-x)/3, (1-x)/3, (1-x)/3] for x in path]
    residuals = [abs(kl_vector(q,p) - e) for p,q,e in zip(lifted,lifted[1:],budgets)]
    assert max(residuals) < D("1e-50")
    tv = sum(abs(x-y) for x,y in zip(lifted[0],lifted[-1]))/TWO
    assert abs(winner["gain"]-tv)<D("1e-50")
    return dict(by_event_size=rows, winning_history=lifted, largest_kl_residual=max(residuals), attained_tv=tv)


def printable(obj):
    if isinstance(obj, Decimal):
        return format(obj, ".24g")
    raise TypeError(type(obj).__name__)


def main():
    with localcontext() as context:
        context.prec = 76
        results = dict(decimal_precision=76,
                       small_budget=small_budget_control(),
                       rare_prior=rare_prior_control(),
                       four_outcome=four_outcome_control())
    print(json.dumps(results, default=printable, indent=2))


if __name__ == "__main__":
    main()

