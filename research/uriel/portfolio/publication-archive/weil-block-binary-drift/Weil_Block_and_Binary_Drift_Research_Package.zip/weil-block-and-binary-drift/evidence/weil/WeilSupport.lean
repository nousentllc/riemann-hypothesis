import Mathlib.Order.CompleteLattice.Basic

/-! Supplemental order-theoretic reconstruction of the support implication.
The two lattices can be subspaces of different representations. -/

namespace Uriel.WeilSupport

universe u v w

theorem zeroRowOfZeroSource {C : Type u} {E : Type v} {W : Type w}
    [CompleteLattice E] [CompleteLattice W]
    (e : C → E) (row : C → W) (carries : C → Prop)
    (occupied : ∀ c, carries c → e c ≠ ⊥)
    (emptySource : (⨆ c, ⨆ (_ : carries c), e c) = ⊥) :
    (⨆ c, ⨆ (_ : carries c), row c) = ⊥ := by
  apply le_antisymm _ bot_le
  apply iSup_le
  intro c
  apply iSup_le
  intro hc
  have hcLe : e c ≤ ⨆ k, ⨆ (_ : carries k), e k :=
    le_iSup_of_le c (le_iSup_of_le hc le_rfl)
  rw [emptySource] at hcLe
  exact False.elim (occupied c hc (le_antisymm hcLe bot_le))

theorem sameSupport {C : Type u} {E : Type v} {W : Type w}
    [CompleteLattice E] [CompleteLattice W]
    (e : C → E) (row : C → W) (carries : C → Prop)
    (occupied : ∀ c, carries c → e c ≠ ⊥)
    (forward : (⨆ c, ⨆ (_ : carries c), e c) ≠ ⊥ →
      (⨆ c, ⨆ (_ : carries c), row c) ≠ ⊥) :
    ((⨆ c, ⨆ (_ : carries c), e c) ≠ ⊥) ↔
      (⨆ c, ⨆ (_ : carries c), row c) ≠ ⊥ :=
  ⟨forward, fun hrow hzero => hrow (zeroRowOfZeroSource e row carries occupied hzero)⟩

theorem oneLabelForAllRows {P I : Type*} (active : P → Prop) (present : I → P → Prop)
    (transfer : ∀ p, active p → ∀ i, present i p)
    (seed : ∃ p, active p) :
    ∃ p, active p ∧ ∀ i, present i p := by
  obtain ⟨p, hp⟩ := seed
  exact ⟨p, hp, transfer p hp⟩

#print axioms zeroRowOfZeroSource
#print axioms sameSupport
#print axioms oneLabelForAllRows

end Uriel.WeilSupport

