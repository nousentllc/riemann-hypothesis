"""Generate dyadic-free fixed decimal grid enclosures for a specified Bernoulli prior.
Run with Python 3.11+; only the standard library is used. The independent
checker in verify_drift.py verifies the bounds with rational log enclosures.
"""
import argparse
import json
from decimal import Decimal as D, localcontext, ROUND_CEILING, ROUND_FLOOR
from functools import lru_cache
from pathlib import Path

PLACES = 30
UNIT = 10**PLACES
SCHEDULES = {
    **{f"half_{n}": ("0.5", ["0.005"] * n) for n in (1, 2, 4, 8)},
    **{f"prior_{p}": (p, ["0.005"] * 4) for p in ("0.1", "0.3", "0.7", "0.9")},
    "small_large": ("0.3", ["0.001", "0.03"]),
    "large_small": ("0.3", ["0.03", "0.001"]),
    "zero_insert": ("0.5", ["0.005", "0", "0.005"]),
    "zero_total": ("0.37", ["0", "0"]),
    "no_steps": ("0.37", []),
    "up_saturates": ("0.9", ["0.11", "0.001"]),
    "down_saturates": ("0.1", ["0.11", "0.001"]),
    "both_saturate": ("0.5", ["0.7", "0.01"]),
    "zero_prior": ("0", ["0.7", "1"]),
    "one_prior": ("1", ["0.7", "1"]),
}
@lru_cache(maxsize=8192)
def log_value(x):
    return x.ln()

def kl(q, p):
    if q == p:
        return D(0)
    if p == 0 or p == 1:
        return D('Infinity')
    a = q * (log_value(q) - log_value(p)) if q else D(0)
    b = (1-q) * (log_value(1-q) - log_value(1-p)) if q != 1 else D(0)
    return a+b

def gridnum(v):
    return D(v)/UNIT

def extremal_pair(center, cap, upper):
    """Return (feasible grid point, outward bound) on the chosen side."""
    outward = UNIT if upper else 0
    if center in (0, UNIT) or cap == 0:
        return center, center
    prior = gridnum(center)
    if kl(gridnum(outward), prior) <= cap:
        return outward, outward
    inside = center
    while abs(outward-inside) > 1:
        candidate = (outward+inside)//2
        if kl(gridnum(candidate), prior) <= cap:
            inside = candidate
        else:
            outward = candidate
    return inside, outward

def iterate(prior, caps):
    lo_in = lo_out = hi_in = hi_out = int(D(prior)*UNIT)
    trail = []
    for text_cap in caps:
        cap = D(text_cap)
        lo_in = extremal_pair(lo_in, cap, False)[0]
        lo_out = extremal_pair(lo_out, cap, False)[1]
        hi_in = extremal_pair(hi_in, cap, True)[0]
        hi_out = extremal_pair(hi_out, cap, True)[1]
        trail.append(dict(lo_outer=lo_out, lo_path=lo_in, hi_path=hi_in, hi_outer=hi_out))
    p = D(prior)
    def fmt(n, upper=False):
        return format(n.quantize(D('1e-24'), rounding=ROUND_CEILING if upper else ROUND_FLOOR), 'f')
    return dict(prior=prior, budgets=caps, steps=trail,
                kl_lower=fmt(max(kl(gridnum(lo_in),p),kl(gridnum(hi_in),p))),
                kl_upper=fmt(max(kl(gridnum(lo_out),p),kl(gridnum(hi_out),p)), True),
                tv_lower=fmt(max(p-gridnum(lo_in),gridnum(hi_in)-p)),
                tv_upper=fmt(max(p-gridnum(lo_out),gridnum(hi_out)-p), True))

def controls():
    p,q,r=map(D,['0.5','0.55','0.60'])
    e,f=kl(q,p),kl(r,q)
    opposite=p  # Same second cap permits a return to the initial law.
    def ds(x): return format(x,'.22f')
    a=[D('0.2'),D('0.3'),D('0.1'),D('0.4')]
    lifted=[D('0.24'),D('0.36'),D('0.08'),D('0.32')]
    hidden=[D('0.35'),D('0.15'),D('0.1'),D('0.4')]
    def full(x,y): return sum(v*(v/w).ln() for v,w in zip(x,y))
    return {
        'rational_witness':dict(path=[str(p),str(q),str(r)],
              caps=[ds(e),ds(f)],cap_sum=ds(e+f),endpoint=ds(kl(r,p)),
              exact_excess=ds((r-q)*((q/(1-q)).ln()-(p/(1-p)).ln())),
              reversal=dict(p2=str(opposite),charge=ds(kl(opposite,q)),endpoint=ds(kl(opposite,p)))),
        'rare_prior':[dict(M=int(m), q=ds(D('.1')/m), r=ds(D('.1')/(m/D('.1')).ln()), step1=ds(kl(D('.1')/m,(-m).exp())),step2=ds(kl(D('.1')/(m/D('.1')).ln(),D('.1')/m)),endpoint=ds(kl(D('.1')/(m/D('.1')).ln(),(-m).exp()))) for x in [10,100,1000,10000] for m in [D(x)]],
        'categorical':dict(prior=list(map(str,a)),lift=list(map(str,lifted)),
             lift_KL=ds(full(lifted,a)),event_KL=ds(kl(D('.6'),D('.5'))),
             hidden_change=list(map(str,hidden)),hidden_event_KL='0',hidden_full_KL=ds(full(hidden,a))),
    }

def result():
    with localcontext() as ctx:
        ctx.prec=80
        return dict(grid_denominator=str(UNIT), schedules={k:iterate(p,b) for k,(p,b) in SCHEDULES.items()}, controls=controls())

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path)
    args=ap.parse_args()
    serialized=json.dumps(result(),indent=2,sort_keys=True)+'\n'
    if args.out: args.out.write_text(serialized,encoding='utf-8')
    else: print(serialized,end='')
if __name__=='__main__':
    main()

