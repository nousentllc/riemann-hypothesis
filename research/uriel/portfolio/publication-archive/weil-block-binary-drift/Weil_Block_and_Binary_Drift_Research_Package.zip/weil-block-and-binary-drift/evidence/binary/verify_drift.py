"""Independent interval proofs and finite-grid controls. Standard library only.
Series bounds use integers and fractions. Decimal logarithms play no role in
accepting an endpoint certificate. Run this script without Python -O.
"""
import argparse
from fractions import Fraction as F
from functools import lru_cache
import json
import math
from pathlib import Path

BASE=10**70
TERMS=68
def ceildiv(a,b): return -(-a//b)

def reduced_log(x):
    """Certified log on [1,2] using 2 atanh((x-1)/(x+1))."""
    assert 1<=x<=2
    z=(x-1)/(x+1)
    lo=(z.numerator*BASE)//z.denominator
    hi=ceildiv(z.numerator*BASE,z.denominator)
    sl=lo*lo//BASE
    sh=ceildiv(hi*hi,BASE)
    al=ah=0
    for j in range(1,2*TERMS,2):
        al+=2*lo//j
        ah+=ceildiv(2*hi,j)
        lo=lo*sl//BASE
        hi=ceildiv(hi*sh,BASE)
    j=2*TERMS+1
    ah+=ceildiv(9*BASE,4*j*3**j)  # 2 z^j / (j(1-z^2)), z <= 1/3
    return al,ah

@lru_cache(maxsize=4096)
def log_bounds(x):
    assert x>0
    k=x.numerator.bit_length()-x.denominator.bit_length()
    m=x/F(2)**k
    if m<1:
        m*=2
        k-=1
    a,b=reduced_log(m)
    c,d=LOG2
    if k<0:c,d=d,c
    return F(a+k*c,BASE),F(b+k*d,BASE)
LOG2=reduced_log(F(2))

def kb(q,p):
    if p==q:return F(0),F(0)
    if p in (0,1):return math.inf,math.inf
    lo=hi=F(0)
    for a,b in ((q,p),(1-q,1-p)):
        if a:
            l,h=log_bounds(a/b)
            lo+=a*l
            hi+=a*h
    return lo,hi

def check_case(case,unit):
    p0=F(case['prior']); caps=list(map(F,case['budgets']))
    assert len(caps)==len(case['steps'])
    prev=[p0]*4
    tests=0
    for cap,row in zip(caps,case['steps']):
        cur=[F(row[key],unit) for key in ('lo_outer','lo_path','hi_path','hi_outer')]
        assert 0<=cur[0]<=cur[1]<=p0<=cur[2]<=cur[3]<=1
        for i,(a,b) in enumerate(zip(prev,cur)):
            assert b<=a if i<2 else a<=b
            if cap==0 or a in (0,1):
                assert a==b
            elif i in (1,2):
                assert kb(b,a)[1]<=cap
                tests+=1
            elif b not in (0,1):
                assert kb(b,a)[0]>cap
                tests+=1
        prev=cur
    l,li,ui,u=prev
    assert F(case['kl_lower'])<=max(kb(li,p0)[0],kb(ui,p0)[0])
    assert F(case['kl_upper'])>=max(kb(l,p0)[1],kb(u,p0)[1])
    assert F(case['tv_lower'])<=max(p0-li,ui-p0)
    assert F(case['tv_upper'])>=max(p0-l,u-p0)
    return tests,max(li-l,u-ui)

def finite_dp(n, prior, caps):
    """Enumerate all feasible edges, with binary64 logs independent of the inverse."""
    i=int(prior*n);assert F(i,n)==prior
    reached={i}
    pts=[j/n for j in range(n+1)]
    min_margin=math.inf
    for e in caps:
        more=set()
        for i in sorted(reached):
            p=pts[i]
            if p in (0,1):
                more.add(i)
                continue
            for j,q in enumerate(pts):
                val=(q*math.log(q/p) if q else 0)+((1-q)*math.log((1-q)/(1-p)) if q!=1 else 0)
                margin=abs(val-e)
                min_margin=min(min_margin,margin)
                if val<=e: more.add(j)
        reached=more
    assert len(reached)==max(reached)-min(reached)+1
    return F(min(reached),n),F(max(reached),n),min_margin

def run(data):
    unit=int(data['grid_denominator']); rows=data['schedules']
    total=0; width=F(0)
    for case in rows.values():
        count,w=check_case(case,unit); total+=count;width=max(width,w)
    for x,y in [('prior_0.1','prior_0.9'),('prior_0.3','prior_0.7'),('down_saturates','up_saturates')]:
        for l,r in zip(rows[x]['steps'],rows[y]['steps']):
            for a,b in [('lo_outer','hi_outer'),('lo_path','hi_path'),('hi_outer','lo_outer'),('hi_path','lo_path')]:
                assert l[a]+r[b]==unit
    assert rows['half_2']['steps'][-1]==rows['zero_insert']['steps'][-1]
    controls={}
    for name in ['half_2','prior_0.3','small_large','large_small']:
        case=rows[name];prior=F(case['prior']);caps=list(map(float,case['budgets']))
        ref=case['steps'][-1]
        prev_l=prev_u=prior
        vals=[]
        for n in (50,100,200,400,800):
            l,u,m=finite_dp(n,prior,caps)
            assert F(ref['lo_outer'],unit)<=l<=prev_l<=prev_u<=u<=F(ref['hi_outer'],unit)
            assert m>1e-12
            vals.append(dict(grid=n,lower=str(l),upper=str(u),distance_from_threshold_min=float('%.6g'%m)))
            prev_l,prev_u=l,u
        controls[name]=vals
    p,q,r=F(1,2),F(11,20),F(3,5)
    e=kb(q,p);f=kb(r,q);d=kb(r,p)
    assert kb(p,q)[1]<f[0] and d[0]>e[1]+f[1]
    cx=log_bounds((q/(1-q))/(p/(1-p)))
    assert d[0]-e[1]-f[1]<=(r-q)*cx[1] and d[1]-e[0]-f[0]>=(r-q)*cx[0]
    # A backward test would charge a different amount even for the first step.
    assert kb(p,q)[0]>e[1]
    import copy
    rejected=[]
    for key,change in [('infeasible path',('hi_path',unit)),('false outer bound',('hi_outer',int(.51*unit)))]:
        altered=copy.deepcopy(rows['half_1'])
        altered['steps'][0][change[0]]=change[1]
        try:check_case(altered,unit)
        except AssertionError:rejected.append(key)
        else:raise AssertionError('corrupted certificate was accepted')
    # Pass monotone ordering but fail the crucial outward/nonfeasible log test.
    fake=copy.deepcopy(rows['half_1'])
    fake['steps'][0]['hi_outer']=fake['steps'][0]['hi_path']
    try:check_case(fake,unit)
    except AssertionError:rejected.append('feasible point used as strict exterior')
    else:raise AssertionError('strict exterior test failed')
    return dict(schedules=len(rows),steps=sum(len(v['steps']) for v in rows.values()),
                rational_sign_checks=total,largest_enclosure_width=str(width),grid_controls=controls,
                exact_witness_and_reversal=True,wrong_kl_direction_distinguished=True,rejected_mutations=rejected)

if __name__=='__main__':
    if not __debug__:raise SystemExit('Run verification without -O.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file',nargs='?',type=Path,default=Path(__file__).with_name('results.json'))
    parser.add_argument('--out',type=Path)
    args=parser.parse_args();s=json.dumps(run(json.loads(args.file.read_text())),indent=2,sort_keys=True)+'\n'
    if args.out: args.out.write_text(s)
    else: print(s,end='')

