/- Structural core of the binary KL reachability argument.
   Each remaining analytic obligation is an explicit field of RevisionBand.
   This file uses Lean's core library only. -/
import Init

namespace GemaRevision

structure OrderLaws (α : Type) (le : α → α → Prop) : Prop where
  refl : ∀ x, le x x
  trans : ∀ {x y z}, le x y → le y z → le x z
  antisymm : ∀ {x y}, le x y → le y x → x = y
  total : ∀ x y, le x y ∨ le y x

structure RevisionBand (α : Type) (le : α → α → Prop) where
  lower : α → α
  upper : α → α
  lower_mono : ∀ {x y}, le x y → le (lower x) (lower y)
  upper_mono : ∀ {x y}, le x y → le (upper x) (upper y)
  holds_lower : ∀ x, le (lower x) x
  holds_upper : ∀ x, le x (upper x)

variable {α : Type} {le : α → α → Prop}

def lowerEnd (s : Nat → RevisionBand α le) (p : α) : Nat → α
  | 0 => p
  | n + 1 => (s n).lower (lowerEnd s p n)

def upperEnd (s : Nat → RevisionBand α le) (p : α) : Nat → α
  | 0 => p
  | n + 1 => (s n).upper (upperEnd s p n)

def Reach (s : Nat → RevisionBand α le) (p : α) : Nat → α → Prop
  | 0, q => q = p
  | n + 1, q =>
    ∃ y, Reach s p n y ∧ le ((s n).lower y) q ∧ le q ((s n).upper y)

theorem stay (s : Nat → RevisionBand α le) (p : α) (n : Nat) :
    Reach s p n p := by
  induction n with
  | zero => rfl
  | succ n ih => exact ⟨p, ih, (s n).holds_lower p, (s n).holds_upper p⟩

theorem reachable_iff_between (ord : OrderLaws α le)
    (s : Nat → RevisionBand α le) (p : α) (n : Nat) :
    ∀ q, Reach s p n q ↔ le (lowerEnd s p n) q ∧ le q (upperEnd s p n) := by
  induction n with
  | zero =>
    intro q
    change q = p ↔ le p q ∧ le q p
    constructor
    · intro h
      cases h
      exact ⟨ord.refl p, ord.refl p⟩
    · intro h
      exact ord.antisymm h.2 h.1
  | succ n ih =>
    intro q
    constructor
    · intro h
      obtain ⟨y, hy, hl, hu⟩ := h
      obtain ⟨hyl, hyu⟩ := (ih y).1 hy
      exact ⟨ord.trans ((s n).lower_mono hyl) hl,
             ord.trans hu ((s n).upper_mono hyu)⟩
    · intro h
      have center := (ih p).1 (stay s p n)
      have span := ord.trans center.1 center.2
      have reachedLower := (ih _).2 ⟨ord.refl _, span⟩
      have reachedUpper := (ih _).2 ⟨span, ord.refl _⟩
      cases ord.total q (lowerEnd s p n) with
      | inl ql =>
        exact ⟨lowerEnd s p n, reachedLower, h.1,
               ord.trans ql ((s n).holds_upper _)⟩
      | inr lq =>
        cases ord.total (upperEnd s p n) q with
        | inl uq =>
          exact ⟨upperEnd s p n, reachedUpper,
                 ord.trans ((s n).holds_lower _) uq, h.2⟩
        | inr qu =>
          exact ⟨q, (ih q).2 ⟨lq, qu⟩,
                 (s n).holds_lower q, (s n).holds_upper q⟩

#print axioms GemaRevision.reachable_iff_between

end GemaRevision

