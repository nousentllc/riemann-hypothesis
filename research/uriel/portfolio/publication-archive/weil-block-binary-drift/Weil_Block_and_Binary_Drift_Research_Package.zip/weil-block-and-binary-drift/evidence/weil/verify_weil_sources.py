"""Authenticate selected source files from a checkout or unpacked source archive."""
import argparse
import hashlib
import json
from pathlib import Path


def verify(root, manifest):
    files = json.loads(manifest.read_text())["files"]
    for row in files:
        contents = (root / row["path"]).read_bytes()
        oid = hashlib.sha1(b"blob " + str(len(contents)).encode() + b"\0" + contents).hexdigest()
        if oid != row["git_blob"] or hashlib.sha256(contents).hexdigest() != row["sha256"]:
            raise ValueError("file mismatch: " + row["path"])
        lines = contents.splitlines(keepends=True)
        for span in row["line_spans"]:
            excerpt = b"".join(lines[span["start"]-1:span["end"]])
            if hashlib.sha256(excerpt).hexdigest() != span["sha256"]:
                raise ValueError("line span mismatch: " + row["path"])
    return len(files)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("checkout", type=Path, help="root containing the pinned src/ directory")
    cli.add_argument("--manifest", type=Path, default=Path(__file__).with_name("weil_source_trace.json"))
    args = cli.parse_args()
    print("Authenticated", verify(args.checkout, args.manifest), "source files.")

