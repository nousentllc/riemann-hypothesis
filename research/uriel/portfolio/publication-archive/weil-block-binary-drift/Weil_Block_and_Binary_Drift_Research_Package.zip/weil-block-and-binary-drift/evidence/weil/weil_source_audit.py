"""Authenticate the Weil-bridge source and check the explicitly identified handoffs.

Requires an extracted source tree and a checkout containing the pinned Git tree.
Adds no files to either input. Optionally count transitive project imports.
"""
import argparse
from collections import deque
import hashlib
import json
from pathlib import Path
import re
import subprocess

PIN='40e56bab026552e089d7afcfeff08d2defb9c005'
GITHUB=f'https://github.com/nousentllc/riemann-hypothesis/blob/{PIN}/'
AUTO='src/Development/AutomorphicArithmetic/'
THIRD=AUTO+'ThetaCorrespondence/ThetaPairLifts/ThirdPlaceSeries/'
AV='src/Development/AbelianVarietyTheory/'
TW=AV+'Definitions/GlobalTwisting/'
MODULES={
 'member':THIRD+'MemberBundlesLargeUnramifiedExponents.lean',
 'base':THIRD+'ExistsBaseLatticeOfPrime.lean',
 'at':THIRD+'ExtensionWithAtProperty.lean',
 'transport':THIRD+'IsBuiltEPrmAIff.lean',
 'weil':THIRD+'ExistsWeilBlockNeAtMember.lean',
 'slots':AV+'Definitions/AutomorphicMembership/ThetaChr.lean',
 'exbl':TW+'EventuallyAllScaleContextsAndOfBoth.lean',
 'exb':TW+'ValidForConstructedPointClassesEventuallyWorking.lean',
 'link':THIRD+'TwistedBundle.lean',
 'hyps':THIRD+'HypothesesNonemptyOfUnramifiedExponents.lean',
 'rows':THIRD+'NonemptyHypsOfAllRows.lean',
 'selection':AUTO+'CharacterBoxes/ClassSel.lean',
 'local':THIRD+'ExistsSelectionPairLocalLanglands.lean',
 'rowlift':AV+'Proofs/IwasawaDecomposition/RowPartFormsAndNonzeroVectorsEveryPlace.lean',
 'idem':'src/Formalism/LocalToGlobal/Divisibility/GoodPartHermitianSpec.lean',
 'proj':'src/Formalism/LocalToGlobal/Divisibility/ProjLemmas.lean',
 'char':AV+'Proofs/DivisorProofs/ChiIdemMulLvlIdemBaseNeZero.lean',
 'vector':AV+'Proofs/SatakeParameters/ExistsLevelVectorGoodTypeStableSubspace.lean',
}
ANCHORS=[
 ('at',16,17,['NormChoiceExtension','× PLift (A K B f T)']),
 ('transport',18,27,['builtExtendByAutomorphy','PLift.up a','isBuiltE_extensionWithAtProperty_iff']),
 ('transport',28,53,['isGoodE_extensionWithAtProperty_iff','EvLgG A','Step.of_evLgG','SecondG.sAnd_of_largeBase']),
 ('slots',85,103,['def BuiltE','def GoodE','def MemberE','FirstG KPx','SecondG KPx']),
 ('base',57,72,['exists_baseLattice_of_prime_alt','extensionWithOrigin','MemberE','GlobalTheory.Fc.ExBL','GeometricNormExtension']),
 ('member',34,40,['SiegelMassRatioCM','MemberE','ExBL KPx','IsBuiltE','IsGoodE','BundleLinkage','EvLgG A']),
 ('member',59,63,['memberE_extensionWithAtProperty_of_evLgG','member_exists_baseLattice_alt hA hE hH hW hL hN cDep hM).1','compatibleSystem_weilBlock_ne_alt','slot_mv_extension_with_origin_geo_cl']),
 ('weil',24,33,['exists_weilBlock_ne_at_member_alt','Nonempty','PositionMv','ExBL KPx','geometric_parameter_uniform_alt','rfl']),
 ('exbl',40,45,['def sAnd','def LargeBaseCondition','Q K','→ R K']),
 ('exbl',65,86,['def RowL','def ExBL','∃ R : V4.Slot','LargeBaseCondition KP Q R ∧ ExB','RowL.elim','r.and r\'']),
 ('exb',254,262,['def QOf','def ExB','∀ β : BPt K','β.Is Q → ∀ c : ℝ, ∃ b : Bd β.D β.O c, Lk K β c b','def RowE']),
 ('exb',277,279,['def pick','Classical.choose (cls_at']),
 ('exb',360,366,['QOf₂','let ⟨b, hb⟩ := H.1 β hq c','H.2 β hq c b hb','Row.elim','pick_isSel']),
 ('link',44,49,['structure TwistedBundle','eq :','realPackageOfBundle']),
 ('link',57,76,['structure BundleWitness','ax : HEq a.x x','recPin','eF : HEq','d3b : HEq','def BundleLinkage','Nonempty']),
 ('hyps',41,44,['EvLgG A','obtain ⟨hP, hMem, hEx⟩','large_unramified_exponent_bundles_exist_alt']),
 ('hyps',54,61,['have hAll','nonempty_hyps_of_allRows_alt','(fun _ => hMem) hEx hAll']),
 ('rows',47,59,['obtain ⟨𝒜, σ, hE, hD','UpperTheory.Top.classSel','hc hx hall','𝒜 := 𝒜','σ := σ','hEx :=']),
 ('selection',14,25,['ExBL','RowL.elim hx hr','Row.elim hx\' hr\'','pick (sAnd Q\' R) Lk E','hH','memberTop_final_contextParameters']),
 ('local',40,48,['wp3_ne_bot_and_piece_at_of_multEq','EEp3 p\' ≠ ⊥','Wp3 i p\' ≠ ⊥','rowPart_forms_and_nonzero_vectors_every_place']),
 ('rowlift',16,32,['hA :=','dimParts i p','finrank_bot','exists_nonzero_rational_lift_mem_base_part']),
 ('char',147,163,['chiIdem_mul_lvlIdem_ne_zero','coeff 1','mul_left_cancel₀']),
 ('vector',117,145,['theorem exists_level_vector','U ≠ ⊥','∀ χ ∈ X','U.map (ρ g) ≤ U','u ≠ 0']),
]
def sha(b):
    return hashlib.sha256(b).hexdigest()

def git_tree(repo,paths):
    p=subprocess.run(['git','-C',str(repo),'ls-tree','-r','-z',PIN,'--',*paths],check=True,capture_output=True)
    out={}
    for line in p.stdout.split(b'\0'):
        if line:
            tag,filename=line.split(b'\t')
            out[filename.decode()]=tag.split()[2].decode()
    return out

def verify_source(src,repo):
    tree=git_tree(repo,MODULES.values())
    raw={k:(src/f).read_bytes() for k,f in MODULES.items()}
    files={}
    for k,b in raw.items():
        obj=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        file=MODULES[k]
        if obj!=tree[file]: raise ValueError('Git blob differs at '+file)
        files[k]=dict(path=file,git_blob=obj,sha256=sha(b),size_bytes=len(b))
    records=[]
    for name,start,end,tokens in ANCHORS:
        part=b''.join(raw[name].splitlines(keepends=True)[start-1:end])
        if any(x not in part.decode() for x in tokens):
            raise ValueError('Anchor differs at '+str((name,start,end)))
        records.append(dict(key=name,start=start,end=end,sha256=sha(part),tokens=tokens,url=GITHUB+MODULES[name]+f'#L{start}-L{end}'))
    return files,records

def implication_domain_controls():
    # Pointwise logical skeleton after eventual context and final slot are fixed.
    # A finite Q' domain and incidence relation represent eligible points and links.
    from itertools import product
    points=(0,1); bundles=(0,1)
    rows=[]
    for domain_mask,links_mask in product(range(4),range(16)):
        ok=lambda x: bool(domain_mask & (1<<x))
        lk=lambda x,b: bool(links_mask & (1<<(2*x+b)))
        supply=all((not ok(x)) or any(lk(x,b) for b in bundles) for x in points)
        example_exists=any(ok(x) and lk(x,b) for x,b in product(points,bundles))
        rows.append((domain_mask,links_mask,supply,example_exists))
    assert all(s and not e for d,lk,s,e in rows if d==0)
    assert all(e for d,lk,s,e in rows if d!=0 and s)
    # Distinct choices with disjoint indices cannot discharge the conjunction.
    local_properties=[(True,False),(False,True)]
    assert all(any(row[j] for row in local_properties) for j in (0,1))
    assert not any(a and b for a,b in local_properties)
    return dict(finite_contexts=len(rows),pointwise_supply_cases=sum(r[2] for r in rows),
                empty_domain_supply_cases=sum(r[2] for r in rows if not r[0]),
                nonempty_domain_supply_gives_link=sum(r[2] for r in rows if r[0]),
                disjoint_witness_control='Both individual existential statements hold. No common index has both properties.')

def closure(src,name):
    # Published sources here use one regular import per line. Count only project paths;
    # this is a syntactic estimate, independent of kernel-term dependency.
    pattern=re.compile(rb'(?m)^\s*(?:(?:public|private|meta|all)\s+)*import\s+(?:all\s+)?([A-Za-z0-9_.\x80-\xff]+)')
    root=src/'src'; groups={p.name for p in root.iterdir() if p.is_dir()}
    q=deque([MODULES[name][4:-5].replace('/','.')]); seen=set()
    while q:
        mod=q.popleft()
        if mod in seen: continue
        b=(root.joinpath(*mod.split('.')).with_suffix('.lean')).read_bytes()
        seen.add(mod)
        for m in pattern.findall(b):
            token=m.decode()
            if token.split('.')[0] in groups and token not in seen: q.append(token)
    return len(seen)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',type=Path,required=True)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--out',type=Path)
    ap.add_argument('--closures',action='store_true')
    a=ap.parse_args()
    files,anchors=verify_source(a.source,a.repo)
    out=dict(pin=PIN,files=files,anchors=anchors,finite_controls=implication_domain_controls())
    if a.closures: out['textual_project_import_closure_including_target']={x:closure(a.source,x) for x in ('member','local','hyps')}
    out['audit_scope']='Git-pinned source, text anchors and separate finite controls. Kernel checks, where applicable, have a separate receipt.'
    text=json.dumps(out,indent=2,ensure_ascii=False)+'\n'
    if a.out: a.out.write_text(text)
    else: print(text,end='')
if __name__=='__main__': main()
