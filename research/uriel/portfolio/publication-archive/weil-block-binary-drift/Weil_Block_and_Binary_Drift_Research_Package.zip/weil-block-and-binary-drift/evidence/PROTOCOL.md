# Study design recorded before the numerical sweep
23 November 2026 (America/Detroit). The candidate theorem, the previously examined three-point example, and the first source-signature observation were known before this file was written. This is a prediction and control record for the new computations, not a claim of blind discovery.

## Weil source and checks
Use the original Git tree 40e56bab026552e089d7afcfeff08d2defb9c005. Compare the full type of compatibleSystem_weilBlock_ne_alt with its name, locate the supplying and consuming declarations, and distinguish membership at the base parameters from the strengthened parameters. Follow any literal nonzero predicate to its object and assumptions, including conditions on witnesses and vacuous cases. Kernel checks count only for declarations actually replayed. The source trace is useful even if the theorem yields no explicit numerical sample.

## Drift estimand
KL always uses the updated binary law in the first slot and the preceding law in the second slot. Logs are natural. Fix the initial probability and the ordered list of nonnegative finite step budgets. Predict that successive lower and upper one-step extrema are reachable, enclose all other endpoints, and attain the maximum final-to-initial KL at one of their ends. No fitted or empirical memory parameters enter these claims.

## Predictions and controls
1. Compute 1, 2, 4 and 8 equal steps from one half at budget 0.005 per step. Compare against the sum of the budgets, the exact feasible endpoint interval, and the total-variation path estimate. At 2 steps the sum of the two KL budgets should understate maximum endpoint KL.
2. Repeat at priors 0.1, 0.3, 0.7, 0.9 and under a permutation of unequal budgets. Compare complements, zero budgets, both absorbing endpoints and saturation at 0 or 1. Keep each order in the record even if it performs worse.
3. On finite grids compare the continuous envelope with an independent enumeration of all feasible successors at each step; refine the grid. Require containment, nesting on refinements, and an independent log-sign certificate for continuous inner and outer paths. Include deliberate mutation of direction, a certificate lying inside the bound in the wrong role, and an infeasible path.
4. Exhibit exact rational revisions from 1/2 to 11/20 to 3/5 under budgets given by their own divergences. Verify the exact upper path, its reflected competitor, and the three-point identity. Compare to an opposite-direction second step under the same caps.
5. Distinguish a nominated-event probability in a larger belief space from the divergence of the full belief state. Check a small lift with unchanged conditional distributions and a same-event-mass control with changed within-event odds.
6. Analyze dependence on the known prior and the number of steps. No finite test alone licenses the continuum theorem or a claim about an operating memory system.

