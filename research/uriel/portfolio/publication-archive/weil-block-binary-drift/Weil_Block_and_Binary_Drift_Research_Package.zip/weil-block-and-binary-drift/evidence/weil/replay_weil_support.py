"""Replay the new abstract support lemmas against cached Lean/Mathlib 4.33.1."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def replay(toolchain, mathlib):
    source=Path(__file__).with_name('WeilSupport.lean').resolve()
    toolchain=toolchain.resolve()
    mathlib=mathlib.resolve()
    with tempfile.TemporaryDirectory(prefix='uriel-weil-support-') as name:
        work=Path(name)
        shutil.copyfile(source,work/source.name)
        libs=[work,mathlib/'.lake/build/lib/lean',*sorted((mathlib/'.lake/packages').glob('*/.lake/build/lib/lean'))]
        env=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,libs)),LEAN_SYSROOT=str(toolchain),
                 PATH=str(toolchain/'bin')+os.pathsep+os.environ['PATH'])
        def run(args):
            p=subprocess.run(args,cwd=work,env=env,check=True,capture_output=True,text=True)
            return (p.stdout+p.stderr).strip()
        version=run(['lean','--version'])
        if '4.33.1' not in version:
            raise ValueError('Expected Lean 4.33.1')
        mathlib_commit=run(['git','-C',str(mathlib),'rev-parse','HEAD'])
        if mathlib_commit != '0df444a360eaa60ab8c11dca51a86af692955474':
            raise ValueError('Expected the mathlib revision recorded by this study')
        elaboration=run(['lean','--root=.','-o','WeilSupport.olean','WeilSupport.lean'])
        checked=run(['leanchecker','-v','WeilSupport'])
        targets=['zeroRowOfZeroSource','sameSupport','oneLabelForAllRows']
        if checked != 'replaying WeilSupport' or any(
                "'Uriel.WeilSupport."+t+"' does not depend on any axioms" not in elaboration for t in targets):
            raise ValueError('Unexpected kernel replay or axiom inventory')
        return dict(lean=version,mathlib_commit=mathlib_commit,elaboration=elaboration,kernel=checked,
                    sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                    scope='New abstract order-theoretic transfer and quantifier lemmas; written specialization to the pinned subspaces.')


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--toolchain',required=True,type=Path)
    cli.add_argument('--mathlib',required=True,type=Path)
    args=cli.parse_args()
    print(json.dumps(replay(args.toolchain,args.mathlib),indent=2))

