"""Verify an attained GEMA schedule on a rational grid using integer arithmetic.

The input budgets are KL divergences of named rational pairs. Each comparison
reduces to comparing a product of positive integer powers against one.
No logarithms or floating point values decide any enumerated transition.
"""
from fractions import Fraction as F
from functools import reduce
from math import lcm
import json


def kl_terms(q, p):
    """Return log-linear rational terms; None denotes positive infinity."""
    terms = []
    for u, v in ((q, p), (1-q, 1-p)):
        if u == 0:
            continue
        if v == 0:
            return None
        terms.append((u, u/v))
    return terms


def compare_logs(left, right):
    """Compare two extended nonnegative KL expressions exactly."""
    if left is None or right is None:
        return (left is None) - (right is None)
    signed = list(left) + [(-a, r) for a, r in right]
    denominator = reduce(lcm, (a.denominator for a, _ in signed), 1)
    product = F(1)
    for weight, ratio in signed:
        exponent = weight * denominator
        assert exponent.denominator == 1
        product *= ratio ** int(exponent)
    return (product > 1) - (product < 1)


def exact_grid_control(denominator):
    witness = [F(1, 2), F(3, 5), F(7, 10), F(4, 5)]
    step_budgets = [kl_terms(q, p) for p, q in zip(witness, witness[1:])]
    nodes = [F(i, denominator) for i in range(denominator + 1)]
    frontier = {witness[0]}
    edges_tested = 0
    rows = []
    for step, budget in enumerate(step_budgets, 1):
        next_frontier = set()
        for p in sorted(frontier):
            for q in nodes:
                edges_tested += 1
                if compare_logs(kl_terms(q, p), budget) <= 0:
                    next_frontier.add(q)
        frontier = next_frontier
        target = {q for q in nodes if 1-witness[step] <= q <= witness[step]}
        if frontier != target:
            raise AssertionError((step, sorted(frontier ^ target)))
        rows.append(dict(step=step, lower=str(min(frontier)),
                         upper=str(max(frontier)), grid_states=len(frontier)))
    assert compare_logs(kl_terms(witness[-1], witness[0]), sum(step_budgets, [])) > 0
    assert compare_logs(kl_terms(F(0), F(0)), []) == 0
    assert compare_logs(kl_terms(F(1, 2), F(0)), step_budgets[0]) > 0
    assert compare_logs(kl_terms(F(1, 2), F(1)), step_budgets[0]) > 0
    return dict(denominator=denominator, edges_checked=edges_tested, layers=rows)


def main():
    results = [exact_grid_control(scale) for scale in (10, 20, 50, 100)]
    print(json.dumps(dict(method="exact integer comparisons of log-linear expressions",
                          grids=results, total_edges_checked=sum(row["edges_checked"] for row in results)),
                     indent=2))


if __name__ == "__main__":
    main()

