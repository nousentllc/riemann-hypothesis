"""Replay selected verbatim original finite-algebra proofs with pinned Mathlib."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

SETTINGS = ["-DautoImplicit=false", "-DrelaxedAutoImplicit=false", "-DmaxSynthPendingDepth=3", "-Dpp.unicode.fun=true", "-DmaxHeartbeats=4000000", "--tstack=400000"]
GD = 'src/Formalism/LocalToGlobal/Divisibility/GoodPartHermitianSpec.lean'
PJ = 'src/Formalism/LocalToGlobal/Divisibility/ProjLemmas.lean'
ID = 'src/Development/AbelianVarietyTheory/Proofs/DivisorProofs/ChiIdemMulLvlIdemBaseNeZero.lean'
LV = 'src/Development/AbelianVarietyTheory/Proofs/SatakeParameters/ExistsLevelVectorGoodTypeStableSubspace.lean'
PREFIX = 'https://github.com/nousentllc/riemann-hypothesis/blob/40e56bab026552e089d7afcfeff08d2defb9c005/'
TARGETS = ['Formalism.L2.DIV.schur_scalar','GlobalTheory.GoodTypeGeneric.chiIdem_mul_lvlIdem_ne_zero','GlobalTheory.Hk3.Meet.coeff_chiIdem_mul_lvlIdem','GlobalTheory.Hk3.exists_level_vector']
SLICES = [
    "import Mathlib\nnoncomputable section\nopen Module NumberField IsDedekindDomain\nopen scoped TensorProduct InnerProductSpace Matrix ComplexOrder\nnamespace Formalism.L2.DIV",
    (GD, 15, 29), (PJ,317,322), (PJ,606,612), (PJ,623,632), (PJ,669,671), (PJ,810,820),
    "end Formalism.L2.DIV\nopen Formalism.L2.DIV\nnamespace GlobalTheory.GoodTypeGeneric",
    (ID,147,163), "end GlobalTheory.GoodTypeGeneric", (LV,16,204),
]
def digest(b):
    return hashlib.sha256(b).hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',type=Path,required=True,help='extracted original repository with src/')
    ap.add_argument('--mathlib',type=Path,required=True,help='pinned checkout with .lake/build/lib/lean')
    ap.add_argument('--lean',type=Path,required=True,help='pinned toolchain root')
    ap.add_argument('--out',type=Path,required=True,help='scratch output directory')
    args=ap.parse_args()
    src, mathlib, tc, out=(x.resolve() for x in (args.source,args.mathlib,args.lean,args.out))
    out.mkdir(parents=True,exist_ok=True)
    libs=[out,mathlib/'.lake/build/lib/lean',*sorted((mathlib/'.lake/packages').glob('*/.lake/build/lib/lean'))]
    env=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,libs)), LEAN_SYSROOT=str(tc), PATH=str(tc/"bin")+os.pathsep+os.environ["PATH"])
    known = {
        GD: '89f10f2aa200ccd749b878d4bddb9bdb85ef3a0f33f801f0797e024f7ab71e17', PJ: '6cae7fdb0f88090708e9b9e47ab2726fb7637742bdc1a9e5177400fa5dc65101', ID: '72ef9261e6b97fe2abaea2987ddee8465ec30a5fd2178f83737a8d295a7198b5', LV: '3edc253452e5ad5410914ca28e151c1cb6b4143f13238df48eb9a394cb08fd5e'
    }
    extracts=[]; pieces=[]
    for s in SLICES:
        if isinstance(s,str):
            pieces.append(s+'\n')
            continue
        filename, start, end=s
        f=(src/filename).read_bytes()
        if digest(f)!=known[filename]: raise ValueError('Pinned source digest mismatch: '+filename)
        block=b''.join(f.splitlines(keepends=True)[start-1:end])
        pieces.append(block.decode())
        extracts.append(dict(source=filename,start=start,end=end,source_sha256=digest(f),slice_sha256=digest(block),url=PREFIX+filename+f'#L{start}-L{end}'))
    pieces.append('\n'.join('#print axioms '+x for x in TARGETS)+'\n')
    leanfile=out/'WeilFiniteSlice.lean'
    leanfile.write_text('\n'.join(pieces))
    def run(tool,*args):
        p=subprocess.run([str(tc/'bin'/tool),*args],env=env,cwd=out,capture_output=True,text=True)
        return dict(args=[tool,*args],status=p.returncode,stdout=p.stdout,stderr=p.stderr)
    version=run('lean','--version')
    git=subprocess.run(['git','-C',str(mathlib),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
    if 'version 4.33.1' not in version['stdout'] or git!='0df444a360eaa60ab8c11dca51a86af692955474':
        raise RuntimeError('Lean toolchain or Mathlib revision mismatch')
    commands=[run('lean',*SETTINGS,'--root=.','-o','WeilFiniteSlice.olean','WeilFiniteSlice.lean')]
    if commands[0]['status']==0:
        commands.append(run('leanchecker','-v','WeilFiniteSlice'))
    valid=all(x['status']==0 for x in commands) and len(commands)==2 and all(f"'{x}' depends on axioms: [propext, Classical.choice, Quot.sound]" in commands[0]['stdout'] for x in TARGETS) and commands[-1]['stdout'].strip()=='replaying WeilFiniteSlice'
    receipt=dict(interpretation='Selected unmodified original declaration texts in a fresh namespace-equivalent module, relying on cached pinned Mathlib. No upstream module object or full build claimed.', mathlib_revision=git,lean_version=version['stdout'].strip(),source_sha256=digest(leanfile.read_bytes()),slices=extracts,commands=commands,valid=valid)
    (out/'slice_receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
    for c in commands: print(c['status'],c['stdout'][-1700:],c['stderr'][-350:])
    if not valid: raise SystemExit(1)
if __name__=='__main__': main()
