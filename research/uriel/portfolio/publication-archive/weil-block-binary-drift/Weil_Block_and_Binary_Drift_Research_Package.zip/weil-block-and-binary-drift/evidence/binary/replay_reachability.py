"""Elaborate and replay the abstract recurrence, using only the given Lean SDK."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory


def replay(prefix):
    toolchain = Path(prefix).expanduser().resolve()
    source = Path(__file__).with_name("Reachability.lean").read_bytes()
    with TemporaryDirectory() as temp:
        work = Path(temp)
        (work / "Reachability.lean").write_bytes(source)
        env = os.environ.copy()
        env.update(PATH=str(toolchain / "bin") + os.pathsep + env["PATH"],
                   LEAN_SYSROOT=str(toolchain),
                   LEAN_PATH=os.pathsep.join([str(work), str(toolchain / "lib/lean")]))
        def run(program, *args):
            return subprocess.check_output([str(toolchain / "bin" / program), *args],
                                           env=env, cwd=work, text=True,
                                           stderr=subprocess.STDOUT, timeout=90).strip()
        version = run("lean", "--version")
        compile_log = run("lean", "--root=.", "-o", "Reachability.olean", "Reachability.lean")
        replay_log = run("leanchecker", "-v", "Reachability")
        wording = "'GemaRevision.reachable_iff_between' does not depend on any axioms"
        if compile_log != wording or replay_log != "replaying Reachability":
            raise RuntimeError((compile_log, replay_log))
        return dict(lean=version, module="Reachability", only_import="Init",
                    source_sha256=hashlib.sha256(source).hexdigest(),
                    object_sha256=hashlib.sha256((work / "Reachability.olean").read_bytes()).hexdigest(),
                    compile=compile_log, replay=replay_log, theorem_scope=
                    "Ordered, monotone, reflexive revision bands with linearly ordered states; binary KL specialization is a written proof.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("toolchain", help="path to the Lean SDK containing bin/lean and bin/leanchecker")
    args = parser.parse_args()
    print(json.dumps(replay(args.toolchain), indent=2))


if __name__ == "__main__":
    main()

