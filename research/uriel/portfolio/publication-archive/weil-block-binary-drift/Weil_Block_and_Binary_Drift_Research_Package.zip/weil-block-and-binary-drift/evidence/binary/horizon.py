"""Fixed sum B=1/25 at prior one half. Propose one-sided endpoint
enclosures with binary64 bisection; require rational certificates for every link.
"""
import argparse
import json
import math
from fractions import Fraction as F
from pathlib import Path
from verify_drift import kb
N=10**12

def proposals(center,e):
    if center==N:return N,N
    p=center/N
    if -math.log(p)<=float(e):return N,N
    lo,hi=center,N
    while hi-lo>1:
        mid=(lo+hi)//2
        q=mid/N
        v=q*math.log(q/p)+(1-q)*math.log((1-q)/(1-p))
        if v<=float(e):lo=mid
        else:hi=mid
    return max(center,lo-3),min(N,hi+3)

def classify(t,budget):
    e=budget/t
    inner=outer=N//2
    path=[]
    tests=0
    for _ in range(t):
        i=proposals(inner,e)[0]
        o=proposals(outer,e)[1]
        assert inner<=i<=o<=N and outer<=o
        assert kb(F(i,N),F(inner,N))[1]<=e
        tests+=1
        if o!=N:
            assert kb(F(o,N),F(outer,N))[0]>e
            tests+=1
        inner,outer=i,o
        path.append([i,o])
    assert inner==N or outer<N, 'inconclusive: refine grid or proposal'
    return dict(T=t,cap=str(e),upper_in=inner,upper_out=outer,reaches_one=inner==N,certified_edges=tests,bounds=path)

def run():
    budget=F(1,25)
    results=[]
    for t in range(1,101):
        row=classify(t,budget)
        results.append(row)
        if row['reaches_one']:break
    assert results[-1]['reaches_one']
    return dict(prior='1/2',total_budget=str(budget),grid=N,first_horizon=results[-1]['T'],cases=results)

if __name__=='__main__':
    if not __debug__:raise SystemExit('Use Python without -O.')
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path)
    args=p.parse_args();s=json.dumps(run(),indent=2)+'\n'
    if args.out:args.out.write_text(s)
    else:print(s,end='')

