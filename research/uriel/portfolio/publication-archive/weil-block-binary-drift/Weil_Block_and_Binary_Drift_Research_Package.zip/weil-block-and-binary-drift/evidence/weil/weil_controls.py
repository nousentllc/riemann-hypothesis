"""Exact finite controls for character and level projectors on S_3.

Run with Python 3.9+ and no third-party packages. The result on standard output
is a group-algebra calculation. It does not take a limit or instantiate an
automorphic host.
"""
import itertools
import json
from fractions import Fraction


def compose(left, right):
    """Compose permutations, acting on column vectors from the left."""
    return tuple(left[right[i]] for i in range(len(left)))


def inverse(g):
    return tuple(g.index(i) for i in range(len(g)))


def sign(g):
    inversions = sum(x > y for i,x in enumerate(g) for y in g[i + 1:])
    return (-1) ** inversions


def product(a, b, elements):
    answer = {g: Fraction() for g in elements}
    for g, first in a.items():
        for h, second in b.items():
            answer[compose(g, h)] += first * second
    return answer


def assert_equal(actual, expected):
    if actual != expected:
        raise ValueError((actual, expected))


def carrier_control():
    """Three possible joint eigenpackets, retaining their zero/nonzero pattern."""
    counts = dict(all=0, typed=0, typed_reverse_fail=0,
                  reverse_fail_without_typing=0, typed_forward_fail_without_transfer=0)
    for carriers, source, row in itertools.product(range(8), repeat=3):
        typed = (carriers & ~source) == 0
        has_source = bool(carriers & source)
        has_row = bool(carriers & row)
        counts["all"] += 1
        counts["typed"] += int(typed)
        counts["typed_reverse_fail"] += int(typed and has_row and not has_source)
        counts["reverse_fail_without_typing"] += int(has_row and not has_source)
        counts["typed_forward_fail_without_transfer"] += int(typed and has_source and not has_row)
    assert_equal(list(counts.values()), [512, 216, 0, 91, 61])
    return counts


def run():
    elements = tuple(itertools.permutations(range(3)))
    identity, swap = (0, 1, 2), (1, 0, 2)
    chars = {
        "trivial": lambda g: 1,
        "sign": sign,
        "standard": lambda g: sum(i == j for i, j in enumerate(g)) - 1,
    }
    # Every subgroup type up to conjugacy. Trivial/sign restrictions suffice
    # for the listed rational linear level characters; no claim about all C3 characters.
    settings = [
        ("trivial", (identity,), {"trivial": chars["trivial"]}),
        ("C2", (identity,swap), {"trivial": chars["trivial"], "sign":sign}),
        ("C3", tuple(g for g in elements if sign(g)==1), {"trivial":chars["trivial"]}),
        ("S3", elements, {"trivial":chars["trivial"], "sign":sign}),
    ]
    outputs = []
    for label,chi in chars.items():
        central = {g: Fraction(chi(identity)*chi(inverse(g)),len(elements)) for g in elements}
        assert_equal(product(central,central,elements),central)
        for subgroup,P,level_chars in settings:
            for level_label,psi in level_chars.items():
                level = {g: Fraction(psi(inverse(g)),len(P)) if g in P else Fraction() for g in elements}
                assert_equal(product(level,level,elements),level)
                c = product(central,level,elements)
                assert_equal(c,product(level,central,elements))
                assert_equal(c,product(c,c,elements))
                m = sum(Fraction(chi(h),psi(h)) for h in P)/len(P)
                assert_equal(c[identity],Fraction(chi(identity),len(elements))*m)
                assert_equal(any(c.values()),m!=0)
                outputs.append(dict(irrep=label,subgroup=subgroup,level_character=level_label,
                                    multiplicity=int(m),identity_coefficient=str(c[identity]),
                                    nonzero=any(c.values())))
    def record(chi, P, psi):
        return next(row for row in outputs if (row['irrep'], row['subgroup'], row['level_character']) == (chi, P, psi))
    assert_equal(record('standard','C2','trivial')['identity_coefficient'],'1/3')
    assert_equal(record('standard','C2','sign')['identity_coefficient'],'1/3')
    assert_equal(record('trivial','C2','sign')['nonzero'],False)
    assert_equal(record('standard','trivial','trivial')['multiplicity'],2)
    assert_equal(record('standard','C3','trivial')['multiplicity'],0)
    return dict(group='S3',group_order=len(elements),cases=len(outputs),
        nonzero_products=sum(x['nonzero'] for x in outputs),cases_detail=outputs,
        carrier_control=carrier_control())


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, ensure_ascii=False, sort_keys=True))

