"""Score fixed local readers on the frozen record-query panel (standard library)."""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import re
from tempfile import NamedTemporaryFile

HERE = Path(__file__).resolve().parent
ACTIONS = ("Y", "N", "A")
OUTPUTS = (*ACTIONS, "I")


def read(path):
    return json.loads(path.read_bytes())


def require(test, message):
    if not test:
        raise ValueError(message)


def unique_by(items, key):
    indexed = {item[key]: item for item in items}
    require(len(indexed) == len(items), f"Duplicate {key} values")
    return indexed


def validate_panel(panel):
    rows = unique_by(panel["rows"], "id")
    packets = unique_by(panel["packets"], "id")
    coverage = Counter(k for pkt in packets.values() for k in pkt["rows"])
    require(coverage == Counter({k: 1 for k in rows}), "Packets must cover every row exactly once")
    for pid, packet in packets.items():
        calculated = sha256(packet["prompt"].encode("utf-8")).hexdigest()
        require(calculated == packet["prompt_sha256"], f"Frozen prompt hash mismatch for {pid}")
    for row in rows.values():
        y, n = row["yes"], row["no"]
        require(type(y) is int and type(n) is int and y >= 0 and n >= 0 and y+n > 0, row["id"])
        require(1 <= row["e"] <= row["z"] and row["z"] >= 64, row["id"])
        expected = "N" if y == 0 else "Y" if n == 0 else "A"
        require(row["action"] == expected, f"Inconsistent support for {row['id']}")
    links = panel["links"]
    require(set(k["row"] for k in links) == set(rows), "Writer links must cover all rows")
    for link in links:
        require(link["z"] == rows[link["row"]]["z"], "Writer link has a different cutoff")
    return rows, packets


def load_predictions(study, packets, expected_models):
    all_actions, receipts, packet_hashes = {}, {}, {}
    parent = study / "responses"
    frozen_models = read(study / "frozen" / "models.json")
    declared_tags = {short: conf["tag"] for short, conf in frozen_models.items()}
    if expected_models:
        require(expected_models == declared_tags, "Requested reader cohort differs from frozen/models.json")
    expected_models = declared_tags
    require(len(expected_models) >= 2, "At least two models are required for a paired release")
    for short, declared in expected_models.items():
        actions, model_id, status_counts = {}, None, Counter()
        for pid, pkt in packets.items():
            path = parent / short / (pid + ".json")
            if not path.is_file():
                raise ValueError(f"Missing packet {path}")
            result = read(path)
            require(result["rows"] == pkt["rows"], f"Row identity/order differs in {path}")
            outputs = result["actions"]
            require(len(outputs) == len(pkt["rows"]) and all(a in OUTPUTS for a in outputs),
                    f"Every frozen row needs one parsed action or I in {path}")
            digest = result["prompt_sha256"]
            require(re.fullmatch(r"[a-f0-9]{64}", digest), f"Invalid prompt SHA in {path}")
            expected_hash = pkt["prompt_sha256"]
            require(digest == expected_hash, f"Prompt differs in {path}")
            packet_hashes[pid] = digest
            if "digest" in result:
                require(result["digest"] == frozen_models[short]["digest"], f"Model digest differs in {path}")
            require(isinstance(result["model"], str) and bool(result["model"]), f"No model in {path}")
            model_id = model_id or result["model"]
            require(result["model"] == model_id and (declared is None or model_id == declared),
                    f"Model differs in {path}")
            status_counts[result["status"]] += 1
            actions.update(zip(pkt["rows"], outputs))
        receipts[short] = {"model": model_id, "packets_by_status": dict(sorted(status_counts.items()))}
        all_actions[short] = actions
    require(len({x["model"] for x in receipts.values()}) == len(receipts), "Repeated model ID")
    return all_actions, receipts, packet_hashes


def fraction_text(value):
    if value is None:
        return None
    return f"{value.numerator}/{value.denominator}"


def ratio(numerator, denominator):
    return fraction_text(Fraction(numerator, denominator)) if denominator else None


def metrics(ids, rows, outputs):
    confusion = {s: dict.fromkeys(OUTPUTS, 0) for s in ACTIONS}
    lucky = Fraction(0)
    truth_credit = Fraction(0)
    for k in ids:
        r, answer = rows[k], outputs[k]
        target = r["action"]
        confusion[target][answer] += 1
        if answer in ("Y", "N"):
            credit = Fraction(r["yes"] if answer == "Y" else r["no"], r["yes"] + r["no"])
            truth_credit += credit
            if target == "A":
                lucky += credit
    y, n, a = (confusion[t] for t in ACTIONS)
    ambiguous = sum(a.values())
    settled = len(ids) - ambiguous
    correct = y["Y"] + n["N"]
    guesses = a["Y"] + a["N"]
    definite = sum(g["Y"] + g["N"] for g in (y, n, a))
    return {
        "n": len(ids),
        "ambiguous": ambiguous, "unsupported_guesses": guesses, "unsupported_rate": ratio(guesses, ambiguous),
        "correct_abstentions": a["A"], "invalid_ambiguous": a["I"],
        "settled": settled, "settled_correct": correct, "settled_correct_rate": ratio(correct, settled),
        "settled_positive": sum(y.values()), "settled_positive_correct": y["Y"],
        "settled_negative": sum(n.values()), "settled_negative_correct": n["N"],
        "settled_wrong_sign": y["N"] + n["Y"], "settled_abstentions": y["A"] + n["A"],
        "invalid_settled": y["I"] + n["I"], "total_invalid": y["I"] + n["I"] + a["I"],
        "licensed_actions_correct": correct + a["A"], "definite_answers": definite,
        "guesses_expected_true_count": fraction_text(lucky),
        "expected_hidden_truth_credit_all_rows": fraction_text(truth_credit),
        "expected_hidden_truth_accuracy_when_definite": fraction_text(truth_credit/definite) if definite else None,
        "confusion_target_then_response": confusion
    }


def pair_comparison(ids, rows, left, right):
    by_outcome = {}
    for category, targets in (("abstains_on_ambiguity", {"A"}), ("correct_on_settled", {"Y", "N"})):
        count = Counter()
        for k in ids:
            expected = rows[k]["action"]
            if expected in targets:
                a, b = left[k] == expected, right[k] == expected
                count["both" if a and b else "left_only" if a else "right_only" if b else "neither"] += 1
        by_outcome[category] = {k:count[k] for k in ("both", "left_only", "right_only", "neither")}
    by_outcome["different_actions"] = sum(left[k] != right[k] for k in ids)
    return by_outcome


def score(study, expected_models):
    panel_path = study / "frozen" / "panel.json"
    panel = read(panel_path)
    rows, packets = validate_panel(panel)
    predictions, receipts, hashes = load_predictions(study, packets, expected_models)
    models = list(predictions)
    controls = {
        "support_oracle": {k:r["action"] for k, r in rows.items()},
        "always_no": dict.fromkeys(rows, "N"),
        "always_abstain": dict.fromkeys(rows, "A"),
        "forced_majority": {k:("Y" if r["yes"] > r["no"] else "N") for k, r in rows.items()}
    }
    require(not set(models) & controls.keys(), "Model alias collides with baseline")
    writers = defaultdict(set)
    for link in panel["links"]:
        writers[link["writer"]].add(link["row"])
    packet_map = {k:pid for pid,pkt in packets.items() for k in pkt["rows"]}
    strata = {"fresh": [k for k in rows if rows[k]["z"] > 64],
              "calibration": [k for k in rows if rows[k]["z"] == 64]}
    report = {
        "panel_sha256": sha256(panel_path.read_bytes()).hexdigest(), "models": receipts,
        "weighting": "Each distinct visible row has weight one. Per-writer rows are deduplicated within writer. Hidden-truth expectations average uniformly over compatible lifts of each visible row. I is an invalid response, never an abstention.",
        "prompt_sha256": hashes,
        "scores": {}, "paired": {}, "observations": []
    }
    for panel_name, ids in strata.items():
        selected = set(ids)
        by_cutoff = defaultdict(list)
        for k in ids:
            by_cutoff[rows[k]["z"]].append(k)
        channels = {w: sorted(selected & group) for w, group in writers.items()}
        report["scores"][panel_name] = {
            name: {"all": metrics(ids, rows, outputs),
                   "by_writer": {w:metrics(group, rows, outputs) for w,group in sorted(channels.items())},
                   "by_cutoff": {str(z):metrics(group, rows, outputs) for z,group in sorted(by_cutoff.items())}}
            for name,outputs in {**predictions, **controls}.items()
        }
        report["paired"][panel_name] = [
            {"left": left, "right": right, **pair_comparison(ids, rows, predictions[left], predictions[right])}
            for left, right in combinations(models, 2)
        ]
    for k, row in rows.items():
        report["observations"].append({"row": k, "packet": packet_map[k], "z": row["z"], "e": row["e"],
                                       "tag": row["tag"], "residues": row["residues"],
                                       "writers": sorted(w for w, group in writers.items() if k in group),
                                       "yes": row["yes"], "no": row["no"], "action": row["action"],
                                       "responses": {name:predictions[name][k] for name in models}})
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, default=HERE)
    parser.add_argument("--model", action="append", default=[], metavar="SHORT=OLLAMA_TAG",
                        help="expect exactly the named model aliases; repeat for each reader")
    parser.add_argument("--output", type=Path, help="default: STUDY/results.json")
    args = parser.parse_args()
    expected = {}
    for spec in args.model:
        short, delim, tag = spec.partition("=")
        if not delim or not short or not tag or short in expected:
            parser.error("Each --model must be a unique SHORT=OLLAMA_TAG")
        expected[short] = tag
    report = score(args.study, expected)
    dest = args.output or args.study / "results.json"
    with NamedTemporaryFile(mode="w", dir=dest.parent, suffix=".tmp", delete=False) as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    Path(stream.name).replace(dest)
    for short in report["models"]:
        counts = report["scores"]["fresh"][short]["all"]
        print(short, f"guesses {counts['unsupported_guesses']}/{counts['ambiguous']}",
              f"settled correct {counts['settled_correct']}/{counts['settled']}",
              f"invalid {counts['total_invalid']}/{counts['n']}")


if __name__ == "__main__":
    main()
