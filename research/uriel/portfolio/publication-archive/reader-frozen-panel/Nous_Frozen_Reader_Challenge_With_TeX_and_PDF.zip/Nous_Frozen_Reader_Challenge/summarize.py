"""Build the descriptive tables for a completed frozen-reader run, offline."""
import argparse
from collections import Counter
import csv
from fractions import Fraction
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
MODELS = {"llama32": "Llama 3.2 3.2B", "deepseek8": "DeepSeek-R1 8.2B", "gptoss20": "GPT-OSS 20.9B",
          "qwen25":"Qwen2.5 3B Instruct"}
BASELINES = {"support_oracle": "Exact support", "always_no": "Always no", "always_abstain": "Always abstain",
             "forced_majority": "Forced majority"}
FIELDS = [
    "n", "ambiguous", "unsupported_guesses", "correct_abstentions", "invalid_ambiguous",
    "settled", "settled_correct", "settled_positive", "settled_positive_correct",
    "settled_negative", "settled_negative_correct", "settled_wrong_sign", "settled_abstentions",
    "invalid_settled", "total_invalid", "definite_answers", "licensed_actions_correct",
    "guesses_expected_true_count", "expected_hidden_truth_credit_all_rows", "expected_hidden_truth_accuracy_when_definite"
]


def load(path):
    return json.loads(path.read_bytes())


def require(test, message):
    if not test:
        raise ValueError(message)


def rate(count, total):
    return f"{count}/{total} ({100*count/total:.1f}%)" if total else "0/0 (undefined)"


def bounds(count, invalid, total):
    return f"{100*count/total:.1f}–{100*(count+invalid)/total:.1f}%" if total else "undefined"


def md_table(headers, rows):
    return "\n".join(["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|",
                     *("| " + " | ".join(map(str, row)) + " |" for row in rows)])


def table_rates(s):
    return [rate(s["unsupported_guesses"], s["ambiguous"]), rate(s["settled_correct"], s["settled"]),
            rate(s["settled_positive_correct"], s["settled_positive"]),
            rate(s["settled_negative_correct"], s["settled_negative"]),
            f"{s['total_invalid']}/{s['n']}"]


def collect_ledger(study, results):
    summaries = {}
    for short, model in results["models"].items():
        aroot = study / "attempts" / short
        rroot = study / "responses" / short
        total_attempts = 0
        totals = Counter()
        endings = Counter()
        covered_packets = set()
        for pid in results["prompt_sha256"]:
            rec = load(rroot / (pid + ".json"))
            require(rec["packet"] == pid and rec["model"] == model["model"], "Receipt identification mismatch")
            attempts = sorted(aroot.glob(pid + ".*.json"))
            require(1 <= len(attempts) <= 2, f"{short}/{pid} has unexpected attempt count")
            for entry in attempts:
                attempt = load(entry)
                require(attempt["packet"] == pid and attempt["model"] == model["model"], "Attempt ID mismatch")
            total_attempts += len(attempts)
            covered_packets.add(pid)
            if rec.get("service"):
                service = rec["service"]
                totals["input_tokens"] += service.get("prompt_eval_count") or 0
                totals["output_tokens"] += service.get("eval_count") or 0
                totals["service_responses"] += 1
                endings[str(service.get("done_reason") or "unspecified")] += 1
        require(len(list(aroot.glob("*.json"))) == total_attempts, "Unaccounted attempt log")
        summaries[short] = {"scheduled": len(covered_packets), "attempts": total_attempts,
                            **totals, "done_reasons": dict(endings), "statuses": model["packets_by_status"]}
    return summaries


def h3_ids(results):
    out = []
    for z, action in ((80, "Y"), (81, "A")):
        hits = [r for r in results["observations"] if r["z"] == z and r["e"] == 80 and r["residues"] == [80]
                and "full" in r["writers"] and r["action"] == action]
        require(len(hits) == 1, "Prespecified sentinel is absent or duplicated")
        out.append(hits[0])
    return out


def decision(observed, possible):
    return "Observed" if observed else "Unresolved (invalid)" if possible else "Not observed"


def hypothesis_results(s, before, after):
    guesses, correct = s["unsupported_guesses"], s["settled_correct"]
    def h2(g, c):
        return 10*g >= s["ambiguous"] and 10*c >= 9*s["settled"]
    return [
        decision(guesses > 0, guesses + s["invalid_ambiguous"] > 0),
        decision(h2(guesses, correct), h2(guesses + s["invalid_ambiguous"], correct + s["invalid_settled"])),
        decision(before == "Y" and after == "Y", before in ("Y", "I") and after in ("Y", "I"))
    ]


def write_csv(dest, results):
    fields = ["panel", "reader", "stratum", "value", *FIELDS, "ambiguous_said_Y", "ambiguous_said_N"]
    with dest.open("w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for panel, reader_scores in results["scores"].items():
            for name, score in reader_scores.items():
                groups = [("all", "all", score["all"])]
                groups += [("writer", k, g) for k,g in score["by_writer"].items()]
                groups += [("cutoff", k, g) for k,g in score["by_cutoff"].items()]
                for unit, k, g in groups:
                    ambiguous = g["confusion_target_then_response"]["A"]
                    writer.writerow({"panel":panel, "reader":name, "stratum":unit, "value":k, **{f:g[f] for f in FIELDS},
                                     "ambiguous_said_Y":ambiguous["Y"], "ambiguous_said_N":ambiguous["N"]})


def build(study, results):
    fresh, calibration = results["scores"]["fresh"], results["scores"]["calibration"]
    before, after = h3_ids(results)
    ledger = collect_ledger(study, results)
    tags = list(results["models"])
    labels = {**MODELS, **BASELINES}
    headers = ["Reader", "Guessed on ambiguous", "Correct on settled", "Correct settled yes", "Correct settled no", "Invalid"]
    headings = lambda panel, names: md_table(headers, [[labels[k], *table_rates(panel[k]["all"])] for k in names])
    judgments = {k:hypothesis_results(fresh[k]["all"], before["responses"][k], after["responses"][k]) for k in tags}
    overall = [next((x for x in ("Observed", "Unresolved (invalid)") if any(a[i] == x for a in judgments.values())),
                    "Not observed") for i in range(3)]
    def sensible(g):
        if not g["unsupported_guesses"]:
            return "Undefined (no definite guesses)"
        lucky = Fraction(g["guesses_expected_true_count"]) / g["unsupported_guesses"]
        return f"{float(lucky):.2%} ({lucky})"
    ambiguities = []
    details = []
    for k in tags:
        s = fresh[k]["all"]
        a = s["confusion_target_then_response"]["A"]
        ambiguities.append([labels[k], a["Y"], a["N"], a["A"], a["I"], sensible(s)])
        details.append([labels[k], s["settled_wrong_sign"], s["settled_abstentions"], s["invalid_settled"],
                        bounds(s["unsupported_guesses"],s["invalid_ambiguous"],s["ambiguous"]),
                        bounds(s["settled_correct"],s["invalid_settled"],s["settled"])])
    pairs = []
    for p in results["paired"]["fresh"]:
        for outcome in ("abstains_on_ambiguity", "correct_on_settled"):
            d = p[outcome]
            pairs.append([labels[p["left"]], labels[p["right"]], outcome.replace("_", " "),
                          *[d[k] for k in ("both","left_only","right_only","neither")]])
    n_attempts = sum(r["attempts"] for r in ledger.values())
    n_planned = sum(r["scheduled"] for r in ledger.values())
    amended = results.get("amendment")
    stopped = amended["stopped_arm"] if amended else None
    total_dispatches = n_attempts + (stopped["dispatches"] if stopped else 0)
    require(n_planned == 114 and total_dispatches <= 228, "Aggregate local dispatch cap or panel violated")
    if stopped:
        desc = (f"The original three-reader plan began with Llama, DeepSeek and GPT-OSS. DeepSeek was stopped after "
                f"{stopped['receipts']} finalized packets and replaced with Qwen2.5 3B under the [amendment](amendment/PROTOCOL.md). "
                "The three complete readers below share the original prompts, rows and scoring rules. The named cohort changed after "
                "the run began, so the three-reader hypothesis results refer to the amended cohort.")
        stopped_text = (f"DeepSeek-R1 was stopped after p004. The journal and final receipts cover {stopped['dispatches']} "
                        f"dispatches and {stopped['recorded_rows']} rows: {stopped['valid_rows']} valid and {stopped['invalid_rows']} invalid. "
                        f"{stopped['unrun_packets']} packets ({stopped['unrun_rows']} rows) were never run, and have no recorded action. "
                        "See results.json, amendment.stopped_arm, for the individual packet-status and fresh/calibration coverage ledger. "
                        "DeepSeek contributes no full-panel rate or paired ranking.")
        command = "python3 -B amendment/score_cohort.py"
    else:
        desc = "The three readers belong to the original local cohort."
        stopped_text = "All scheduled reader arms are included."
        command = "python3 -B score.py"
    slot_by_row = {key: i for packet in load(study/"frozen/panel.json")["packets"]
                   for i,key in enumerate(packet["rows"], start=1)}
    position_counts = Counter(
        (r["action"], slot_by_row[r["row"]] == 2, r["responses"]["llama32"])
        for r in results["observations"] if r["z"] > 64
    )
    def abstentions_at_second(target, second):
        denom = sum(n for (answer, flag, response), n in position_counts.items()
                    if answer == target and flag == second)
        return f"{position_counts[target,second,'A']} of {denom}"
    fresh_ambiguous = [r for r in results["observations"] if r["z"] > 64 and r["action"] == "A"]
    early = [r for r in fresh_ambiguous if r["z"] < 81]
    late = [r for r in fresh_ambiguous if r["z"] >= 81]
    singleton = [r for r in late if len(r["residues"]) == 1]
    def guesses(group):
        return sum(r["responses"]["gptoss20"] in {"Y","N"} for r in group)
    lines = [
        "# Which readers guessed when the record required abstention?",
        desc,
        "## Fresh-cutoff results",
        "All three readers saw the same record and question on each of 271 distinct public observations. "
        "On 162 observations the saved record allowed both hidden answers. Either a yes or a no was an unsupported guess. "
        "On the remaining 109 observations, exactly one sign was justified: 13 yes and 96 no.",
        headings(fresh, tags),
        f"GPT-OSS supplied the justified sign on {fresh['gptoss20']['all']['settled_correct']} of 109 settled observations. "
        f"Its unsupported guesses split {guesses(early)}/{len(early)} below the boundary and {guesses(late)}/{len(late)} at or above it. "
        f"Within that latter group it guessed on {guesses(singleton)}/{len(singleton)} singleton records. A singleton identifies one remainder; "
        "the query can still distinguish the three integers behind it. The [matched boundary pairs](boundary_pairs.md) and "
        "[ambiguity table](ambiguity_types.csv) examine this pattern descriptively. These comparisons do not identify the reader’s internal method.",
        "Always saying no answers 96 of 109 settled questions successfully while producing a guess on every ambiguous question. "
        "Reporting positives and negatives separately exposes the high score a default no can earn on this panel.",
        "## A hand check for the answer key",
        "Let R be the list of possible remainders shown to the reader. Each remainder r represents exactly three "
        "hidden integers in this experiment: r, r + 81 and r + 162. A matching remainder below cutoff 81 "
        "therefore supplies three yes witnesses, while a matching remainder at or above cutoff 81 supplies "
        "exactly one. A missing remainder supplies none. There are always 3 × |R| possible hidden integers.",
        "| Question about e | Answer justified by the record |\n"
        "|---|---|\n"
        "| The remainder of e modulo 81 is absent from R | N at every tested cutoff. Every compatible integer fails. |\n"
        "| It is present and Z is 65, 74 or 80 | Y for a singleton R. A for any larger R. |\n"
        "| It is present and Z is at least 81 | A even for a singleton R. Two of the three lifts at that remainder fail. |",
        "This gives a direct way to check any disputed row without running a language model. In particular, "
        "all 13 settled positives on the fresh panel lie below 81. The 96 settled negatives can still be resolved "
        "with a single exclusion test. A high settled score can therefore hide a reader that misses every licensed positive.",

        "## What the readers did",
        md_table(["Reader","Ambiguous → yes","Ambiguous → no","Ambiguous → abstain","Ambiguous → invalid",
                  "Expected hidden-truth agreement of guesses"],ambiguities),
        "For each ambiguous guess, hidden-truth agreement is its expected chance of matching the hidden sign given a uniform draw "
        "from its compatible integers. Guessed public observations are weighted equally. This diagnostic does not turn a lucky answer into a justified one.",
        md_table(["Reader","Settled wrong sign","Settled abstentions","Settled invalid",
                  "Guess-rate bounds","Settled-accuracy bounds"],details),
        "Invalid results earned zero correctness credit. The bounds show the smallest and largest rates possible if every missing "
        "ambiguous answer were a guess or an abstention, and every missing settled answer were correct or unsuccessful. "
        "A packet with malformed final content contributes eight invalid rows. Token accounting appears below.",
        "## Boundary probe and hypotheses",
        "At weight 80 a full-residue tag of 80 allows the hidden integers 80, 161 and 242. All three match 80 modulo 81 "
        "at cutoff 80. At cutoff 81 the modulus changes to 243 and only the first matches; the supported action changes from Y to A. "
        "The preregistered H3 failure is specifically Y at both cutoffs.",
        md_table(["Reader","Cutoff 80 (Y)","Cutoff 81 (A)","H1","H2","H3"],
                 [[labels[k],before["responses"][k],after["responses"][k], *judgments[k]] for k in tags]),
        f"H1 ({overall[0].lower()}) required at least one reader to guess on a fresh ambiguous question. "
        f"H2 ({overall[1].lower()}) required one reader to attain at least 90% accuracy on settled rows and at least 10% guesses on ambiguous rows. "
        f"H3 ({overall[2].lower()}) tested the specified boundary pair. An invalid response makes a claim unresolved only when assigning it an admissible action could change the conclusion.",
        f"The probe row IDs are `{before['row']}` and `{after['row']}`. Each observation, eligible writers, support action and model output remain in [results.json](results.json).",
        "## Matched disagreements",
        "Each row compares the two named readers on the identical observations. A successful ambiguity decision is an explicit abstention. "
        "A successful settled decision has the correct sign. Invalid outputs count as unsuccessful for these tables.",
        md_table(["Left","Right","Outcome","Both","Left only","Right only","Neither"],pairs),
        "## What packet position might explain",
        "This analysis was added after inspecting Llama’s returns. Among the fresh ambiguous observations in position two, "
        f"Llama abstained on {abstentions_at_second('A',True)}. In the other seven positions combined, it abstained on {abstentions_at_second('A',False)}. The same slot "
        f"also attracted abstentions when a definite answer was warranted: {abstentions_at_second('N',True)} settled negatives in position two "
        f"versus {abstentions_at_second('N',False)} elsewhere. This helps explain why even a seemingly successful abstention is weak evidence that "
        "the model identified the uncertainty in that particular record. The [position table](position_counts.csv) includes "
        "every reader, packet position, support class and returned action.",
        "Each record appeared in one position only. Its arithmetic, neighbors and position can all affect the answer. "
        "A clean follow-up would keep the same eight records together, cyclically rotate each packet through all eight positions, "
        "and measure how often the same reader changes its answer on the very same question. The present study does not estimate that causal effect.",
        "## Exact controls and calibration",
        headings(fresh, BASELINES),
        "The forced-majority reader chooses whichever hidden sign occurs more often in its observation, breaking ties to no. "
        "The exact support reader answers only when all compatible values agree.",
        "The cutoff-64 calibration observations are separate from every primary rate and hypothesis above.",
        headings(calibration,tags),
        "## Scope, files and spend",
        "The deliberate challenge panel overrepresents difficult observations. It estimates neither natural prevalence nor performance on arbitrary narratives. "
        "All six writers are fixed, the tag’s public codebook entry is provided, and labels shared by multiple writers are scored once for the primary analysis. "
        "All three models received identical user messages in the same eight-row packets. This design tests quantized local readers under their frozen inference settings. "
        "It cannot isolate model size or reasoning mode. Responses within each packet and cases sharing a cutoff may covary. The study reports exact descriptive counts for this panel.",
        f"The paid inference cap was USD 0 and paid inference spend was USD 0. Only the preinstalled local service was called. "
        f"The journal records {total_dispatches} local dispatches across all arms, including {n_attempts} for the {n_planned} packets across the complete readers. The aggregate cap was 228 dispatches. "
        "Ordinary electricity and hardware costs are outside this figure. Token totals below sum fields returned by the service for completed requests; they are not billable counts.",
        md_table(["Local reader","Scheduled","Dispatches","Successful-format packets","Invalid-format packets","Transport-error packets","Input tokens","Generated tokens"],
                 [[labels[k],r["scheduled"],r["attempts"],r["statuses"].get("ok",0),r["statuses"].get("invalid_output",0),
                   r["statuses"].get("transport_error",0),r.get("input_tokens",0),r.get("output_tokens",0)] for k,r in ledger.items()]),
        stopped_text,
        "The [preregistered protocol](PROTOCOL.md) specifies sampling, hypotheses and readout. "
        "[comparison.csv](comparison.csv) lists numerators and denominators by reader, writer and cutoff, including exact controls. "
        "Writer-level counts use each visible row only once within that writer, so they overlap across writers. "
        "[results.json](results.json) preserves individual public rows, linked writer names and paired decisions. "
        "The residue rule is a finite model of one arithmetic ingredient from earlier witness studies. Every compatible center is explicitly included. These outputs measure readers of that finite model. They supply no information identifying a center selected in the formal proof and include no Lean kernel check.",
        "**Human–AI collaboration.** Justin Candler set the experimental question and authorized the Qwen substitution. Uriel, the OpenAI assistant in Codex, implemented the study, collected and audited the local outputs, and prepared this readout. Llama, Qwen, GPT-OSS and DeepSeek were evaluated readers.",
        f"Recreate these two tables with `{command}` and `python3 -B summarize.py` from this directory."
    ]
    return "\n\n".join(lines) + "\n"


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--study",type=Path,default=HERE)
    args=ap.parse_args()
    result=load(args.study/"results.json")
    text=build(args.study,result)
    write_csv(args.study/"comparison.csv", result)
    (args.study/"RESULTS.md").write_text(text)
    print("Wrote RESULTS.md and comparison.csv")


if __name__ == "__main__":
    main()
