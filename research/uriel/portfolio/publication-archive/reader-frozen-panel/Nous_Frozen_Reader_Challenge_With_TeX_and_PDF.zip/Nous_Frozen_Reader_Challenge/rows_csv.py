"""Expose every public observation and compare two sources of ambiguity descriptively."""
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def run():
    src=json.loads((ROOT/'results.json').read_bytes())
    labels=list(src['models'])
    counts=defaultdict(lambda:dict(n=0,guesses=0,abstentions=0,invalid=0))
    with (ROOT/'case_decisions.csv').open('w',newline='') as f:
        out=csv.writer(f)
        out.writerow(['public_row','packet','cutoff','weight','tag','compatible_low_residues','writers',
                      'compatible_hidden_yes','compatible_hidden_no','licensed_action','reason',*labels])
        for row in src['observations']:
            z=row['z']
            if row['action']!='A': reason='all lifts agree'
            elif z<81: reason='different stored residues yield different truths'
            elif len(row['residues'])==1: reason='a single stored residue has three possible lifts'
            else: reason='multiple stored residues and an unrecorded higher digit'
            out.writerow([row['row'],row['packet'],z,row['e'],row['tag'],' '.join(map(str,row['residues'])),
                          ' '.join(row['writers']),row['yes'],row['no'],row['action'],reason,*[row['responses'][m] for m in labels]])
            if z<=64 or row['action']!='A': continue
            for m in labels:
                d=counts[m,reason];d['n']+=1
                a=row['responses'][m]
                if a in ('N','Y'):d['guesses']+=1
                elif a=='A':d['abstentions']+=1
                else:d['invalid']+=1
    with (ROOT/'ambiguity_types.csv').open('w',newline='') as f:
        out=csv.writer(f);out.writerow(['model','descriptive_ambiguity_type','n','guesses','abstentions','invalid'])
        for (m,reason),d in sorted(counts.items()):
            out.writerow([m,reason,d['n'],d['guesses'],d['abstentions'],d['invalid']])
    write_position_counts(ROOT, src)


def write_position_counts(study, report):
    """Tabulate fresh visible decisions by their original within-packet position."""
    panel = json.loads((study / "frozen/panel.json").read_bytes())
    fresh = {row["id"]: row for row in panel["rows"] if row["z"] > 64}
    positions = {rid: (packet["id"], pos) for packet in panel["packets"]
                 for pos, rid in enumerate(packet["rows"], 1)}
    width = max(len(packet["rows"]) for packet in panel["packets"])
    targets = ("A", "Y", "N")
    outputs = ("Y", "N", "A", "I")
    counts = defaultdict(Counter)
    cohort = tuple(report["models"])
    seen = set()
    for row in report["observations"]:
        if row["z"] <= 64:
            continue
        rid = row["row"]
        frozen = fresh[rid]
        packet, pos = positions[rid]
        if (rid in seen or row["packet"] != packet or row["z"] != frozen["z"]
                or row["action"] != frozen["action"] or set(row["responses"]) != set(cohort)):
            raise ValueError("Fresh position observation mismatch: " + rid)
        seen.add(rid)
        for alias, action in row["responses"].items():
            if action not in outputs:
                raise ValueError("Unknown returned action for " + rid)
            counts[alias, pos, frozen["action"]][action] += 1
    if seen != set(fresh):
        raise ValueError("Position census does not cover the frozen fresh panel")

    for alias in cohort:
        score = report["scores"]["fresh"][alias]["all"]
        confusion = score["confusion_target_then_response"]
        total = 0
        for target in targets:
            for action in outputs:
                n = sum(counts[alias, pos, target][action] for pos in range(1, width + 1))
                if n != confusion[target][action]:
                    raise ValueError(f"Position counts disagree with score: {alias} {target} {action}")
                total += n
        if total != score["n"] or total != len(fresh):
            raise ValueError("Fresh denominator mismatch for " + alias)

    with (study / "position_counts.csv").open("w", newline="") as handle:
        table = csv.writer(handle)
        table.writerow(["model", "packet_position", "licensed_action", "fresh_public_rows",
                        *("returned_" + a for a in outputs)])
        for alias in cohort:
            for pos in range(1, width + 1):
                for target in targets:
                    cell = counts[alias, pos, target]
                    table.writerow([alias, pos, target, sum(cell.values()), *(cell[a] for a in outputs)])


if __name__=='__main__':run()
