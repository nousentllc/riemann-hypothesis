"""Verify a frozen reader panel by independently evaluating each compatible lift.

Uses the 3-adic valuation of the integer difference, without importing the panel
generator or its labels. The historical checks use the original 81-state law.
"""

import argparse
from collections import Counter, defaultdict
from functools import lru_cache
import json
from pathlib import Path


WRITERS = ("raw27", "opt27", "terminal", "split1", "split8", "full")
CUTOFFS = (64, 65, 74, 80, 81, 90, 101, 121, 162)
HISTORICAL = (*range(24, 30), *range(59, 65))


def require(condition, message):
    if not condition:
        raise ValueError(message)


@lru_cache(maxsize=None)
def codebook(writer):
    singleton = tuple((r,) for r in range(1, 65))
    empty = (0, *range(65, 81))
    if writer == "raw27":
        cells = tuple((r, r + 27, r + 54) for r in range(27))
    elif writer == "opt27":
        cells = ((empty,) + singleton[:11]
                 + tuple(tuple(range(i, i + 3)) for i in range(12, 33, 3))
                 + tuple(tuple(range(i, i + 4)) for i in range(33, 65, 4)))
    elif writer == "terminal":
        cells = (empty,) + singleton
    elif writer in ("split1", "split8"):
        width = {"split1": 1, "split8": 8}[writer]
        assigned = empty[1:1 + width]
        rest = tuple(r for r in empty if r not in assigned)
        cells = (rest,) + singleton + (assigned,)
    elif writer == "full":
        cells = tuple((r,) for r in range(81))
    else:
        raise ValueError(f"Unknown writer {writer!r}")
    require(sorted(r for group in cells for r in group) == list(range(81)),
            f"Incomplete or repeated residues in writer {writer!r}")
    return cells


def is_positive(center, cutoff, weight):
    difference = abs(center - weight)
    if difference == 0:
        return True
    valuation_power = 1
    while difference % 3 == 0:
        difference //= 3
        valuation_power *= 3
    return valuation_power > cutoff


def count_support(centers, cutoff, weight):
    yes = sum(is_positive(s, cutoff, weight) for s in centers)
    no = len(centers) - yes
    action = "N" if yes == 0 else "Y" if no == 0 else "A"
    return yes, no, action


def historical_controls():
    controls = {}
    for writer in WRITERS:
        heldout = Counter()
        terminal = Counter()
        for z in HISTORICAL:
            for e in range(1, z + 1):
                for group in codebook(writer):
                    yes, no, action = count_support(group, z, e)
                    heldout["state_queries"] += len(group)
                    heldout["best_forced_errors"] += min(yes, no)
                    if action == "A":
                        heldout["required_abstentions"] += len(group)
                    if z == 64:
                        terminal[action] += len(group)
        controls[writer] = {"cutoff64": dict(terminal), "old_holdout": dict(heldout)}
        require(heldout["state_queries"] == 42768, f"Old count mismatch {writer}")
    expected = {"raw27": {"N": 4992, "A": 192},
                "opt27": {"N": 4982, "Y": 11, "A": 191}}
    for writer, old in expected.items():
        require(controls[writer]["cutoff64"] == old,
                f"Original 27-tag census changed for {writer}")
    for writer, costs in {"terminal": (45, 765), "split1": (42, 672),
                          "split8": (45, 381), "full": (0, 0)}.items():
        obs = controls[writer]["old_holdout"]
        require((obs.get("best_forced_errors", 0), obs.get("required_abstentions", 0)) == costs,
                f"Original refinement control changed for {writer}")
    return controls


def verify_panel(panel):
    rows = {row["id"]: row for row in panel["rows"]}
    require(len(rows) == len(panel["rows"]), "Duplicate row identifier")
    seen = set()
    checked_cutoffs = set()
    for row in rows.values():
        z, e = row["z"], row["e"]
        checked_cutoffs.add(z)
        require(z in CUTOFFS and 1 <= e <= z, f"Invalid cutoff or weight, {row!r}")
        residues = row["residues"]
        require(residues and len(set(residues)) == len(residues)
                and all(isinstance(r, int) and 0 <= r < 81 for r in residues),
                f"Invalid residue fiber, {row!r}")
        centers = [r + offset for offset in (0, 81, 162) for r in residues]
        independently = count_support(centers, z, e)
        require(independently == (row["yes"], row["no"], row["action"]),
                f"Lift multiplicity or licensed action disagrees, {row!r}")
        if z >= 81:
            require(row["action"] != "Y", f"Impossible positive above 80, {row!r}")
    require(checked_cutoffs == set(CUTOFFS), f"Incomplete cutoff coverage: {checked_cutoffs}")
    cases = defaultdict(dict)
    linked = set()
    for link in panel["links"]:
        case, writer = link["case"], link["writer"]
        key = case, writer
        require(key not in seen, f"Duplicate case/writer {key!r}")
        seen.add(key)
        row = rows[link["row"]]
        linked.add(row["id"])
        r = link["r"]
        require(link["z"] == row["z"] and link["e"] == row["e"],
                f"Query changed when linked, {link!r}")
        tag = next((i for i, group in enumerate(codebook(writer)) if r in group), None)
        require(tag is not None and row["tag"] == tag and
                sorted(row["residues"]) == list(codebook(writer)[tag]),
                f"Record, tag or compatible residues disagree for {link!r}")
        cases[case][writer] = (link["z"], r, link["e"])
    for case, views in cases.items():
        require(set(views) == set(WRITERS) and len(set(views.values())) == 1,
                f"Matched writer comparison broken on case {case!r}")
    require(linked == set(rows), "Rows missing a latent case")
    covered = [r for p in panel["packets"] for r in p["rows"]]
    require(Counter(covered) == Counter(list(rows)), "Packet coverage differs from rows")
    return {"distinct_rows": len(rows), "cases": len(cases), "links": len(seen),
            "packets": len(panel["packets"]), "cutoffs": sorted(checked_cutoffs),
            "rows_by_action": dict(Counter(r["action"] for r in rows.values()))}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--panel", type=Path,
                   default=Path(__file__).resolve().parent / "frozen/panel.json")
    p.add_argument("--historical-only", action="store_true")
    args = p.parse_args()
    results = {"historical_controls": historical_controls()}
    if not args.historical_only:
        results["frozen_panel"] = verify_panel(json.loads(args.panel.read_text()))
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
