"""Run prospectively frozen replacement cohort through the original local interface."""
import argparse
import fcntl
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import run_readers as original


def read(path):
    return json.loads((ROOT / path).read_bytes())


def verify_model(model):
    tags = {item["name"]: item for item in original.query("/api/tags")["models"]}
    if tags[model["tag"]]["digest"] != model["digest"]:
        raise ValueError("Serving model changed: " + model["tag"])


def run():
    original.receipts()
    for name, digest in read("amendment/FROZEN.json").items():
        if sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise ValueError("Amendment file changed: " + name)
    registry = read("amendment/models.json")
    before = read("frozen/models.json")
    if any(registry[name] != before[name] for name in ("llama32", "gptoss20")):
        raise ValueError("Retained configuration changed")
    if original.query("/api/version")["version"] != "0.40.4":
        raise ValueError("Local server version changed")
    packets = read("frozen/panel.json")["packets"]
    with (ROOT / ".run.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for name in ("qwen25", "gptoss20"):
            model = registry[name]
            verify_model(model)
            for idx, packet in enumerate(packets, 1):
                total = sum(1 for _ in (ROOT / "attempts").glob("*/*.json"))
                slot = ROOT / "responses" / name / (packet["id"] + ".json")
                used = len(list((ROOT / "attempts" / name).glob(packet["id"] + ".*.json")))
                if not slot.exists() and total + max(0, 2-used) > 228:
                    raise RuntimeError("Global dispatch ceiling reached")
                status = original.generate(name, model, packet, idx == len(packets))
                print(original.now(), name, packet["id"], status, flush=True)
            verify_model(model)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--rundir", action="store_true", required=True)
    ap.parse_args()
    run()
