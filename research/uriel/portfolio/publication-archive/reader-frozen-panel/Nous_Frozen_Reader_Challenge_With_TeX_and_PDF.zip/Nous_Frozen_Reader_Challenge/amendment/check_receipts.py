"""Audit the prospectively amended complete cohort and the stopped reader's observed prefix.

Use --git-timing-output before distributing the ZIP to include the local time
evidence. The packed commits are sufficient to verify hashes and timestamps
without an installed Git repository. The times come from this workstation.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha1
import importlib.util
import json
from pathlib import Path
import subprocess


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("original_receipt_audit", HERE.parent / "verification/check_receipts.py")
original = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(original)
need = original.need
read = original.read
digest = original.digest
EFFECTIVE = {"llama32", "qwen25", "gptoss20"}
STOPPED = "deepseek8"
STOP_AFTER = 4


def git_hash(kind, data):
    return sha1(kind.encode() + b" " + str(len(data)).encode() + b"\x00" + data).hexdigest()


def freeze_files(study):
    path = study / "amendment/FROZEN.json"
    pins = read(path)
    for name, expected in pins.items():
        target = study / name
        need(target.is_file() and digest(target.read_bytes()) == expected,
             "Amendment freeze mismatch: " + name)
    return path, pins


def make_witness(study, paths):
    """Collect the minimal hashed Git object chain for each attested path."""
    def git(*args):
        return subprocess.check_output(["git", "-C", str(study), *args])

    commits = git("log", "--reverse", "--format=%H", "--diff-filter=A", "--", "amendment/FROZEN.json").decode().splitlines()
    need(len(commits) == 1, "Ambiguous history for the amendment registration")
    revision = commits[0]
    need(subprocess.run(["git", "-C", str(study), "merge-base", "--is-ancestor",
                         original.PREFLIGHT, revision]).returncode == 0, "Amendment lacks original freeze ancestor")
    history = git("rev-list", "--first-parent", revision, "^" + original.FREEZE).decode().splitlines()
    need(original.PREFLIGHT in history, "Amendment first-parent chain omits the original scorer")
    bodies = {rev: git("cat-file", "commit", rev).hex() for rev in (original.FREEZE, *history)}
    trees = {}
    to_check = [(revision, name) for name in paths]
    to_check.extend([(original.FREEZE, "FROZEN.json"), (original.PREFLIGHT, "score.py")])
    for rev, path in to_check:
        tree = git("rev-parse", rev + "^{tree}").decode().strip()
        for directory in [None, *Path(path).parts[:-1]]:
            if directory is not None:
                tree = git("rev-parse", tree + ":" + directory).decode().strip()
            if tree not in trees:
                trees[tree] = git("cat-file", "tree", tree).hex()
    return {"revision": revision, "commits_hex": bodies, "trees_hex": trees}


def git_timestamp(record):
    lines = record.split(b"\n\n", 1)[0].decode().splitlines()
    timestr = next(t for t in lines if t.startswith("committer ")).rsplit(" ", 2)[1]
    return datetime.fromtimestamp(int(timestr), timezone.utc)


def entries(raw):
    out = {}
    position = 0
    while position < len(raw):
        stop = raw.index(b"\x00", position)
        mode, name = raw[position:stop].decode().split(" ", 1)
        digest_bytes = raw[stop + 1:stop + 21]
        need(len(digest_bytes) == 20 and name not in out, "Malformed Git tree entry")
        out[name] = mode, digest_bytes.hex()
        position = stop + 21
    return out


def verify_witness(study, witness, paths):
    bodies = {key: bytes.fromhex(value) for key, value in witness["commits_hex"].items()}
    trees = {key: bytes.fromhex(value) for key, value in witness["trees_hex"].items()}
    for kind, objects in (("commit", bodies), ("tree", trees)):
        for key, raw in objects.items():
            need(git_hash(kind, raw) == key, "Invalid " + kind + " object " + key)
    rev = witness["revision"]
    chain = []
    cursor = rev
    while cursor != original.FREEZE:
        need(cursor not in chain, "Cyclic Git history")
        chain.append(cursor)
        cursor = next(k[7:] for k in bodies[cursor].decode().splitlines() if k.startswith("parent "))
    need(original.PREFLIGHT in chain, "Original preflight commit absent from chain")
    check_paths = [(rev, name) for name in paths]
    check_paths.extend([(original.FREEZE, "FROZEN.json"), (original.PREFLIGHT, "score.py")])
    for revision, name in check_paths:
        target = bodies[revision].split(b"\n", 1)[0].decode().split()[1]
        for part in Path(name).parts:
            mode, target = entries(trees[target])[part]
        need(mode == "100644" or mode == "100755", "Expected regular Git file")
        need(target == git_hash("blob", (study / name).read_bytes()), "Git file mismatch: " + name)
    return {key:git_timestamp(bodies[key]) for key in (original.FREEZE, original.PREFLIGHT, rev)}


def model_rows(study, alias, config, packets):
    answers = {}
    status_counts = Counter()
    dates = []
    ended = []
    expected_logs = set()
    for packet in packets[:STOP_AFTER] if alias == STOPPED else packets:
        pid = packet["id"]
        rec = read(study / "responses" / alias / (pid + ".json"))
        expected = original.request_sha(config, packet, pid == packets[-1]["id"])
        need((rec["packet"], rec["model"], rec["digest"], rec["rows"]) ==
             (pid, config["tag"], config["digest"], packet["rows"]),
             "Wrong model or record on " + alias + "/" + pid)
        need(rec["request_sha256"] == expected, "Options or prompt hash differs in " + alias + "/" + pid)
        need(rec["prompt_sha256"] == packet["prompt_sha256"] == digest(packet["prompt"].encode()),
             "Frozen prompt hash differs")
        actions, status = original.parse_final(rec, len(packet["rows"]))
        need(rec["actions"] == actions and rec["status"] == status, "Raw content reparse mismatch")
        timeline = original.attempts_for(study, alias, config, packet, expected, rec, status)
        for idx in range(len(timeline)):
            expected_logs.add(pid + "." + str(idx + 1) + ".json")
        dates.extend(timeline)
        if "ended" in rec:
            ended.append(original.instant(rec["ended"]))
        status_counts[status] += 1
        for rid, action in zip(packet["rows"], actions):
            need(rid not in answers, "Duplicate answered row")
            answers[rid] = action
    need({p.name for p in (study / "attempts" / alias).glob("*.json")} == expected_logs,
         "Extra or missing attempt journals: " + alias)
    packet_names = {p["id"] + ".json" for p in (packets[:STOP_AFTER] if alias == STOPPED else packets)}
    need({p.name for p in (study / "responses" / alias).glob("*.json")} == packet_names,
         "Response count does not match the authorized packet list: " + alias)
    return answers, status_counts, dates, ended


def summarize(answers, rows, boundary):
    fresh = [rid for rid in answers if rows[rid]["z"] > 64]
    matrix = {a:{j:0 for j in ("Y", "N", "A", "I")} for a in ("Y", "N", "A")}
    for rid in fresh:
        row = rows[rid]
        action = original.independent_label(row)
        need(action == row["action"], "Oracle disagreement " + rid)
        matrix[action][answers[rid]] += 1
    n_a = sum(matrix["A"].values())
    n_s = len(fresh) - n_a
    guess = matrix["A"]["Y"] + matrix["A"]["N"]
    correct = matrix["N"]["N"] + matrix["Y"]["Y"]
    return {
        "confusion_target_then_response": matrix, "n": len(fresh),
        "ambiguous": n_a, "unsupported_guesses": guess, "settled": n_s, "settled_correct": correct,
        "settled_positive": sum(matrix["Y"].values()), "settled_positive_correct": matrix["Y"]["Y"],
        "settled_negative": sum(matrix["N"].values()), "settled_negative_correct": matrix["N"]["N"],
        "total_invalid": sum(matrix[a]["I"] for a in matrix),
        "h1_any_definitive_guess": bool(guess),
        "h2_at_least_90pct_settled_and_10pct_guess": bool(n_s and n_a and 10*correct >= 9*n_s and 10*guess >= n_a),
        "h3_z80_then_z81": [answers.get(boundary[z]) for z in (80,81)],
    }


def audit(study, git_timing_output=None):
    original.check_manifest(study)
    path, amend_pins = freeze_files(study)
    attested_paths = [str(path.relative_to(study)), *amend_pins]
    original_models = read(study / "frozen/models.json")
    effective = read(study / "amendment/models.json")
    required = {"amendment/models.json", "amendment/PROTOCOL.md", "amendment/run.py",
                "amendment/stop_authorization.json", "amendment/qwen_identity.json"}
    need(required <= set(amend_pins), "Required amendment evidence missing from registration")
    need(set(effective) == EFFECTIVE and original_models["llama32"] == effective["llama32"]
         and original_models["gptoss20"] == effective["gptoss20"], "Wrong complete model cohort")
    panel = read(study / "frozen/panel.json")
    packets = panel["packets"]
    rows = {r["id"]:r for r in panel["rows"]}
    reported = read(study / "results.json")
    need(set(reported["models"]) == EFFECTIVE and reported["panel_sha256"] == digest((study / "frozen/panel.json").read_bytes()),
         "Completed results include the wrong reader or panel")
    need(reported["prompt_sha256"] == {p["id"]:p["prompt_sha256"] for p in packets}, "Reported prompt identities differ")
    observations = {v["row"]:v for v in reported["observations"]}
    need(set(observations) == set(rows) and len(rows) == len(reported["observations"]),
         "Results row multiplicities differ")
    boundary = {r["z"]:r["id"] for r in rows.values() if r["z"] in (80,81) and r["tag"] == 80
                and r["e"] == 80 and r["residues"] == [80]}
    need(set(boundary) == {80,81}, "Missing registered boundary probe")
    measured = {}
    starts = {}
    ends = {}
    for alias, model in {**effective, STOPPED: original_models[STOPPED]}.items():
        actions, statuses, dates, ended = model_rows(study, alias, model, packets)
        starts[alias] = min(dates)
        ends[alias] = max(ended) if ended else max(dates)
        calc = summarize(actions, rows, boundary)
        matched_rows = sum(statuses.values())
        measured[alias] = {"packets": matched_rows, "attempts": len(dates), "rows": len(actions),
                           "by_packet_status": dict(statuses), "fresh": calc}
        if alias == STOPPED:
            stopped_report = reported["amendment"]["stopped_arm"]
            outcome_counts = Counter("invalid_rows" if a == "I" else "valid_rows" for a in actions.values())
            totals = {"receipts":matched_rows, "dispatches":len(dates), "recorded_rows":len(actions),
                      "unrun_rows":len(rows)-len(actions), "unrun_packets":len(packets)-matched_rows,
                      "valid_rows":outcome_counts["valid_rows"], "invalid_rows":outcome_counts["invalid_rows"]}
            need(all(stopped_report[k] == val for k,val in totals.items()), "Stopped-arm totals disagree")
            for section, select in (("fresh", lambda z:z>64), ("calibration", lambda z:z==64)):
                section_actions = [a for rid,a in actions.items() if select(rows[rid]["z"])]
                invalid = section_actions.count("I")
                need(stopped_report["coverage_by_panel"][section] ==
                     {"valid_rows":len(section_actions)-invalid, "invalid_rows":invalid},
                     "Stopped-arm calibration or fresh observation counts disagree")
            continue
        need(set(actions) == set(rows), "Incomplete primary reader")
        for pk in packets:
            for rid in pk["rows"]:
                entry = observations[rid]
                need(entry["packet"] == pk["id"] and entry["action"] == rows[rid]["action"]
                     and set(entry["responses"]) == EFFECTIVE and entry["responses"][alias] == actions[rid],
                     "Reported action differs for " + rid)
        stats = reported["scores"]["fresh"][alias]["all"]
        need(all(stats[key] == val for key,val in calc.items() if not key.startswith("h")),
             "Primary endpoints differ for " + alias)
        need(reported["models"][alias]["packets_by_status"] == dict(statuses), "Status counts differ")
    expected_dirs = EFFECTIVE | {STOPPED}
    for name in ("attempts", "responses"):
        need({p.name for p in (study / name).iterdir() if p.is_dir()} == expected_dirs,
             "Wrong reader folders under " + name)
    stop = read(study / "amendment/stop_authorization.json")
    need(stop["last_authorized_packet"] == packets[STOP_AFTER-1]["id"] and
         stop["next_unstarted_packet"] == packets[STOP_AFTER]["id"], "Authorized prefix differs")
    authorized = original.instant(stop["timestamp"])
    need(starts[STOPPED] <= authorized <= starts["qwen25"], "Request and authorization chronology disagree")
    witness_path = study / "verification/amendment_git_witness.json"
    native_repo = (study / ".git").exists()
    if native_repo:
        witness = make_witness(study, attested_paths)
    else:
        need(witness_path.is_file(), "An extracted archive requires verification/amendment_git_witness.json")
        witness = read(witness_path)
    stamps = verify_witness(study, witness, attested_paths)
    need(stamps[original.FREEZE] <= stamps[original.PREFLIGHT] <= min(starts.values()),
         "Original freeze postdates initial request")
    need(authorized.replace(microsecond=0) <= stamps[witness["revision"]] <= starts["qwen25"],
         "Amendment was not recorded before Qwen collection")
    if git_timing_output is not None:
        git_timing_output.write_text(json.dumps(witness, indent=2, sort_keys=True) + "\n")
    return {"first_freeze": original.FREEZE, "preflight": original.PREFLIGHT,
            "amendment_commit": witness["revision"], "local_git_available": native_repo,
            "original_manifest_sha256": original.MANIFEST_SHA,
            "amendment_manifest_sha256": digest(path.read_bytes()),
            "amendment_commit_utc": stamps[witness["revision"]].isoformat(),
            "qwen_first_utc": starts["qwen25"].astimezone(timezone.utc).isoformat(),
            "response_files": sum(m["packets"] for m in measured.values()),
            "physical_attempts": sum(m["attempts"] for m in measured.values()),
            "effective_cohort": sorted(effective), "readers": measured}


if __name__ == "__main__":
    cmd = argparse.ArgumentParser(description=__doc__)
    cmd.add_argument("--study", type=Path, default=HERE.parent)
    cmd.add_argument("--git-timing-output", type=Path,
                     help="If requested, save the replayable local-Git chronology proof at this path.")
    opts = cmd.parse_args()
    print(json.dumps(audit(opts.study.resolve(), opts.git_timing_output), indent=2, sort_keys=True))
