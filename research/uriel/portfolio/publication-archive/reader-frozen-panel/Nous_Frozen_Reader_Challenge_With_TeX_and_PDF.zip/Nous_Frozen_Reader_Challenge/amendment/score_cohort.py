"""Apply the original scoring contract to the three completed, amended readers.

Run from a standalone extracted study with python3 -B amendment/score_cohort.py.
Verified original files remain untouched. A temporary input view points at the
one shared panel, the amended model registry, and the original returned files.
"""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import NamedTemporaryFile, TemporaryDirectory

STUDY = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(STUDY))
from score import read, require, score, validate_panel


def authenticated(study):
    original_hashes = read(study / "FROZEN.json")
    for name, expected in original_hashes.items():
        require(sha256((study/name).read_bytes()).hexdigest() == expected, "Original freeze mismatch: " + name)
    original = read(study/"frozen/models.json")
    active = read(study/"amendment/models.json")
    require(set(original) == {"llama32","deepseek8","gptoss20"}, "Unexpected original cohort")
    require(set(active) == {"llama32","qwen25","gptoss20"}, "Unexpected amended cohort")
    for name in ("llama32","gptoss20"):
        require(original[name] == active[name], "Retained model configuration changed: " + name)
    require(read(study/"amendment/stop_authorization.json")["last_authorized_packet"] == "p004",
            "Stop authorization differs from receipt boundary")
    return original


def stopped_arm(study, model, rows, packets):
    """Audit coverage of the authorized prefix only; no imputed predictions."""
    stop_pid = read(study/"amendment/stop_authorization.json")["last_authorized_packet"]
    expected = list(packets)[:list(packets).index(stop_pid) + 1]
    root = study/"responses/deepseek8"
    files = {p.stem for p in root.glob("*.json") if p.is_file()}
    require(files == set(expected), "Stopped-arm finalized receipts differ from authorized prefix")
    journal = study/"attempts/deepseek8"
    receipt_rows = []
    metrics = Counter()
    strata = {"fresh":Counter(), "calibration":Counter()}
    for pid in expected:
        rec = read(root/(pid+".json"))
        want = packets[pid]
        for flag in [rec["model"] == model["tag"], rec["packet"] == pid, rec["digest"] == model["digest"],
                     rec["prompt_sha256"] == want["prompt_sha256"], rec["rows"] == want["rows"]]:
            require(flag, f"Stopped-arm mismatch for {pid}")
        actions = rec["actions"]
        require(len(actions) == len(rec["rows"]) and all(a in ("Y","N","A","I") for a in actions),
                "Stopped-arm action count/alphabet differs")
        trials = sorted(journal.glob(pid + ".*.json"))
        require(1 <= len(trials) <= 2, "Stopped-arm trial count outside budget")
        for trial in trials:
            info = read(trial)
            require(info["packet"] == pid and info["model"] == model["tag"], "Attempt identity mismatch")
        metrics["receipts"] += 1
        metrics["dispatches"] += len(trials)
        metrics["recorded_rows"] += len(actions)
        for ident, action in zip(rec["rows"], actions):
            a = rows[ident]
            section = "fresh" if a["z"]>64 else "calibration"
            outcome = "invalid_rows" if action == "I" else "valid_rows"
            strata[section][outcome] += 1
            metrics[outcome] += 1
        ok = all(a != "I" for a in actions)
        require(rec["status"] in ("ok","transport_error","invalid_output"), "Unknown stopped-arm packet status")
        require(ok if rec["status"] == "ok" else all(a == "I" for a in actions), "Stopped-arm parse mismatch")
        metrics[rec["status"]+"_packets"] += 1
        service = rec.get("service", {})
        metrics["input_tokens"] += service.get("prompt_eval_count") or 0
        metrics["output_tokens"] += service.get("eval_count") or 0
        receipt_rows.append({"packet":pid, "status":rec["status"], "dispatches":len(trials),
                             "row_ids":rec["rows"], "valid_rows":sum(a!="I" for a in actions)})
    require(len(list(journal.glob("*.json"))) == metrics["dispatches"], "Unexpected stopped-arm dispatches")
    return {"short":"deepseek8","model":model["tag"], **dict(metrics),
            "valid_rows":metrics["valid_rows"], "invalid_rows":metrics["invalid_rows"],
            "unrun_packets":len(packets)-len(expected), "unrun_rows":len(rows)-metrics["recorded_rows"],
            "coverage_by_panel":{k:{"valid_rows":v["valid_rows"], "invalid_rows":v["invalid_rows"]} for k,v in strata.items()},
            "packet_receipts":receipt_rows}


def score_amended(study):
    study = study.resolve()
    original = authenticated(study)
    panel = read(study/"frozen/panel.json")
    rows, packets = validate_panel(panel)
    with TemporaryDirectory(prefix="nous-amended-score-") as folder:
        view = Path(folder)
        (view/"frozen").mkdir()
        (view/"frozen/panel.json").symlink_to(study/"frozen/panel.json")
        (view/"frozen/models.json").symlink_to(study/"amendment/models.json")
        (view/"responses").symlink_to(study/"responses",target_is_directory=True)
        report = score(view, {})
    report["amendment"] = {
        "original_registry_sha256":sha256((study/"frozen/models.json").read_bytes()).hexdigest(),
        "effective_registry_sha256":sha256((study/"amendment/models.json").read_bytes()).hexdigest(),
        "interpretation":"Llama and GPT-OSS are retained original configurations. Qwen replaced DeepSeek after the local run began. The same paired descriptive rules apply; the three-reader hypothesis test is reported for the amended cohort.",
        "stopped_arm":stopped_arm(study,original["deepseek8"],rows,packets)
    }
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--study",type=Path,default=STUDY)
    ap.add_argument("--output",type=Path)
    args = ap.parse_args()
    report = score_amended(args.study)
    dest = args.output or args.study/"results.json"
    with NamedTemporaryFile(mode="w",dir=dest.parent,suffix=".tmp",delete=False) as stream:
        json.dump(report,stream,ensure_ascii=False,indent=2)
        stream.write("\n")
    Path(stream.name).replace(dest)
    print(f"Scored {len(report['models'])} complete readers; audited stopped DeepSeek coverage separately.")


if __name__ == "__main__":
    main()
