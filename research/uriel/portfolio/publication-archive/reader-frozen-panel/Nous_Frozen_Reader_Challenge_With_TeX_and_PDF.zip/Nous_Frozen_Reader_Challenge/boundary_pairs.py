"""Exploratory comparison of identical public records across cutoffs 80 and 81."""
from argparse import ArgumentParser
from collections import Counter
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
NAMES = {"llama32":"Llama 3.2", "gptoss20":"GPT-OSS", "qwen25":"Qwen2.5", "deepseek8":"DeepSeek-R1"}


def load(path):
    return json.loads(path.read_bytes())


def md_table(headers, rows):
    return "\n".join(["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|",
                      *("| " + " | ".join(map(str,row)) + " |" for row in rows)])


def matched(panel, results):
    """Every input dimension except Z, including the numeric tag, is fixed."""
    observed = {r["row"]:r for r in results["observations"]}
    rows = {80:{},81:{}}
    for r in panel["rows"]:
        z = r["z"]
        if z not in rows:
            continue
        key = (r["tag"],tuple(r["residues"]),r["e"])
        if key in rows[z]:
            raise ValueError(f"Duplicate visible key {key} at {z}")
        obs = observed[r["id"]]
        if any(obs[k]!=r[k] for k in ("tag","residues","action","yes","no","z","e")):
            raise ValueError("Score data differs from frozen observation " + r["id"])
        rows[z][key]=obs
    common=sorted(rows[80].keys() & rows[81].keys())
    return [(rows[80][k], rows[81][k]) for k in common], len(rows[80]), len(rows[81])


def transition(a,b):
    return a+"→"+b


def group_by_license(pairs):
    groups = {}
    for a,b in pairs:
        groups.setdefault(transition(a["action"],b["action"]),[]).append((a,b))
    return groups


def pattern(a,b,name):
    return transition(a["responses"][name],b["responses"][name])


def mixture(group, name):
    counts=Counter(pattern(a,b,name) for a,b in group)
    return ", ".join(f"{k} ×{v}" for k,v in sorted(counts.items(),key=lambda kv:(-kv[1],kv[0])))


def rule_outputs(a,b):
    low=a["action"]
    def majority(r):
        return "Y" if r["yes"]>r["no"] else "N"
    return {"Exact support":transition(low,b["action"]),
            "Reuse the cutoff-80 support answer":transition(low,low),
            "Exact at 80, always abstain at 81":transition(low,"A"),
            "Guess the more frequent hidden sign":transition(majority(a),majority(b)),
            "Always abstain":"A→A"}


def report(panel, result):
    names=list(result["models"])
    pairs,n0,n1=matched(panel,result)
    groups=group_by_license(pairs)
    group_n={k:len(v) for k,v in groups.items()}
    if group_n!={"Y→A":2,"N→N":5,"A→A":7} or (n0,n1)!=(34,34):
        raise ValueError("The panel differs from the specified boundary diagnostic")
    grouped=[]
    for key in ("Y→A","N→N","A→A"):
        cohort=groups[key]
        grouped.append([key,len(cohort), *[mixture(cohort,name) for name in names]])
    examples=[]
    for a,b in groups["Y→A"]:
        examples.append([a["tag"],a["e"],", ".join(a["writers"]),*(pattern(a,b,k) for k in names),
                         f"`{a['row']}` / `{b['row']}`"])
    controls=[]
    for rule in rule_outputs(*pairs[0]):
        matches=[(a,b,rule_outputs(a,b)[rule]) for a,b in pairs]
        n_oracle=sum(policy==transition(a["action"],b["action"]) for a,b,policy in matches)
        controls.append([rule,f"{n_oracle}/14",*[f"{sum(pattern(a,b,k)==policy for a,b,policy in matches)}/14" for k in names]])
    model_names=[NAMES.get(k,k) for k in names]
    valid_table=[]
    for k in names:
        valid=sum(a["responses"][k]!="I" and b["responses"][k]!="I" for a,b in pairs)
        full=sum(pattern(a,b,k)==transition(a["action"],b["action"]) for a,b in pairs)
        stable=groups["N→N"]+groups["A→A"]
        stable_correct=sum(pattern(a,b,k)==transition(a["action"],b["action"]) for a,b in stable)
        switched=sum(pattern(a,b,k)=="Y→A" for a,b in groups["Y→A"])
        valid_table.append([NAMES.get(k,k),f"{switched}/2",f"{stable_correct}/12",f"{full}/14",14-valid])
    return "\n\n".join([
        "# Which answers changed at the cutoff boundary?",
        "**Exploratory analysis.** This reuses the completed readers’ existing responses. The residue-80 pair was the preregistered H3 probe. "
        "The other matched comparisons were added after the protocol freeze. There are no new generations or independent replications here.",
        f"Match the numerical tag, complete ordered list of compatible low residues, and query weight exactly. Of {n0} distinct observations "
        f"at cutoff 80 and {n1} at cutoff 81, {len(pairs)} such records appeared at both cutoffs. On two of the pairs the supported answer "
        "changes from Y to A; on five it stays N and on seven it stays A. The entire observed cell is shared; the other rows in each "
        "eight-question packet and the row positions can differ.",
        md_table(["Reader","Correct Y→A on switches","Correct on both stable ends","Both ends correct overall","Pairs with ≥1 invalid response"],valid_table),
        "## The two switches",
        md_table(["Tag","Weight","Writers at 80",*model_names,"Public row IDs, 80 / 81"], examples),
        "For both records the compatible low residue equals the query weight. At cutoff 80 all three possible lifts give yes; at cutoff 81 "
        "only one of the three gives yes. A Y→Y response retains a previously justified answer past the point where the visible evidence licenses it. "
        "A Y→N response gets the more likely hidden sign at 81 but still makes an unsupported guess. Only Y→A follows both licenses. "
        "The labels Y, N, A and I stand for yes, no, abstain and invalid.",
        "## Changes on all matched pairs",
        md_table(["Required pair","Records",*model_names],grouped),
        "Multiple writers can expose exactly the same tag and compatible residue list. Such a record appears once per cutoff. "
        "The pair totals count both printed actions as a unit. They are distinct from the preregistered per-row totals.",
        "## Could a simpler response rule do the same?",
        md_table(["Reference rule","Pairs correct against oracle", *[n+" agreement" for n in model_names]],controls),
        "Agreement requires matching a rule’s two outputs on the same pair; I cannot match any reference rule. A blanketing rule "
        "that answers correctly at 80 and then abstains on every question at 81 passes both switches while failing the five stable N pairs. "
        "The forced guesser goes Y→N on each switch and can succeed on hidden truth with probability 2/3 at 81. The unaffected N and A "
        "cases therefore constrain the behavioral explanation of a model’s switch responses.",
        "The two switches concern singleton records with the same simple alignment, and the residue-80 switch already contributes to H3. "
        "Even perfect agreement throughout can result from checking low-residue membership and applying a threshold-specific rule. "
        "This panel cannot establish how the model computed its decisions, identify a general uncertainty mechanism, or separate cutoff effects "
        "from the surrounding packet. A prospective test would vary the cutoff and surrounding packet independently and hold out different classes of records.",
        "Rebuild from the frozen panel and completed [row-level scores](results.json) with `python3 -B boundary_pairs.py`."
    ])+"\n"


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument("--study",type=Path,default=HERE)
    p.add_argument("--output",type=Path)
    args=p.parse_args()
    source=args.study
    result=report(load(source/"frozen/panel.json"),load(source/"results.json"))
    (args.output or source/"boundary_pairs.md").write_text(result)


if __name__=="__main__":
    main()
