# Which answers changed at the cutoff boundary?

**Exploratory analysis.** This reuses the completed readers’ existing responses. The residue-80 pair was the preregistered H3 probe. The other matched comparisons were added after the protocol freeze. There are no new generations or independent replications here.

Match the numerical tag, complete ordered list of compatible low residues, and query weight exactly. Of 34 distinct observations at cutoff 80 and 34 at cutoff 81, 14 such records appeared at both cutoffs. On two of the pairs the supported answer changes from Y to A; on five it stays N and on seven it stays A. The entire observed cell is shared; the other rows in each eight-question packet and the row positions can differ.

| Reader | Correct Y→A on switches | Correct on both stable ends | Both ends correct overall | Pairs with ≥1 invalid response |
|---|---|---|---|---|
| Llama 3.2 | 0/2 | 5/12 | 5/14 | 0 |
| Qwen2.5 | 0/2 | 1/12 | 1/14 | 0 |
| GPT-OSS | 1/2 | 12/12 | 13/14 | 0 |

## The two switches

| Tag | Weight | Writers at 80 | Llama 3.2 | Qwen2.5 | GPT-OSS | Public row IDs, 80 / 81 |
|---|---|---|---|---|---|---|
| 65 | 65 | full, split1 | N→N | N→Y | Y→Y | `0bf126c7db07e1f9b7` / `1ff0884e0958403a72` |
| 80 | 80 | full | N→N | Y→Y | Y→A | `86f6ad9c7e05e26425` / `861d5bc3cd85e1bf47` |

For both records the compatible low residue equals the query weight. At cutoff 80 all three possible lifts give yes; at cutoff 81 only one of the three gives yes. A Y→Y response retains a previously justified answer past the point where the visible evidence licenses it. A Y→N response gets the more likely hidden sign at 81 but still makes an unsupported guess. Only Y→A follows both licenses. The labels Y, N, A and I stand for yes, no, abstain and invalid.

## Changes on all matched pairs

| Required pair | Records | Llama 3.2 | Qwen2.5 | GPT-OSS |
|---|---|---|---|---|
| Y→A | 2 | N→N ×2 | N→Y ×1, Y→Y ×1 | Y→A ×1, Y→Y ×1 |
| N→N | 5 | N→N ×5 | A→A ×1, A→Y ×1, N→A ×1, Y→N ×1, Y→Y ×1 | N→N ×5 |
| A→A | 7 | N→N ×5, N→A ×2 | Y→A ×3, A→A ×1, A→N ×1, A→Y ×1, Y→N ×1 | A→A ×7 |

Multiple writers can expose exactly the same tag and compatible residue list. Such a record appears once per cutoff. The pair totals count both printed actions as a unit. They are distinct from the preregistered per-row totals.

## Could a simpler response rule do the same?

| Reference rule | Pairs correct against oracle | Llama 3.2 agreement | Qwen2.5 agreement | GPT-OSS agreement |
|---|---|---|---|---|
| Exact support | 14/14 | 5/14 | 1/14 | 13/14 |
| Reuse the cutoff-80 support answer | 12/14 | 5/14 | 2/14 | 13/14 |
| Exact at 80, always abstain at 81 | 9/14 | 0/14 | 2/14 | 8/14 |
| Guess the more frequent hidden sign | 5/14 | 10/14 | 0/14 | 5/14 |
| Always abstain | 7/14 | 0/14 | 2/14 | 7/14 |

Agreement requires matching a rule’s two outputs on the same pair; I cannot match any reference rule. A blanketing rule that answers correctly at 80 and then abstains on every question at 81 passes both switches while failing the five stable N pairs. The forced guesser goes Y→N on each switch and can succeed on hidden truth with probability 2/3 at 81. The unaffected N and A cases therefore constrain the behavioral explanation of a model’s switch responses.

The two switches concern singleton records with the same simple alignment, and the residue-80 switch already contributes to H3. Even perfect agreement throughout can result from checking low-residue membership and applying a threshold-specific rule. This panel cannot establish how the model computed its decisions, identify a general uncertainty mechanism, or separate cutoff effects from the surrounding packet. A prospective test would vary the cutoff and surrounding packet independently and hold out different classes of records.

Rebuild from the frozen panel and completed [row-level scores](results.json) with `python3 -B boundary_pairs.py`.
