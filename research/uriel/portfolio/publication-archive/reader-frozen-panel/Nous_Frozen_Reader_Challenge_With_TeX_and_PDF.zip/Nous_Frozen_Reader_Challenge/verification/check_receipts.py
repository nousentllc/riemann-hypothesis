"""Independently replay matched prompts, parsing, primary counts and the H3 probe.

The retained evidence contains final response content and request digests. This
audit reconstructs the registered request; it does not authenticate the Ollama
service independently. All paths are relative to the supplied study directory.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess


FREEZE = "38b5d30d01ae1ca824bbf8bb52fdd8a3eab4589d"
PREFLIGHT = "12876a4559f0392dfb4e0c21433a490924dc6819"
MANIFEST_SHA = "f8a1c23cca900223d9e018f21315b11fbdb00078de6225f38069faee81226598"
ACTIONS = ("Y", "N", "A")


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return sha256(data).hexdigest()


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def instant(value):
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    need(stamp.tzinfo is not None, "Timezone missing from " + value)
    return stamp


def check_manifest(study):
    frozen = study / "FROZEN.json"
    need(digest(frozen.read_bytes()) == MANIFEST_SHA, "FROZEN.json differs from the registered protocol")
    pins = read(frozen)
    for path, value in pins.items():
        need(digest((study / path).read_bytes()) == value, "Frozen bytes changed in " + path)
    return pins


def chronology(study, pins, first_request):
    evidence = {"first_request_utc": first_request.astimezone(timezone.utc).isoformat(),
                "first_commit": FREEZE, "second_commit": PREFLIGHT}
    if not (study / ".git").exists():
        evidence["verified_local_repository"] = False
        return evidence

    def git(*args):
        return subprocess.check_output(["git", "-C", str(study), *args])

    previous = None
    for index, revision in enumerate((FREEZE, PREFLIGHT)):
        stamp, ancestry = git("show", "-s", "--format=%ct%n%P", revision).decode().splitlines()
        if index:
            need(ancestry == FREEZE, "Scoring freeze is not the child of the experiment freeze")
        commit_time = datetime.fromtimestamp(int(stamp), timezone.utc)
        need((previous is None or previous <= commit_time) and commit_time <= first_request,
             "Local Git and attempt-journal chronology disagree")
        previous = commit_time
        evidence["commit_" + str(index + 1) + "_utc"] = commit_time.isoformat()
        for path in (*pins.keys(), "FROZEN.json"):
            need(git("show", revision + ":" + path) == (study / path).read_bytes(),
                 "Registered source differs from commit " + revision + ": " + path)
    for path in ("check_oracle.py", "score.py", "verification/preflight_oracle.json"):
        need(git("show", PREFLIGHT + ":" + path) == (study / path).read_bytes(),
             "Scoring implementation differs from the pre-inference commit: " + path)
    evidence["verified_local_repository"] = True
    return evidence


def request_sha(model, packet, last):
    size = len(packet["rows"])
    array = {"minItems": size, "maxItems": size, "type": "array",
             "items": {"enum": list(ACTIONS), "type": "string"}}
    req = {
        "model": model["tag"],
        "messages": [{"content": packet["prompt"], "role": "user"}],
        "format": {"type": "object", "additionalProperties": False, "required": ["actions"],
                   "properties": {"actions": array}},
        "options": {"seed": 49217, "temperature": 0, "num_predict": 1536, "num_ctx": 4096},
        "stream": False,
        "keep_alive": 0 if last else "5m",
    }
    if model["think"] is not None:
        req["think"] = model["think"]
    return digest(json.dumps(req, sort_keys=True).encode())


def parse_final(rec, count):
    invalid = ["I"] * count
    if "content" not in rec:
        return invalid, "transport_error"
    if not rec["service"]["done"] or not isinstance(rec["content"], str):
        return invalid, "invalid_output"
    try:
        raw = json.loads(rec["content"])
    except (ValueError, TypeError):
        return invalid, "invalid_output"
    if not isinstance(raw, dict) or set(raw) != {"actions"}:
        return invalid, "invalid_output"
    acts = raw["actions"]
    if not isinstance(acts, list) or len(acts) != count or any(a not in ACTIONS for a in acts):
        return invalid, "invalid_output"
    return acts, "ok"


def attempts_for(study, short, model, packet, expected_sha, rec, expected_status):
    prefix = study / "attempts" / short
    found = sorted(prefix.glob(packet["id"] + ".*.json"))
    need(1 <= len(found) <= 2, "Missing journal or more than two attempts: " + str(prefix / packet["id"]))
    stamps = []
    for n, f in enumerate(found, 1):
        need(f.name == f"{packet['id']}.{n}.json", "Noncontiguous journal " + str(f))
        journal = read(f)
        need((journal["model"], journal["packet"]) == (model["tag"], packet["id"]),
             "Journal names mismatch: " + str(f))
        stamps.append(instant(journal["started"]))
        if n > 1:
            need(stamps[-2] <= stamps[-1], "Retry precedes the first attempt: " + str(f))
        if "ended" in journal:
            need(instant(journal["ended"]) >= stamps[-1], "Journal end precedes start: " + str(f))
        # The runner preserves the canonical request digest on completed generations
        # and at dispatch. It replaces its initial entry on a caught transport error.
        if "request_sha256" in journal:
            need(journal["request_sha256"] == expected_sha, "Journal request hash mismatch: " + str(f))
        if journal.get("status") in {"ok", "invalid_output"}:
            need(n == len(found) and journal["status"] == expected_status, "Ineligible retry: " + str(f))
            need(journal["started"] == rec["started"] and journal["ended"] == rec["ended"],
                 "Response/journal timestamps disagree: " + str(f))
            need(journal["request_sha256"] == expected_sha, "Final journal request digest missing: " + str(f))
        if n == len(found) and expected_status != "transport_error":
            need(journal.get("status") == expected_status, "Completed generation lacks its journal: " + str(f))
    if expected_status == "transport_error":
        need(len(found) == 2, "Transport failure was not exhausted: " + packet["id"])
    return stamps


def independent_label(row):
    weights = [r + offset for r in row["residues"] for offset in (0, 81, 162)]
    yes = 0
    for s in weights:
        difference = abs(s - row["e"])
        if difference == 0:
            yes += 1
            continue
        tw = 1
        while difference % 3 == 0:
            difference //= 3
            tw *= 3
        yes += int(tw > row["z"])
    return "A" if 0 < yes < len(weights) else "Y" if yes else "N"


def audit(study):
    pins = check_manifest(study)
    panel = read(study / "frozen/panel.json")
    models = read(study / "frozen/models.json")
    report = read(study / "results.json")
    packets = panel["packets"]
    rows = {r["id"]: r for r in panel["rows"]}
    observations = {v["row"]: v for v in report["observations"]}
    need(set(observations) == set(rows) and len(rows) == len(report["observations"]),
         "Results observations differ from the frozen rows")
    need(report["panel_sha256"] == pins["frozen/panel.json"] and set(report["models"]) == set(models),
         "Results identify different panel or readers")
    labels = {k: independent_label(r) for k, r in rows.items()}
    need(all(pred == rows[k]["action"] for k, pred in labels.items()), "Oracle mismatch")
    expected_paths = set()
    journals = set()
    all_dates = []
    reader_results = {}
    for alias, model in models.items():
        answers = {}
        statuses = Counter()
        total_attempts = 0
        for seq, packet in enumerate(packets, 1):
            pid = packet["id"]
            path = study / "responses" / alias / (pid + ".json")
            expected_paths.add(path)
            rec = read(path)
            text_hash = digest(packet["prompt"].encode())
            req_hash = request_sha(model, packet, seq == len(packets))
            need(text_hash == packet["prompt_sha256"] == rec["prompt_sha256"] == report["prompt_sha256"][pid],
                 "Prompt digest mismatch: " + str(path))
            need(rec["model"] == model["tag"] and rec["digest"] == model["digest"] and rec["packet"] == pid
                 and rec["rows"] == packet["rows"] and rec["request_sha256"] == req_hash,
                 "Request, rows or model identity disagree: " + str(path))
            parsed, status = parse_final(rec, len(packet["rows"]))
            need(parsed == rec["actions"] and status == rec["status"], "Final JSON reparse failed for " + str(path))
            dates = attempts_for(study, alias, model, packet, req_hash, rec, status)
            for n in range(1, len(dates) + 1):
                journals.add(study / "attempts" / alias / f"{pid}.{n}.json")
            all_dates.extend(dates)
            total_attempts += len(dates)
            statuses[status] += 1
            for k, action in zip(packet["rows"], parsed):
                need(k not in answers, "Same row is served twice per reader")
                need(observations[k]["responses"][alias] == action and observations[k]["packet"] == pid
                     and observations[k]["action"] == labels[k], "Row-level results disagree: " + k)
                answers[k] = action
        need(set(answers) == set(rows), "Missing reader rows")
        need(report["models"][alias]["packets_by_status"] == dict(statuses), "Packet-status counts disagree")
        matrix = {target: {key: 0 for key in (*ACTIONS, "I")} for target in ACTIONS}
        boundary = {}
        for k, row in rows.items():
            if row["z"] == 64:
                continue
            matrix[labels[k]][answers[k]] += 1
            if row["e"] == 80 and row["tag"] == 80 and row["residues"] == [80] and row["z"] in (80, 81):
                need("full" in observations[k]["writers"], "H3 full-writer linkage missing")
                boundary[row["z"]] = answers[k]
        recorded = report["scores"]["fresh"][alias]["all"]
        n_amb = sum(matrix["A"].values())
        n_set = sum(matrix["Y"].values()) + sum(matrix["N"].values())
        guesses = matrix["A"]["Y"] + matrix["A"]["N"]
        correct = matrix["Y"]["Y"] + matrix["N"]["N"]
        counts = {"settled": n_set, "ambiguous": n_amb, "settled_correct": correct,
                  "unsupported_guesses": guesses}
        need(all(recorded[k] == v for k, v in counts.items()) and
             recorded["confusion_target_then_response"] == matrix, "Primary score mismatch for " + alias)
        need(set(boundary) == {80, 81}, "Missing H3 matched observation")
        reader_results[alias] = {
            "attempts": total_attempts, "packets": dict(statuses), "counts": counts,
            "fresh_confusion": matrix, "h1_any_definitive_guess": guesses > 0,
            "h2_at_least_90pct_settled_and_10pct_guess": 10*correct >= 9*n_set and 10*guesses >= n_amb,
            "h3_z80_then_z81": [boundary[80], boundary[81]],
            "h3_carried_yes": boundary[80] == boundary[81] == "Y",
        }
    need(set((study / "responses").glob("*/*.json")) == expected_paths, "Extra or missing model receipts")
    need(set((study / "attempts").glob("*/*.json")) == journals, "Extra or missing attempt journals")
    output = {"study_freeze_manifest_sha256": MANIFEST_SHA, "responses_checked": len(expected_paths),
              "attempts_checked": len(journals), "scores_sha256": digest((study / "results.json").read_bytes()),
              "readers": reader_results, "local_timing": chronology(study, pins, min(all_dates))}
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, default=Path(__file__).resolve().parents[1])
    print(json.dumps(audit(parser.parse_args().study.resolve()), indent=2, sort_keys=True))
