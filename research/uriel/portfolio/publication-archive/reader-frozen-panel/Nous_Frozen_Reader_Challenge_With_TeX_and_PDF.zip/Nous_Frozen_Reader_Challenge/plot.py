"""Render the primary count table from the completed results (optional: Pillow)."""
from pathlib import Path
import json
from PIL import Image, ImageDraw, ImageFont
HERE=Path(__file__).resolve().parent
names={'llama32':'Llama 3.2 3B','deepseek8':'DeepSeek-R1 8B','gptoss20':'GPT-OSS 20B','qwen25':'Qwen2.5 3B'}
def font(pt,bold=False):
    options=('/System/Library/Fonts/Supplemental/Arial Bold.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf') if bold else ('/System/Library/Fonts/Supplemental/Arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    for t in options:
        if Path(t).is_file():return ImageFont.truetype(t,pt)
    return ImageFont.load_default(size=pt)
def run():
    r=json.loads((HERE/'results.json').read_bytes())
    m={k:r['scores']['fresh'][k]['all'] for k in r['models']}
    paper='#ffffff';ink='#172d3c';muted='#4b5e69';rule='#cfdbdd'
    canvas=Image.new('RGB',(1610,680),paper);d=ImageDraw.Draw(canvas)
    def words(x,y,s,pt=22,col=ink,bold=False):
        d.text((x,y),s,fill=col,font=font(pt,bold))
    words(48,34,'When did each reader guess?',48,bold=True)
    words(50,102,'Same 271 fresh record–query observations for each of three local configurations',24,muted)
    headers=[('Unsupported guesses','of 162 ambiguous records','unsupported_guesses','ambiguous','#a95828'),
             ('Settled answers correct','of 109 settled records','settled_correct','settled','#166a66'),
             ('Settled yes correct','of 13 positives','settled_positive_correct','settled_positive','#166a66'),
             ('Settled no correct','of 96 negatives','settled_negative_correct','settled_negative','#166a66')]
    for i,(head,sub,*_) in enumerate(headers):
        x=346+306*i
        words(x,190,head,21,bold=True); words(x,223,sub,18,muted)
    for j,model in enumerate(m):
        label=names[model]
        y=282+j*94
        d.line((50,y-16,1560,y-16),fill=rule,width=1)
        words(50,y+11,label,26,bold=True)
        for i,(_,__,num,den,color) in enumerate(headers):
            a,b=m[model][num],m[model][den];x=346+306*i
            words(x,y,f'{a}/{b}   ({100*a/b:.1f}%)',23)
            d.rectangle((x,y+40,x+235,y+51),fill='#e6eeed')
            if a:d.rectangle((x,y+40,x+round(235*a/b),y+51),fill=color)
    invalid=', '.join(f'{names[k]} {m[k]["total_invalid"]}' for k in m)
    words(50,576,'Lower is better for unsupported guesses. Higher is better for the three accuracy measures.',21,muted)
    words(50,616,'Invalid fresh responses: '+invalid+'. Invalids receive no correctness credit.',19,muted)
    canvas.save(HERE/'Reader_Comparison.png',optimize=True)
if __name__=='__main__':run()
