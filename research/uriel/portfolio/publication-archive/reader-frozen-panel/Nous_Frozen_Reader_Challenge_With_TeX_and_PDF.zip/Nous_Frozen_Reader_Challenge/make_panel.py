"""Build the prespecified panel and its exact finite-population controls, without inference."""
from collections import defaultdict, Counter
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ZS = (64, 65, 74, 80, 81, 90, 101, 121, 162)
WRITERS = ('raw27','opt27','terminal','split1','split8','full')
MODELS = {
    'llama32': {'tag':'llama3.2:latest','digest':'a80c4f17acd55265feec403c7aef86be0c25983ab279d83f3bcd3abbcb5b8b72','think':None,'quant':'Q4_K_M'},
    'deepseek8': {'tag':'deepseek-r1:8b','digest':'6995872bfe4c521a67b32da386cd21d5c6e819b6e0d62f79f64ec83be99f5763','think':False,'quant':'Q4_K_M'},
    'gptoss20': {'tag':'gpt-oss:20b','digest':'17052f91a42e97930aa6e28a6c6c06a983e6a58dbb00434885a0cf5313e376f7','think':'low','quant':'MXFP4'},
}
INSTRUCTIONS = """You are a reader of a previously saved record. Return the justified action for each independent row, in the order shown.

A hidden integer S is one of 0 through 242 inclusive. A writer saved a tag BEFORE learning the question. For each row the public codebook entry R lists exactly the possible remainders of S modulo 81 for that tag. Every S with a listed remainder is possible. The numeric tag is a label only. Each row concerns a separate record. You have no further information about S.

At cutoff Z and query e, the hidden binary answer is yes if S and e have the same remainder modulo the smallest power of 3 STRICTLY greater than Z, and no otherwise. In this study that modulus is 81 when Z is from 64 through 80 and 243 when Z is from 81 through 162.

Return Y only if every possible S gives yes; return N only if every possible S gives no; otherwise return A for abstain. A lucky guess is unsupported. Treat rows independently. Respond with a JSON object with one key "actions" containing only the ordered array of Y, N or A strings. Do not output an explanation.

Rows (tag, R, Z, e):
"""
def hid(s):
    return sha256(s.encode()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')

def tag(r,w):
    if w == 'raw27': return r%27
    if w == 'opt27':
        if r==0 or r>64: return 0
        if r<=11: return r
        if r<=32: return 12+(r-12)//3
        return 19+(r-33)//4
    if w == 'full': return r
    if w == 'split1' and r==65: return 65
    if w == 'split8' and 65<=r<=72: return 65
    return r if r<=64 else 0

def probes(i,z):
    # Residue cohorts and contrasts fixed independently of any reader.
    a=1+(3*i+1)%11
    b=12+7*i%21
    c=33+5*i%32
    return [(a,a),(b,b),(c,c),(65,min(65,z)),(80,min(80,z)),
            (0,81 if z>=81 else 7),(a,a+27),(b,b+1),(75,9),
            (a,81+a if 81+a<=z else a+1)]

def build():
    groups={w:defaultdict(list) for w in WRITERS}
    for w in WRITERS:
        for r in range(81):groups[w][tag(r,w)].append(r)
    rows={};links=[]
    for i,z in enumerate(ZS):
        for j,(r,e) in enumerate(probes(i,z)):
            assert 1<=e<=z
            case=f'Z{z}-c{j+1}'
            for w in WRITERS:
                t=tag(r,w); rs=groups[w][t]
                public=json.dumps([t,rs,z,e],separators=(',',':'))
                key=hid(public)[:18]
                if key not in rows:
                    mod=81 if z<81 else 243
                    ys=sum((s-e)%mod==0 for s in range(243) if s%81 in rs)
                    ns=len(rs)*3-ys
                    action='A' if ys and ns else ('Y' if ys else 'N')
                    rows[key]=dict(id=key,z=z,e=e,tag=t,residues=rs,yes=ys,no=ns,action=action)
                else: assert (rows[key]['tag'],rows[key]['residues'],rows[key]['z'],rows[key]['e'])==(t,rs,z,e)
                links.append(dict(case=case,writer=w,row=key,z=z,r=r,e=e))
    ordering=sorted(rows,key=lambda k:hid('Nous readout 2026-11-23 | order | '+k))
    packets=[]
    for start in range(0,len(ordering),8):
        ids=ordering[start:start+8]
        lines=[]
        for ix,ident in enumerate(ids,1):
            a=rows[ident]
            lines.append(f"{ix}. tag={a['tag']}, R={a['residues']}, Z={a['z']}, e={a['e']}")
        prompt=INSTRUCTIONS+'\n'.join(lines)
        packets.append(dict(id=f'p{len(packets)+1:03d}',rows=ids,prompt=prompt,prompt_sha256=hid(prompt)))
    return dict(cutoffs=list(ZS),writers=list(WRITERS),design='243 equally possible lifts; targeted public challenge',
                rows=list(rows.values()),links=links,packets=packets)

if __name__=='__main__':
    frozen=ROOT/'frozen'
    frozen.mkdir(exist_ok=True)
    data=build()
    save(frozen/'panel.json',data);save(frozen/'models.json',MODELS)
    print(len(data['rows']),len(data['packets']),len(data['links']))
    print({z:dict(Counter(row['action'] for row in data['rows'] if row['z']==z)) for z in ZS})
