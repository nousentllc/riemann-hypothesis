# Frozen reader challenge

Three local instruction models read the same 38 packets of saved records. The two primary questions are how often a reader makes a definite guess when the record is ambiguous and how often it gives the right sign when the record settles the answer. The complete comparison uses Llama 3.2 3B, Qwen2.5 3B Instruct and GPT-OSS 20B. A fourth configuration, DeepSeek-R1 8B, was stopped after four packets. Its observed prefix has a separate coverage ledger.

Start with [the results](RESULTS.md), [the comparison chart](Reader_Comparison.png) or [the primary tables](comparison.csv). [results.json](results.json) records the per-row decisions, confusion counts, deterministic controls and stopped-arm coverage. [case_decisions.csv](case_decisions.csv) exposes the decisions row by row. [ambiguity_types.csv](ambiguity_types.csv) breaks down the sources of ambiguity in a descriptive analysis added after registration.

## What was frozen and when

1. [The original protocol](PROTOCOL.md) and the collection code were committed at `38b5d30d01ae1ca824bbf8bb52fdd8a3eab4589d`. Commit `12876a4559f0392dfb4e0c21433a490924dc6819` added the scorer and independent oracle checks before the first request. The original cohort comprised Llama, DeepSeek and GPT-OSS. The original rules provided for preinstalled weights, no model substitutions and a **$0 paid-inference cap**.
2. Llama completed all 38 packets. Its preliminary scores had been seen when the investigator approved replacing DeepSeek after observing three empty public final answers at the generation limit. The fourth DeepSeek request was already in flight and also ended at the 1,536-token limit with an empty final answer. None of these four outputs supplies a valid yes, no or abstention. The remaining 34 packets were never dispatched to DeepSeek. [Stop authorization](amendment/stop_authorization.json)
3. [The amendment](amendment/PROTOCOL.md) was committed at `92d010b7aa914313dd0e8c458a1096ee2912085b` before the first Qwen study request. It retained the original questions, order, scoring rules, endpoints and global dispatch ceiling of 228. It authorized **one model-weight download** from the Ollama registry after the local BF16 Qwen checkpoint could not be imported into this Ollama version. The recorded serving artifact is the official `qwen2.5:3b` distribution. The archived Modelfile documents the import attempt. Qwen ran locally with its native chat template; GPT-OSS retained its original settings. Electricity, hardware and weight acquisition are outside the $0 cap on paid inference. [Effective model pins](amendment/models.json) · [Qwen identity](amendment/qwen_identity.json)
4. The amended comparison carries forward Llama's original receipts and collects Qwen then GPT-OSS on the same 38 packets each. The stopped prefix adds four packets to the three full arms. The substitution was informed by observed DeepSeek failures and earlier Llama results. The timing witness documents local Git chronology. No third-party timestamp is claimed.

## Population and scoring

The six writers store functions of the residue modulo 81. The public prompt expands each observed tag into its allowed residues using its fixed codebook. The hidden center can be any of the 243 lifts across all residues. At cutoff 81 a matching four-digit residue can cease to support a definitive yes. The record still carries the same four ternary digits at most.

The [frozen panel](frozen/panel.json) contains 33 distinct public calibration observations at cutoff 64 and 271 fresh observations at cutoffs 65, 74, 80, 81, 90, 101, 121 and 162. Every complete reader received the same deduplicated observations in the same packets. The first denominator in the main comparison counts fresh ambiguous observations. The second counts fresh settled observations. Unsupported guesses, earned abstentions, correct signs, wrong signs, unwarranted abstentions and invalid outputs have distinct entries. Findings describe these configurations on this targeted panel. The answer key appears in the archive for offline scoring; the saved prompt texts and public receipts show what the readers actually received.

## Replay the published evidence without inference

From a writable copy of the extracted package, use Python 3.11 or later on macOS or Linux. These commands use the standard library. The scorer for the amended cohort checks the DeepSeek prefix separately and writes all four accounting records into one report. The auditor independently verifies the two freezes, request hashes, responses, chronology and endpoint counts. The archive supplies the Git timing witness needed when no native study repository is present.

~~~sh
python3 -B check_oracle.py
python3 -B amendment/score_cohort.py
python3 -B amendment/check_receipts.py
python3 -B summarize.py
python3 -B rows_csv.py
~~~

The last two commands regenerate RESULTS.md and the CSV tables. To regenerate the optional chart with Pillow installed, run `python3 -B plot.py`. The original `score.py` supplied the scoring contract and is called by the amended scorer. Its standalone default expects all three *original* configurations to have completed. For a local Git view of the recorded history, run `git clone study-history.bundle ../frozen-reader-history`.

## Repeat inference as a new run

The historical receipts already contain the answers. Use a fresh directory if the objective is to collect new model outputs. Have Ollama **0.40.4** running at `127.0.0.1:11434` with the digests in [the original registry](frozen/models.json) and [the amendment registry](amendment/models.json). The online weight-acquisition exception in the original run covered the official Qwen distribution only; the commands below assume the required snapshots are already installed. Native templates, greedy decoding and a fixed seed still allow hardware or backend differences between runs.

First copy the code and frozen inputs from the extracted archive. Keep the historical receipts in the original directory. The following creates a new sibling directory and fails if the name is already taken.

~~~sh
python3 -B - <<'PY'
from pathlib import Path
from shutil import copy2, copytree
source = Path.cwd()
target = source.parent / "frozen-reader-repeat"
target.mkdir()
for name in ("FROZEN.json", "PROTOCOL.md", "make_panel.py", "run_readers.py",
             "score.py", "check_oracle.py", "summarize.py", "rows_csv.py", "plot.py"):
    copy2(source / name, target / name)
for name in ("frozen", "amendment"):
    copytree(source / name, target / name)
PY
cd ../frozen-reader-repeat
~~~

Use the original request function to collect Llama's 38 packets and exactly the first four DeepSeek packets. The last-packet flag is computed against the full original sequence for both configurations. In particular DeepSeek packet four uses the same keep-alive setting as the original request. The function journals attempts and checks existing responses on resumption. The four-packet stop in a new repeat is fixed independently of the answers it returns.

~~~sh
python3 -B - <<'PY'
import fcntl
import json
from pathlib import Path
import run_readers as runner
runner.receipts()
registry = json.loads(Path("frozen/models.json").read_bytes())
packets = json.loads(Path("frozen/panel.json").read_bytes())["packets"]
authorization = json.loads(Path("amendment/stop_authorization.json").read_bytes())
stop = next(i + 1 for i, p in enumerate(packets)
            if p["id"] == authorization["last_authorized_packet"])
assert len(packets) == 38 and stop == 4
if runner.query("/api/version")["version"] != "0.40.4":
    raise RuntimeError("Ollama version differs from the study")

def check_snapshot(model):
    tags = {m["name"]: m["digest"] for m in runner.query("/api/tags")["models"]}
    if tags.get(model["tag"]) != model["digest"]:
        raise RuntimeError("Model digest differs for " + model["tag"])

with Path(".run.lock").open("a") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for alias, count in (("llama32", len(packets)), ("deepseek8", stop)):
        model = registry[alias]
        check_snapshot(model)
        for i, packet in enumerate(packets[:count], 1):
            print(alias, packet["id"], runner.generate(
                alias, model, packet, i == len(packets)), flush=True)
        check_snapshot(model)
PY
python3 -B amendment/run.py --rundir
python3 -B amendment/score_cohort.py
python3 -B summarize.py
python3 -B rows_csv.py
~~~

The amendment runner verifies both manifests, enforces the aggregate dispatch cap, and runs Qwen followed by GPT-OSS. These commands create a new sample with its own timestamps and request journals. To inspect the timing of the actual substitution, use the independent receipt auditor on the **archived** package as shown above. It compares the recorded DeepSeek and Qwen request times with the actual dated authorization and amendment.

[Matched boundary pairs](boundary_pairs.md) compares the public records held fixed at cutoffs 80 and 81. Run `python3 -B boundary_pairs.py` after scoring. Only the residue-80 sentinel was specified before inference.
