"""Run the frozen prompts on the pinned, preinstalled localhost readers. No cloud client."""
import argparse
from datetime import datetime, timezone
import fcntl
from hashlib import sha256
import json
import os
from pathlib import Path
import time
import urllib.error
import urllib.request

HERE=Path(__file__).resolve().parent
HOST='http://127.0.0.1:11434'
CLIENT=urllib.request.build_opener(urllib.request.ProxyHandler({}))
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError("Redirect disabled")
CLIENT=urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

def now():
    return datetime.now(timezone.utc).isoformat()

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.pending')
    temp.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
    os.replace(temp,path)

def query(path,payload=None):
    data=None if payload is None else json.dumps(payload).encode()
    req=urllib.request.Request(HOST+path,data=data,headers={'Content-Type':'application/json'})
    with CLIENT.open(req,timeout=260) as resp:
        return json.load(resp)

def receipts():
    pins=json.loads((HERE/'FROZEN.json').read_bytes())
    for p,h in pins.items():
        if sha256((HERE/p).read_bytes()).hexdigest()!=h:raise ValueError('Frozen file changed: '+p)

def generate(short,model,packet,last):
    target=HERE/'responses'/short/(packet['id']+'.json')
    n=len(packet['rows'])
    schema={'type':'object','properties':{'actions':{'type':'array','minItems':n,'maxItems':n,'items':{'type':'string','enum':['Y','N','A']}}},
            'required':['actions'],'additionalProperties':False}
    payload={'model':model['tag'],'messages':[{'role':'user','content':packet['prompt']}],
             'stream':False,'format':schema,'options':{'temperature':0,'seed':49217,'num_ctx':4096,'num_predict':1536},
             'keep_alive':0 if last else '5m'}
    if model['think'] is not None:payload['think']=model['think']
    base=dict(model=model['tag'],digest=model['digest'],rows=packet['rows'],packet=packet['id'],
              prompt_sha256=packet['prompt_sha256'],request_sha256=sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest(),
              actions=['I']*n,status='transport_error')
    if target.exists():
        prev=json.loads(target.read_bytes())
        for k in ('packet','model','digest','rows','prompt_sha256','request_sha256'):
            if base[k]!=prev[k]:raise ValueError(f'Cannot resume unmatched receipt {target}: {k}')
        return prev['status']
    journal=HERE/'attempts'/short
    journal.mkdir(parents=True,exist_ok=True)
    for attempt in (1,2):
        path=journal/(packet['id']+f'.{attempt}.json')
        if path.exists():continue
        started=now()
        with path.open('x') as fp:
            json.dump(dict(started=started,packet=packet['id'],model=model['tag'],request_sha256=base['request_sha256']),fp)
        try:answer=query('/api/chat',payload)
        except (OSError, ValueError) as err:
            base.update(error=str(err)[:250],ended=now())
            write(path,dict(started=started,ended=base['ended'],packet=packet['id'],model=model['tag'],error=base['error']))
            if attempt==1:time.sleep(2)
            continue
        if answer.get('model')!=model['tag']:raise ValueError('Unexpected response model '+str(answer.get('model')))
        content=answer.get('message',{}).get('content','')
        base.update(started=started,ended=now(),status='invalid_output',content=content,
                    service={k:answer.get(k) for k in ('created_at','done','done_reason','total_duration','load_duration','prompt_eval_count','eval_count','eval_duration')})
        try:
            parsed=json.loads(content)
            actions=parsed['actions']
            if (answer.get('done') and set(parsed)=={'actions'} and len(actions)==n
                and isinstance(actions,list) and all(a in ('Y','N','A') for a in actions)):
                base.update(actions=actions,status='ok')
        except (KeyError,ValueError,TypeError):pass
        write(path,dict(started=started,ended=base['ended'],model=model['tag'],packet=packet['id'],status=base['status'],request_sha256=base['request_sha256']))
        break
    write(target,base)
    return base['status']

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--rundir',action='store_true',help='execute all three local readers')
    args=ap.parse_args()
    if not args.rundir:ap.error('Use --rundir to start or resume')
    receipts()
    modelmap=json.loads((HERE/'frozen/models.json').read_bytes())
    panel=json.loads((HERE/'frozen/panel.json').read_bytes())
    assert len(modelmap)==3 and len(panel['packets'])==38
    lock_path=HERE/'.run.lock'
    with lock_path.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        version=query('/api/version')['version']
        if version!='0.40.4':raise ValueError('Ollama version differs: '+version)
        for short,model in modelmap.items():
            inventory={v['name']:v for v in query('/api/tags')['models']}
            if inventory[model['tag']]['digest']!=model['digest']:raise ValueError('Model digest changed')
            for idx,p in enumerate(panel['packets'],1):
                status=generate(short,model,p,idx==len(panel['packets']))
                print(now(),short,p['id'],status,flush=True)
            current={v['name']:v['digest'] for v in query('/api/tags')['models']}
            if current[model['tag']]!=model['digest']:raise ValueError('Model changed during evaluation')
if __name__=='__main__':main()
