# Which readers guessed when the record required abstention?

The original three-reader plan began with Llama, DeepSeek and GPT-OSS. DeepSeek was stopped after 4 finalized packets and replaced with Qwen2.5 3B under the [amendment](amendment/PROTOCOL.md). The three complete readers below share the original prompts, rows and scoring rules. The named cohort changed after the run began, so the three-reader hypothesis results refer to the amended cohort.

## Fresh-cutoff results

All three readers saw the same record and question on each of 271 distinct public observations. On 162 observations the saved record allowed both hidden answers. Either a yes or a no was an unsupported guess. On the remaining 109 observations, exactly one sign was justified: 13 yes and 96 no.

| Reader | Guessed on ambiguous | Correct on settled | Correct settled yes | Correct settled no | Invalid |
|---|---|---|---|---|---|
| Llama 3.2 3.2B | 152/162 (93.8%) | 85/109 (78.0%) | 0/13 (0.0%) | 85/96 (88.5%) | 0/271 |
| Qwen2.5 3B Instruct | 84/162 (51.9%) | 24/109 (22.0%) | 6/13 (46.2%) | 18/96 (18.8%) | 0/271 |
| GPT-OSS 20.9B | 25/162 (15.4%) | 109/109 (100.0%) | 13/13 (100.0%) | 96/96 (100.0%) | 0/271 |

GPT-OSS supplied the justified sign on 109 of 109 settled observations. Its unsupported guesses split 0/36 below the boundary and 25/126 at or above it. Within that latter group it guessed on 15/34 singleton records. A singleton identifies one remainder; the query can still distinguish the three integers behind it. The [matched boundary pairs](boundary_pairs.md) and [ambiguity table](ambiguity_types.csv) examine this pattern descriptively. These comparisons do not identify the reader’s internal method.

Always saying no answers 96 of 109 settled questions successfully while producing a guess on every ambiguous question. Reporting positives and negatives separately exposes the high score a default no can earn on this panel.

## A hand check for the answer key

Let R be the list of possible remainders shown to the reader. Each remainder r represents exactly three hidden integers in this experiment: r, r + 81 and r + 162. A matching remainder below cutoff 81 therefore supplies three yes witnesses, while a matching remainder at or above cutoff 81 supplies exactly one. A missing remainder supplies none. There are always 3 × |R| possible hidden integers.

| Question about e | Answer justified by the record |
|---|---|
| The remainder of e modulo 81 is absent from R | N at every tested cutoff. Every compatible integer fails. |
| It is present and Z is 65, 74 or 80 | Y for a singleton R. A for any larger R. |
| It is present and Z is at least 81 | A even for a singleton R. Two of the three lifts at that remainder fail. |

This gives a direct way to check any disputed row without running a language model. In particular, all 13 settled positives on the fresh panel lie below 81. The 96 settled negatives can still be resolved with a single exclusion test. A high settled score can therefore hide a reader that misses every licensed positive.

## What the readers did

| Reader | Ambiguous → yes | Ambiguous → no | Ambiguous → abstain | Ambiguous → invalid | Expected hidden-truth agreement of guesses |
|---|---|---|---|---|---|
| Llama 3.2 3.2B | 2 | 150 | 10 | 0 | 82.84% (924781/1116288) |
| Qwen2.5 3B Instruct | 54 | 30 | 78 | 0 | 39.48% (30445/77112) |
| GPT-OSS 20.9B | 13 | 12 | 137 | 0 | 60.64% (55663/91800) |

For each ambiguous guess, hidden-truth agreement is its expected chance of matching the hidden sign given a uniform draw from its compatible integers. Guessed public observations are weighted equally. This diagnostic does not turn a lucky answer into a justified one.

| Reader | Settled wrong sign | Settled abstentions | Settled invalid | Guess-rate bounds | Settled-accuracy bounds |
|---|---|---|---|---|---|
| Llama 3.2 3.2B | 13 | 11 | 0 | 93.8–93.8% | 78.0–78.0% |
| Qwen2.5 3B Instruct | 27 | 58 | 0 | 51.9–51.9% | 22.0–22.0% |
| GPT-OSS 20.9B | 0 | 0 | 0 | 15.4–15.4% | 100.0–100.0% |

Invalid results earned zero correctness credit. The bounds show the smallest and largest rates possible if every missing ambiguous answer were a guess or an abstention, and every missing settled answer were correct or unsuccessful. A packet with malformed final content contributes eight invalid rows. Token accounting appears below.

## Boundary probe and hypotheses

At weight 80 a full-residue tag of 80 allows the hidden integers 80, 161 and 242. All three match 80 modulo 81 at cutoff 80. At cutoff 81 the modulus changes to 243 and only the first matches; the supported action changes from Y to A. The preregistered H3 failure is specifically Y at both cutoffs.

| Reader | Cutoff 80 (Y) | Cutoff 81 (A) | H1 | H2 | H3 |
|---|---|---|---|---|---|
| Llama 3.2 3.2B | N | N | Observed | Not observed | Not observed |
| Qwen2.5 3B Instruct | Y | Y | Observed | Not observed | Observed |
| GPT-OSS 20.9B | Y | A | Observed | Observed | Not observed |

H1 (observed) required at least one reader to guess on a fresh ambiguous question. H2 (observed) required one reader to attain at least 90% accuracy on settled rows and at least 10% guesses on ambiguous rows. H3 (observed) tested the specified boundary pair. An invalid response makes a claim unresolved only when assigning it an admissible action could change the conclusion.

The probe row IDs are `86f6ad9c7e05e26425` and `861d5bc3cd85e1bf47`. Each observation, eligible writers, support action and model output remain in [results.json](results.json).

## Matched disagreements

Each row compares the two named readers on the identical observations. A successful ambiguity decision is an explicit abstention. A successful settled decision has the correct sign. Invalid outputs count as unsuccessful for these tables.

| Left | Right | Outcome | Both | Left only | Right only | Neither |
|---|---|---|---|---|---|---|
| Llama 3.2 3.2B | Qwen2.5 3B Instruct | abstains on ambiguity | 6 | 4 | 72 | 80 |
| Llama 3.2 3.2B | Qwen2.5 3B Instruct | correct on settled | 15 | 70 | 9 | 15 |
| Llama 3.2 3.2B | GPT-OSS 20.9B | abstains on ambiguity | 7 | 3 | 130 | 22 |
| Llama 3.2 3.2B | GPT-OSS 20.9B | correct on settled | 85 | 0 | 24 | 0 |
| Qwen2.5 3B Instruct | GPT-OSS 20.9B | abstains on ambiguity | 69 | 9 | 68 | 16 |
| Qwen2.5 3B Instruct | GPT-OSS 20.9B | correct on settled | 24 | 0 | 85 | 0 |

## What packet position might explain

This analysis was added after inspecting Llama’s returns. Among the fresh ambiguous observations in position two, Llama abstained on 9 of 21. In the other seven positions combined, it abstained on 1 of 141. The same slot also attracted abstentions when a definite answer was warranted: 10 of 14 settled negatives in position two versus 1 of 82 elsewhere. This helps explain why even a seemingly successful abstention is weak evidence that the model identified the uncertainty in that particular record. The [position table](position_counts.csv) includes every reader, packet position, support class and returned action.

Each record appeared in one position only. Its arithmetic, neighbors and position can all affect the answer. A clean follow-up would keep the same eight records together, cyclically rotate each packet through all eight positions, and measure how often the same reader changes its answer on the very same question. The present study does not estimate that causal effect.

## Exact controls and calibration

| Reader | Guessed on ambiguous | Correct on settled | Correct settled yes | Correct settled no | Invalid |
|---|---|---|---|---|---|
| Exact support | 0/162 (0.0%) | 109/109 (100.0%) | 13/13 (100.0%) | 96/96 (100.0%) | 0/271 |
| Always no | 162/162 (100.0%) | 96/109 (88.1%) | 0/13 (0.0%) | 96/96 (100.0%) | 0/271 |
| Always abstain | 0/162 (0.0%) | 0/109 (0.0%) | 0/13 (0.0%) | 0/96 (0.0%) | 0/271 |
| Forced majority | 162/162 (100.0%) | 109/109 (100.0%) | 13/13 (100.0%) | 96/96 (100.0%) | 0/271 |

The forced-majority reader chooses whichever hidden sign occurs more often in its observation, breaking ties to no. The exact support reader answers only when all compatible values agree.

The cutoff-64 calibration observations are separate from every primary rate and hypothesis above.

| Reader | Guessed on ambiguous | Correct on settled | Correct settled yes | Correct settled no | Invalid |
|---|---|---|---|---|---|
| Llama 3.2 3.2B | 6/7 (85.7%) | 23/26 (88.5%) | 0/3 (0.0%) | 23/23 (100.0%) | 0/33 |
| Qwen2.5 3B Instruct | 2/7 (28.6%) | 9/26 (34.6%) | 2/3 (66.7%) | 7/23 (30.4%) | 0/33 |
| GPT-OSS 20.9B | 0/7 (0.0%) | 26/26 (100.0%) | 3/3 (100.0%) | 23/23 (100.0%) | 0/33 |

## Scope, files and spend

The deliberate challenge panel overrepresents difficult observations. It estimates neither natural prevalence nor performance on arbitrary narratives. All six writers are fixed, the tag’s public codebook entry is provided, and labels shared by multiple writers are scored once for the primary analysis. All three models received identical user messages in the same eight-row packets. This design tests quantized local readers under their frozen inference settings. It cannot isolate model size or reasoning mode. Responses within each packet and cases sharing a cutoff may covary. The study reports exact descriptive counts for this panel.

The paid inference cap was USD 0 and paid inference spend was USD 0. Only the preinstalled local service was called. The journal records 118 local dispatches across all arms, including 114 for the 114 packets across the complete readers. The aggregate cap was 228 dispatches. Ordinary electricity and hardware costs are outside this figure. Token totals below sum fields returned by the service for completed requests; they are not billable counts.

| Local reader | Scheduled | Dispatches | Successful-format packets | Invalid-format packets | Transport-error packets | Input tokens | Generated tokens |
|---|---|---|---|---|---|---|---|
| Llama 3.2 3.2B | 38 | 38 | 38 | 0 | 0 | 20259 | 1064 |
| Qwen2.5 3B Instruct | 38 | 38 | 38 | 0 | 0 | 23213 | 1596 |
| GPT-OSS 20.9B | 38 | 38 | 38 | 0 | 0 | 21893 | 26497 |

DeepSeek-R1 was stopped after p004. The journal and final receipts cover 4 dispatches and 32 rows: 0 valid and 32 invalid. 34 packets (272 rows) were never run, and have no recorded action. See results.json, amendment.stopped_arm, for the individual packet-status and fresh/calibration coverage ledger. DeepSeek contributes no full-panel rate or paired ranking.

The [preregistered protocol](PROTOCOL.md) specifies sampling, hypotheses and readout. [comparison.csv](comparison.csv) lists numerators and denominators by reader, writer and cutoff, including exact controls. Writer-level counts use each visible row only once within that writer, so they overlap across writers. [results.json](results.json) preserves individual public rows, linked writer names and paired decisions. The residue rule is a finite model of one arithmetic ingredient from earlier witness studies. Every compatible center is explicitly included. These outputs measure readers of that finite model. They supply no information identifying a center selected in the formal proof and include no Lean kernel check.

**Human–AI collaboration.** Justin Candler set the experimental question and authorized the Qwen substitution. Uriel, the OpenAI assistant in Codex, implemented the study, collected and audited the local outputs, and prepared this readout. Llama, Qwen, GPT-OSS and DeepSeek were evaluated readers.

Recreate these two tables with `python3 -B amendment/score_cohort.py` and `python3 -B summarize.py` from this directory.
